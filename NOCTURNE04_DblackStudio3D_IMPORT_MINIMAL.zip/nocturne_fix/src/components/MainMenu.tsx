import { useEffect, useState } from 'react';
import {
  BookOpen,
  ChevronRight,
  Cpu,
  FolderOpen,
  Gamepad2,
  Globe,
  Info,
  Lock,
  Play,
  RotateCcw,
  Settings,
  ShoppingBag,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { DIFFICULTY_CONFIGS } from '../gameplay/difficulty';
import { t } from '../i18n/translations';
import { SaveManager } from '../save/saveManager';
import { CHAPTERS, MAIN_CHAPTER_ORDER, MAIN_KEYART_URL } from '../story/chaptersData';
import type {
  ChapterId,
  DifficultyId,
  EntitlementState,
  GameSettings,
  GlobalProgressData,
  HudSnapshot,
  RenderProfileMode,
  SaveSlotData,
} from '../types/game';
import type { HospitalEngineHandle } from './HospitalViewport';

interface MainMenuProps {
  hud: HudSnapshot;
  settings: GameSettings;
  entitlements: EntitlementState;
  engineRef: React.RefObject<HospitalEngineHandle | null>;
  onUpdateSettings: (next: GameSettings) => void;
  onOpenCodex: () => void;
  onOpenShop: () => void;
  onOpenCredits: () => void;
}

type MenuPanel = 'root' | 'new_game' | 'load' | 'chapters' | 'settings' | 'controls';

const PROFILE_OPTIONS: { id: RenderProfileMode; labelFr: string; labelEn: string }[] = [
  { id: 'auto', labelFr: 'Auto Adaptatif', labelEn: 'Adaptive Auto' },
  { id: 'cinematic_4k', labelFr: '4K AAA', labelEn: '4K AAA' },
  { id: 'cinematic_8k', labelFr: '8K Cinématique', labelEn: '8K Cinematic' },
  { id: 'mobile_landscape', labelFr: 'Mobile Équilibré', labelEn: 'Mobile Balanced' },
  { id: 'performance', labelFr: 'Performance Max', labelEn: 'Max Performance' },
];

export function MainMenu({
  hud,
  settings,
  entitlements,
  engineRef,
  onUpdateSettings,
  onOpenCodex,
  onOpenShop,
  onOpenCredits,
}: MainMenuProps) {
  const [panel, setPanel] = useState<MenuPanel>('root');
  const [selectedDiff, setSelectedDiff] = useState<DifficultyId>('normal');
  const [progress, setProgress] = useState<GlobalProgressData>(() => SaveManager.loadProgress());
  const [slots, setSlots] = useState<Record<SaveSlotData['slotId'], SaveSlotData | null>>(() =>
    SaveManager.listSlots(),
  );
  const [quitNotice, setQuitNotice] = useState(false);

  const lang = settings.language;
  const fr = lang === 'fr';
  const copy = t(lang);
  const latestSave = SaveManager.getLatestSave();

  useEffect(() => {
    setProgress(SaveManager.loadProgress());
    setSlots(SaveManager.listSlots());
  }, [panel, hud.phase]);

  const toggleLanguage = () => {
    const nextLang = lang === 'fr' ? 'en' : 'fr';
    onUpdateSettings({ ...settings, language: nextLang });
  };

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between overflow-y-auto bg-[#030509] text-[#e7eef5]">
      {/* Background atmospheric key art blended with live 3D corridor */}
      <div
        className="pointer-events-none fixed inset-0 bg-cover bg-center opacity-35 transition-opacity duration-700"
        style={{ backgroundImage: `url('${MAIN_KEYART_URL}')` }}
      />
      <div className="pointer-events-none fixed inset-0 bg-gradient-to-r from-[#030509] via-[#030509]/85 to-[#030509]/45" />
      <div className="pointer-events-none fixed inset-0 bg-gradient-to-t from-[#030509] via-transparent to-[#030509]/75" />

      {/* Top Header Strip */}
      <header className="relative z-10 flex flex-wrap items-center justify-between gap-3 px-6 py-5 sm:px-10 border-b border-white/10">
        <div className="flex items-center gap-4">
          <span className="font-mono text-[11px] tracking-[0.26em] text-[#84b3d9] uppercase">
            {fr ? 'CAMPAGNE SURVIVAL HORROR · 6 CHAPITRES' : 'SURVIVAL HORROR CAMPAIGN · 6 CHAPTERS'}
          </span>
          {entitlements.premiumPass && (
            <span className="border border-[#d4a24e]/50 bg-[#231908]/90 px-2 py-0.5 font-mono text-[10px] tracking-[0.18em] text-[#f2cb79]">
              {copy.premiumActive}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleLanguage}
            className="flex min-h-[40px] items-center gap-2 border border-white/15 bg-[#080e17]/90 px-3 py-1.5 text-xs font-medium tracking-wider text-[#cfe0ee] hover:border-[#7bc0f2]/60 hover:text-white cursor-pointer"
          >
            <Globe className="h-3.5 w-3.5 text-[#7bc0f2]" />
            <span>{lang.toUpperCase()}</span>
          </button>

          <button
            type="button"
            onClick={() => engineRef.current?.toggleMute()}
            className="flex min-h-[40px] items-center gap-2 border border-white/15 bg-[#080e17]/90 px-3 py-1.5 text-xs font-medium tracking-wider text-[#cfe0ee] hover:border-[#7bc0f2]/60 hover:text-white cursor-pointer"
          >
            {hud.muted ? <VolumeX className="h-3.5 w-3.5 text-[#e14b56]" /> : <Volume2 className="h-3.5 w-3.5 text-[#7bc0f2]" />}
            <span>{hud.muted ? (fr ? 'MUET' : 'MUTED') : 'AUDIO'}</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="relative z-10 mx-auto flex w-full max-w-6xl flex-1 flex-col justify-center px-6 py-8 sm:px-10 lg:flex-row lg:items-center lg:gap-12">
        {/* Left: Game Identity & Primary Navigation */}
        <div className="w-full max-w-md shrink-0">
          <div className="mb-1 flex items-center gap-2.5">
            <span className="h-px w-8 bg-[#e14b56]" />
            <span className="font-mono text-[11px] tracking-[0.28em] text-[#d67e85] uppercase">
              {copy.freeBadge}
            </span>
          </div>

          <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-[0.14em] text-[#f3f8fc] leading-none">
            {copy.gameTitle}
          </h1>
          <div className="mt-2 font-display text-base sm:text-lg font-semibold tracking-[0.34em] text-[#8db4d4]">
            {copy.gameSubtitle}
          </div>

          <p className="mt-4 text-sm leading-relaxed text-[#a9bfd1] max-w-md">
            {fr
              ? '02h17. Maya disparaît dans l’ancien hôpital de Kambala. Survivez aux six chapitres, percez le protocole secret NOCTURNE et échappez au Patient 04.'
              : '02:17 AM. Maya vanishes inside the abandoned Kambala Hospital. Survive all six chapters, uncover Project NOCTURNE, and evade Patient 04.'}
          </p>

          {/* Menu List */}
          <nav className="mt-7 flex flex-col gap-1.5" aria-label={fr ? 'Menu principal' : 'Main Menu'}>
            <button
              type="button"
              onClick={() => setPanel('new_game')}
              className="group flex min-h-[44px] items-center justify-between border border-[#7bc0f2]/40 bg-[#0d1927]/95 px-4 py-2.5 text-left text-sm font-semibold tracking-[0.14em] text-white uppercase hover:border-[#7bc0f2] hover:bg-[#14253a] cursor-pointer"
            >
              <span className="flex items-center gap-3">
                <Play className="h-4 w-4 text-[#7bc0f2] fill-current" />
                {copy.newGame}
              </span>
              <ChevronRight className="h-4 w-4 text-[#7bc0f2] transition-transform group-hover:translate-x-1" />
            </button>

            {latestSave && (
              <button
                type="button"
                onClick={() => engineRef.current?.loadFromSave(latestSave)}
                className="flex min-h-[44px] items-center justify-between border border-[#4fe09b]/35 bg-[#091c15]/90 px-4 py-2.5 text-left text-sm font-semibold tracking-[0.12em] text-[#baf7d8] uppercase hover:border-[#4fe09b] hover:bg-[#0e291f] cursor-pointer"
              >
                <span className="flex items-center gap-3">
                  <RotateCcw className="h-4 w-4 text-[#4fe09b]" />
                  {copy.continueGame}
                </span>
                <span className="font-mono text-[11px] text-[#7be7b4]">
                  {fr ? CHAPTERS[latestSave.chapterId].labelFr : CHAPTERS[latestSave.chapterId].labelEn}
                </span>
              </button>
            )}

            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setPanel('load')}
                className={`flex min-h-[42px] items-center gap-2.5 border px-3.5 py-2 text-xs font-semibold tracking-wider uppercase cursor-pointer ${
                  panel === 'load'
                    ? 'border-[#7bc0f2] bg-[#132336] text-white'
                    : 'border-white/12 bg-[#070c14]/90 text-[#bfd2e2] hover:border-white/35 hover:text-white'
                }`}
              >
                <FolderOpen className="h-3.5 w-3.5 text-[#7bc0f2]" />
                <span>{copy.loadGame}</span>
              </button>

              <button
                type="button"
                onClick={() => setPanel('chapters')}
                className={`flex min-h-[42px] items-center gap-2.5 border px-3.5 py-2 text-xs font-semibold tracking-wider uppercase cursor-pointer ${
                  panel === 'chapters'
                    ? 'border-[#7bc0f2] bg-[#132336] text-white'
                    : 'border-white/12 bg-[#070c14]/90 text-[#bfd2e2] hover:border-white/35 hover:text-white'
                }`}
              >
                <ChevronRight className="h-3.5 w-3.5 text-[#7bc0f2]" />
                <span>{copy.chapters}</span>
              </button>

              <button
                type="button"
                onClick={onOpenCodex}
                className="flex min-h-[42px] items-center gap-2.5 border border-white/12 bg-[#070c14]/90 px-3.5 py-2 text-xs font-semibold tracking-wider text-[#bfd2e2] uppercase hover:border-white/35 hover:text-white cursor-pointer"
              >
                <BookOpen className="h-3.5 w-3.5 text-[#7bc0f2]" />
                <span>{copy.codex}</span>
              </button>

              <button
                type="button"
                onClick={() => setPanel('settings')}
                className={`flex min-h-[42px] items-center gap-2.5 border px-3.5 py-2 text-xs font-semibold tracking-wider uppercase cursor-pointer ${
                  panel === 'settings'
                    ? 'border-[#7bc0f2] bg-[#132336] text-white'
                    : 'border-white/12 bg-[#070c14]/90 text-[#bfd2e2] hover:border-white/35 hover:text-white'
                }`}
              >
                <Settings className="h-3.5 w-3.5 text-[#7bc0f2]" />
                <span>{copy.settings}</span>
              </button>

              <button
                type="button"
                onClick={() => setPanel('controls')}
                className={`flex min-h-[42px] items-center gap-2.5 border px-3.5 py-2 text-xs font-semibold tracking-wider uppercase cursor-pointer ${
                  panel === 'controls'
                    ? 'border-[#7bc0f2] bg-[#132336] text-white'
                    : 'border-white/12 bg-[#070c14]/90 text-[#bfd2e2] hover:border-white/35 hover:text-white'
                }`}
              >
                <Gamepad2 className="h-3.5 w-3.5 text-[#7bc0f2]" />
                <span>{copy.controls}</span>
              </button>

              <button
                type="button"
                onClick={onOpenCredits}
                className="flex min-h-[42px] items-center gap-2.5 border border-white/12 bg-[#070c14]/90 px-3.5 py-2 text-xs font-semibold tracking-wider text-[#bfd2e2] uppercase hover:border-white/35 hover:text-white cursor-pointer"
              >
                <Info className="h-3.5 w-3.5 text-[#7bc0f2]" />
                <span>{copy.credits}</span>
              </button>
            </div>

            <div className="mt-1 grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={onOpenShop}
                className="flex min-h-[42px] items-center justify-center gap-2 border border-[#d4a24e]/45 bg-[#1b1407]/90 px-3.5 py-2 text-xs font-bold tracking-wider text-[#f3cd7e] uppercase hover:border-[#f3cd7e] hover:bg-[#291e0b] cursor-pointer"
              >
                <ShoppingBag className="h-3.5 w-3.5" />
                <span>{copy.shop} · DLC</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setPanel('root');
                  setQuitNotice(true);
                  setTimeout(() => setQuitNotice(false), 3500);
                }}
                className="flex min-h-[42px] items-center justify-center gap-2 border border-white/10 bg-[#070c14]/80 px-3.5 py-2 text-xs font-semibold tracking-wider text-[#90a6b8] uppercase hover:border-white/25 hover:text-white cursor-pointer"
              >
                <span>{fr ? 'Réinitialiser vue' : 'Reset Title'}</span>
              </button>
            </div>

            {quitNotice && (
              <div className="mt-1 border border-white/15 bg-[#080f18] px-3 py-2 text-xs text-[#9cb7cc]">
                {fr
                  ? 'Vous pouvez fermer cet onglet à tout moment ; votre progression locale est conservée.'
                  : 'You can safely close this tab anytime; local progress is preserved.'}
              </div>
            )}
          </nav>
        </div>

        {/* Right: Contextual Sub-Panel */}
        <div className="mt-8 w-full flex-1 lg:mt-0">
          {panel === 'root' && (
            <div className="border border-white/12 bg-[#060b12]/88 p-6 backdrop-blur-sm">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="font-mono text-[11px] tracking-[0.22em] text-[#7bc0f2] uppercase">
                  {fr ? 'DOSSIER DE SURVIE' : 'SURVIVAL BRIEFING'}
                </span>
                <span className="font-mono text-[11px] text-[#8aa4b8]">
                  {progress.unlockedEndings.length}/3 {fr ? 'FINS' : 'ENDINGS'}
                </span>
              </div>

              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="border border-white/10 bg-[#0a121d] p-4">
                  <div className="font-mono text-[10px] tracking-[0.2em] text-[#e14b56] uppercase">
                    {fr ? 'MENACE BIOLOGIQUE' : 'BIO-THREAT'}
                  </div>
                  <h3 className="mt-1 font-display text-base font-bold text-white">Patient 04</h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-[#a8bfd1]">
                    {fr
                      ? 'Il réagit aux bruits, à la lampe torche et imite la voix de Maya. Économisez vos munitions de 9mm, lancez des bouteilles pour le détourner et cachez-vous dans les casiers.'
                      : 'Reacts to noise, flashlight beams, and mimics Maya’s voice. Conserve 9mm ammo, distract him with glass bottles, and hide inside lockers.'}
                  </p>
                </div>

                <div className="border border-white/10 bg-[#0a121d] p-4">
                  <div className="font-mono text-[10px] tracking-[0.2em] text-[#d4a24e] uppercase">
                    {fr ? 'FIN SECRÈTE & DLC' : 'SECRET ENDING & DLC'}
                  </div>
                  <h3 className="mt-1 font-display text-base font-bold text-white">
                    {fr ? '3 Fins & Dossiers Oubliés' : '3 Endings & Forgotten Files'}
                  </h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-[#a8bfd1]">
                    {fr
                      ? 'Récupérez les 3 dossiers classifiés au Chapitre 5 pour débloquer la Fin C (NOCTURNE). Découvrez le DLC préquelle et le Mode Photo dans la Boutique.'
                      : 'Find all 3 classified files in Chapter 5 to unlock Ending C (NOCTURNE). Explore the prequel DLC and Photo Mode in the Store.'}
                  </p>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-4 text-xs text-[#91aac0]">
                <span>
                  {fr
                    ? `Chapitres débloqués : ${progress.unlockedChapters.length}/6 · Documents lus : ${progress.discoveredDocIds.length}`
                    : `Chapters unlocked: ${progress.unlockedChapters.length}/6 · Files read: ${progress.discoveredDocIds.length}`}
                </span>
                <button
                  type="button"
                  onClick={() => engineRef.current?.startNewGame('normal', 'ch1')}
                  className="inline-flex items-center gap-2 border border-[#7bc0f2]/50 bg-[#122438] px-4 py-2 text-xs font-bold tracking-wider text-white uppercase hover:bg-[#1a3450] cursor-pointer"
                >
                  <Play className="h-3.5 w-3.5 fill-current" />
                  <span>{fr ? 'Lancement rapide (Normal)' : 'Quick Start (Normal)'}</span>
                </button>
              </div>
            </div>
          )}

          {panel === 'new_game' && (
            <div className="border border-white/15 bg-[#060b12]/92 p-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h2 className="font-display text-lg font-bold tracking-wider text-white uppercase">
                  {copy.difficultyTitle}
                </h2>
                <button
                  type="button"
                  onClick={() => setPanel('root')}
                  className="text-xs text-[#8ba5ba] hover:text-white cursor-pointer"
                >
                  {copy.back}
                </button>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                {(['easy', 'normal', 'nightmare'] as DifficultyId[]).map((diffId) => {
                  const cfg = DIFFICULTY_CONFIGS[diffId];
                  const active = selectedDiff === diffId;
                  return (
                    <button
                      key={diffId}
                      type="button"
                      onClick={() => setSelectedDiff(diffId)}
                      className={`flex flex-col justify-between border p-4 text-left transition-colors cursor-pointer ${
                        active
                          ? 'border-[#7bc0f2] bg-[#102235]'
                          : 'border-white/12 bg-[#0a111a] hover:border-white/30'
                      }`}
                    >
                      <div>
                        <div className="font-display text-sm font-bold tracking-wider text-white uppercase">
                          {fr ? cfg.labelFr : cfg.labelEn}
                        </div>
                        <p className="mt-2 text-xs leading-relaxed text-[#a8bfd1]">
                          {fr ? cfg.descFr : cfg.descEn}
                        </p>
                      </div>
                      <div className="mt-3 border-t border-white/10 pt-2 font-mono text-[10px] text-[#7ea3c2]">
                        HP {cfg.playerMaxHealth} · {cfg.startingAmmo} {fr ? 'BALLES' : 'ROUNDS'}
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="mt-5 flex justify-end">
                <button
                  type="button"
                  onClick={() => engineRef.current?.startNewGame(selectedDiff, 'ch1')}
                  className="inline-flex min-h-[44px] items-center gap-2.5 bg-[#e6f1fa] px-6 py-3 text-xs font-bold tracking-[0.2em] text-[#040910] uppercase hover:bg-white cursor-pointer"
                >
                  <Play className="h-4 w-4 fill-current" />
                  <span>{copy.startAdventure}</span>
                </button>
              </div>
            </div>
          )}

          {panel === 'load' && (
            <div className="border border-white/15 bg-[#060b12]/92 p-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h2 className="font-display text-lg font-bold tracking-wider text-white uppercase">
                  {copy.loadGame}
                </h2>
                <button
                  type="button"
                  onClick={() => setPanel('root')}
                  className="text-xs text-[#8ba5ba] hover:text-white cursor-pointer"
                >
                  {copy.back}
                </button>
              </div>

              <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
                {(['auto', 'slot1', 'slot2', 'slot3'] as SaveSlotData['slotId'][]).map((slotId) => {
                  const s = slots[slotId];
                  const slotName =
                    slotId === 'auto'
                      ? fr
                        ? 'Sauvegarde Auto'
                        : 'Auto Save'
                      : `${fr ? 'Emplacement' : 'Slot'} ${slotId.replace('slot', '')}`;
                  return (
                    <div
                      key={slotId}
                      className="flex flex-col justify-between border border-white/12 bg-[#0a111a] p-4"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-xs font-bold text-[#7bc0f2] uppercase">
                            {slotName}
                          </span>
                          {s && (
                            <span className="font-mono text-[10px] text-[#7f97ab]">
                              {new Date(s.savedAt).toLocaleString()}
                            </span>
                          )}
                        </div>
                        {s ? (
                          <div className="mt-2">
                            <div className="text-sm font-semibold text-white">
                              {fr ? CHAPTERS[s.chapterId].labelFr : CHAPTERS[s.chapterId].labelEn} —{' '}
                              {fr ? CHAPTERS[s.chapterId].titleFr : CHAPTERS[s.chapterId].titleEn}
                            </div>
                            <div className="mt-1 font-mono text-[11px] text-[#9eb6c9]">
                              HP {Math.round(s.health)} · {fr ? 'Indices' : 'Clues'} {s.cluesCollected}/4
                            </div>
                          </div>
                        ) : (
                          <div className="mt-3 text-xs text-[#697f92]">
                            {fr ? 'Emplacement vide' : 'Empty slot'}
                          </div>
                        )}
                      </div>

                      {s && (
                        <button
                          type="button"
                          onClick={() => engineRef.current?.loadFromSave(s)}
                          className="mt-3 w-full border border-[#7bc0f2]/50 bg-[#112438] py-2 text-xs font-bold tracking-wider text-white uppercase hover:bg-[#193450] cursor-pointer"
                        >
                          {fr ? 'Charger' : 'Load'}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {panel === 'chapters' && (
            <div className="border border-white/15 bg-[#060b12]/92 p-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h2 className="font-display text-lg font-bold tracking-wider text-white uppercase">
                  {copy.chapters}
                </h2>
                <button
                  type="button"
                  onClick={() => setPanel('root')}
                  className="text-xs text-[#8ba5ba] hover:text-white cursor-pointer"
                >
                  {copy.back}
                </button>
              </div>

              <div className="mt-4 grid max-h-[380px] gap-2.5 overflow-y-auto pr-1 sm:grid-cols-2">
                {[...MAIN_CHAPTER_ORDER, 'dlc1' as ChapterId].map((cid) => {
                  const cfg = CHAPTERS[cid];
                  const isDlc = cid === 'dlc1';
                  const unlocked = isDlc
                    ? entitlements.dlcForgottenFiles
                    : progress.unlockedChapters.includes(cid) || cid === 'ch1';

                  return (
                    <div
                      key={cid}
                      className={`flex flex-col justify-between border p-3.5 ${
                        unlocked
                          ? 'border-white/15 bg-[#0a121c]'
                          : 'border-white/8 bg-[#070b11] opacity-75'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span
                            className={`font-mono text-[10px] tracking-wider uppercase ${
                              isDlc ? 'text-[#f2cb79]' : 'text-[#7bc0f2]'
                            }`}
                          >
                            {fr ? cfg.labelFr : cfg.labelEn}
                          </span>
                          {!unlocked && <Lock className="h-3.5 w-3.5 text-[#7c92a6]" />}
                        </div>
                        <div className="mt-1 font-display text-sm font-bold text-white">
                          {fr ? cfg.titleFr : cfg.titleEn}
                        </div>
                        <p className="mt-1 text-xs leading-snug text-[#9eb5c7] line-clamp-2">
                          {fr ? cfg.summaryFr : cfg.summaryEn}
                        </p>
                      </div>

                      <div className="mt-3">
                        {unlocked ? (
                          <button
                            type="button"
                            onClick={() => engineRef.current?.startChapterDirect(cid, selectedDiff)}
                            className="w-full border border-[#7bc0f2]/45 bg-[#102235] py-2 text-xs font-bold tracking-wider text-white uppercase hover:bg-[#1a3552] cursor-pointer"
                          >
                            {fr ? 'Jouer ce chapitre' : 'Play Chapter'}
                          </button>
                        ) : isDlc ? (
                          <button
                            type="button"
                            onClick={onOpenShop}
                            className="flex w-full items-center justify-center gap-1.5 border border-[#d4a24e]/50 bg-[#231907] py-2 text-xs font-bold tracking-wider text-[#f2cb79] uppercase hover:bg-[#33240a] cursor-pointer"
                          >
                            <Sparkles className="h-3.5 w-3.5" />
                            <span>{fr ? 'Débloquer DLC (2,99 $)' : 'Unlock DLC ($2.99)'}</span>
                          </button>
                        ) : (
                          <div className="py-1.5 text-center font-mono text-[10px] text-[#6d8296] uppercase">
                            {fr ? 'Terminez le chapitre précédent' : 'Complete previous chapter'}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {panel === 'settings' && (
            <div className="border border-white/15 bg-[#060b12]/92 p-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h2 className="font-display text-lg font-bold tracking-wider text-white uppercase">
                  {copy.settings}
                </h2>
                <button
                  type="button"
                  onClick={() => setPanel('root')}
                  className="text-xs text-[#8ba5ba] hover:text-white cursor-pointer"
                >
                  {copy.back}
                </button>
              </div>

              <div className="mt-4 space-y-4">
                <div>
                  <div className="mb-2 flex items-center gap-2 font-mono text-[11px] text-[#7bc0f2] uppercase">
                    <Cpu className="h-3.5 w-3.5" />
                    <span>{fr ? 'Profil graphique' : 'Graphics Profile'}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                    {PROFILE_OPTIONS.map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => onUpdateSettings({ ...settings, profileMode: opt.id })}
                        className={`min-h-[40px] border px-2.5 py-1.5 text-xs font-semibold cursor-pointer ${
                          settings.profileMode === opt.id
                            ? 'border-[#7bc0f2] bg-[#63a5d8] text-[#040910]'
                            : 'border-white/15 bg-[#0b131e] text-[#bdd0e0] hover:border-white/35'
                        }`}
                      >
                        {fr ? opt.labelFr : opt.labelEn}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block text-xs text-[#bdd0e0]">
                    <div className="mb-1 flex justify-between">
                      <span>{fr ? 'Volume principal' : 'Master Volume'}</span>
                      <span className="font-mono">{Math.round(settings.masterVolume * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={settings.masterVolume}
                      onChange={(e) =>
                        onUpdateSettings({ ...settings, masterVolume: Number(e.target.value) })
                      }
                      className="w-full accent-[#63a5d8]"
                    />
                  </label>

                  <label className="block text-xs text-[#bdd0e0]">
                    <div className="mb-1 flex justify-between">
                      <span>{fr ? 'Sensibilité caméra' : 'Camera Sensitivity'}</span>
                      <span className="font-mono">{settings.mouseSensitivity.toFixed(1)}x</span>
                    </div>
                    <input
                      type="range"
                      min={0.4}
                      max={2.2}
                      step={0.1}
                      value={settings.mouseSensitivity}
                      onChange={(e) =>
                        onUpdateSettings({ ...settings, mouseSensitivity: Number(e.target.value) })
                      }
                      className="w-full accent-[#63a5d8]"
                    />
                  </label>

                  <label className="block text-xs text-[#bdd0e0]">
                    <div className="mb-1 flex justify-between">
                      <span>{fr ? 'Champ de vision (FOV)' : 'Field of View'}</span>
                      <span className="font-mono">{Math.round((settings.fov * 180) / Math.PI)}°</span>
                    </div>
                    <input
                      type="range"
                      min={0.85}
                      max={1.28}
                      step={0.03}
                      value={settings.fov}
                      onChange={(e) => onUpdateSettings({ ...settings, fov: Number(e.target.value) })}
                      className="w-full accent-[#63a5d8]"
                    />
                  </label>

                  <div className="flex items-center justify-between border border-white/10 bg-[#0a111a] px-3.5 py-2.5">
                    <span className="text-xs text-[#cfe0ee]">
                      {fr ? 'Sous-titres & Voix' : 'Subtitles & Voice'}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({
                          ...settings,
                          subtitlesEnabled: !settings.subtitlesEnabled,
                        })
                      }
                      className={`border px-3 py-1 font-mono text-xs font-bold cursor-pointer ${
                        settings.subtitlesEnabled
                          ? 'border-[#4fe09b]/50 bg-[#0d271c] text-[#72f0b5]'
                          : 'border-white/15 bg-[#121a24] text-[#8499ab]'
                      }`}
                    >
                      {settings.subtitlesEnabled ? 'ON' : 'OFF'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {panel === 'controls' && (
            <div className="border border-white/15 bg-[#060b12]/92 p-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h2 className="font-display text-lg font-bold tracking-wider text-white uppercase">
                  {copy.controls}
                </h2>
                <button
                  type="button"
                  onClick={() => setPanel('root')}
                  className="text-xs text-[#8ba5ba] hover:text-white cursor-pointer"
                >
                  {copy.back}
                </button>
              </div>

              <div className="mt-4 grid gap-2 sm:grid-cols-2 text-xs">
                {[
                  ['WASD / ZQSD', fr ? 'Déplacement' : 'Move'],
                  ['Shift', fr ? 'Courir (endurance)' : 'Sprint (stamina)'],
                  ['C / Espace', fr ? 'Accroupir / Sauter' : 'Crouch / Jump'],
                  ['V', fr ? 'Basculer Vue 1P / 3P' : 'Toggle 1st / 3rd Person'],
                  ['E', fr ? 'Interagir / Cacher / Fouiller' : 'Interact / Hide / Search'],
                  ['F / B', fr ? 'Lampe torche / Changer pile' : 'Flashlight / Recharge'],
                  ['Clic G / R', fr ? 'Tirer (9mm) / Recharger' : 'Shoot (9mm) / Reload'],
                  ['G / X / H', fr ? 'Bouteille / Fusée / Soin' : 'Bottle / Flare / Medkit'],
                  ['Tab / J', fr ? 'Inventaire / Codex' : 'Inventory / Codex'],
                  ['Échap', fr ? 'Pause' : 'Pause'],
                ].map(([keyLabel, actionLabel]) => (
                  <div
                    key={keyLabel}
                    className="flex items-center justify-between border border-white/10 bg-[#0a111a] px-3 py-2"
                  >
                    <span className="font-mono font-bold text-[#7bc0f2]">{keyLabel}</span>
                    <span className="text-[#c9dae8]">{actionLabel}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer Strip */}
      <footer className="relative z-10 flex flex-wrap items-center justify-between gap-2 border-t border-white/10 px-6 py-3 sm:px-10 text-[11px] font-mono text-[#7c94a8]">
        <span>NOCTURNE 04 — PAVILLON KAMBALA · WEB 3D HORROR</span>
        <span>
          {hud.fps} FPS · {hud.activeTier.toUpperCase()}
        </span>
      </footer>
    </div>
  );
}
