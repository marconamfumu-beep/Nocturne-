import { useState } from 'react';
import { Camera, Download, Eye, Film, X } from 'lucide-react';
import type { Language, VisualFilterMode } from '../types/game';
import type { HospitalEngineHandle } from './HospitalViewport';

interface PhotoModeOverlayProps {
  language: Language;
  visualFilter: VisualFilterMode;
  engineRef: React.RefObject<HospitalEngineHandle | null>;
}

export function PhotoModeOverlay({ language, visualFilter, engineRef }: PhotoModeOverlayProps) {
  const [savedToast, setSavedToast] = useState(false);
  const fr = language === 'fr';

  const handleCapture = () => {
    const dataUrl = engineRef.current?.capturePhotoSnapshot();
    if (!dataUrl) return;
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `nocturne04-kambala-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 2500);
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-30 flex flex-col justify-between p-5">
      <div className="pointer-events-auto flex items-center justify-between border border-[#d4a24e]/45 bg-[#070c14]/90 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <Camera className="h-4 w-4 text-[#f2cb79]" />
          <div>
            <div className="font-mono text-xs font-bold tracking-wider text-white uppercase">
              {fr ? 'MODE PHOTO · PREMIUM PASS' : 'PHOTO MODE · PREMIUM PASS'}
            </div>
            <div className="text-[11px] text-[#9eb6c9]">
              {fr
                ? 'WASD/ZQSD Déplacer caméra libre · Espace/C Monter/Descendre · Glisser Orienter'
                : 'WASD Free Camera · Space/C Up/Down · Drag to Look'}
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => engineRef.current?.resumeGame()}
          className="flex min-h-[40px] items-center gap-1.5 border border-white/20 bg-[#0d1622] px-3 py-1.5 text-xs font-semibold text-white cursor-pointer"
        >
          <X className="h-4 w-4" />
          <span>{fr ? 'Quitter' : 'Exit'}</span>
        </button>
      </div>

      <div className="pointer-events-auto mx-auto flex flex-wrap items-center gap-2 border border-white/15 bg-[#070c14]/92 px-4 py-3">
        {(
          [
            { id: 'none', label: fr ? 'Standard' : 'Standard', icon: Eye },
            { id: 'vhs', label: 'Caméra VHS', icon: Film },
            { id: 'night_vision', label: fr ? 'Vision Nocturne' : 'Night Vision', icon: Camera },
          ] as const
        ).map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            onClick={() => engineRef.current?.setVisualFilter(id)}
            className={`flex min-h-[40px] items-center gap-1.5 border px-3 py-1.5 text-xs font-semibold cursor-pointer ${
              visualFilter === id
                ? 'border-[#f2cb79] bg-[#2a1f0b] text-[#f5d58f]'
                : 'border-white/15 bg-[#0d1622] text-[#bfd2e2] hover:text-white'
            }`}
          >
            <Icon className="h-3.5 w-3.5" />
            <span>{label}</span>
          </button>
        ))}

        <button
          type="button"
          onClick={handleCapture}
          className="flex min-h-[40px] items-center gap-2 bg-[#e6f1fa] px-4 py-2 text-xs font-bold tracking-wider text-[#040910] uppercase hover:bg-white cursor-pointer"
        >
          <Download className="h-3.5 w-3.5" />
          <span>{fr ? 'Capturer PNG' : 'Capture PNG'}</span>
        </button>

        {savedToast && (
          <span className="font-mono text-xs text-[#5ee6a8] px-2">
            {fr ? 'Capture téléchargée !' : 'Snapshot saved!'}
          </span>
        )}
      </div>
    </div>
  );
}
