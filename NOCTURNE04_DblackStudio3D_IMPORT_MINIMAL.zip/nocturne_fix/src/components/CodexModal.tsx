import { useState } from 'react';
import { Award, BookOpen, Headphones, Lock, Play, X } from 'lucide-react';
import { SaveManager } from '../save/saveManager';
import { AUDIO_TAPES, ENDINGS, STORY_DOCUMENTS } from '../story/chaptersData';
import type { EndingId, EntitlementState, Language } from '../types/game';

interface CodexModalProps {
  language: Language;
  discoveredDocIds: string[];
  discoveredTapeIds: string[];
  entitlements: EntitlementState;
  onPlayTape: (tapeId: string) => void;
  onClose: () => void;
}

export function CodexModal({
  language,
  discoveredDocIds,
  discoveredTapeIds,
  entitlements,
  onPlayTape,
  onClose,
}: CodexModalProps) {
  const [tab, setTab] = useState<'docs' | 'tapes' | 'endings'>('docs');
  const [selectedDocId, setSelectedDocId] = useState<string>(STORY_DOCUMENTS[0].id);

  const progress = SaveManager.loadProgress();
  const knownDocs = new Set([...progress.discoveredDocIds, ...discoveredDocIds]);
  const knownTapes = new Set([...progress.discoveredTapeIds, ...discoveredTapeIds]);
  const fr = language === 'fr';

  const activeDoc = STORY_DOCUMENTS.find((d) => d.id === selectedDocId) ?? STORY_DOCUMENTS[0];
  const activeDocUnlocked =
    knownDocs.has(activeDoc.id) && (!activeDoc.isPremiumBonus || entitlements.premiumPass);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#030509]/88 p-4 backdrop-blur-sm">
      <div className="flex max-h-[90vh] w-full max-w-4xl flex-col border border-[#8db4d4]/30 bg-[#070c14]/98 shadow-[0_24px_70px_rgba(0,0,0,0.92)]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div>
            <div className="font-mono text-[10px] tracking-[0.24em] text-[#7bc0f2] uppercase">
              NOCTURNE 04 · {fr ? 'ARCHIVES MÉDICALES' : 'MEDICAL ARCHIVES'}
            </div>
            <h2 className="font-display text-xl font-bold tracking-wider text-white uppercase mt-0.5">
              {fr ? 'Dossiers, Bandes Audio & Fins' : 'Documents, Audio Tapes & Endings'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex min-h-[40px] items-center gap-1.5 border border-white/15 bg-[#0e1724] px-3 py-1.5 text-xs font-semibold text-[#d2e2f0] hover:border-white/40 cursor-pointer"
          >
            <X className="h-4 w-4" />
            <span>{fr ? 'Fermer' : 'Close'}</span>
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-white/10 bg-[#050910] px-6">
          <button
            type="button"
            onClick={() => setTab('docs')}
            className={`flex items-center gap-2 border-b-2 px-4 py-3 text-xs font-bold tracking-wider uppercase cursor-pointer ${
              tab === 'docs'
                ? 'border-[#7bc0f2] text-white'
                : 'border-transparent text-[#859db2] hover:text-white'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            <span>
              {fr ? 'Documents' : 'Documents'} ({knownDocs.size}/{STORY_DOCUMENTS.length})
            </span>
          </button>
          <button
            type="button"
            onClick={() => setTab('tapes')}
            className={`flex items-center gap-2 border-b-2 px-4 py-3 text-xs font-bold tracking-wider uppercase cursor-pointer ${
              tab === 'tapes'
                ? 'border-[#7bc0f2] text-white'
                : 'border-transparent text-[#859db2] hover:text-white'
            }`}
          >
            <Headphones className="h-3.5 w-3.5" />
            <span>
              {fr ? 'Bandes Audio' : 'Audio Tapes'} ({knownTapes.size}/{AUDIO_TAPES.length})
            </span>
          </button>
          <button
            type="button"
            onClick={() => setTab('endings')}
            className={`flex items-center gap-2 border-b-2 px-4 py-3 text-xs font-bold tracking-wider uppercase cursor-pointer ${
              tab === 'endings'
                ? 'border-[#7bc0f2] text-white'
                : 'border-transparent text-[#859db2] hover:text-white'
            }`}
          >
            <Award className="h-3.5 w-3.5" />
            <span>
              {fr ? 'Fins' : 'Endings'} ({progress.unlockedEndings.length}/3)
            </span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {tab === 'docs' && (
            <div className="grid gap-5 md:grid-cols-[270px_1fr]">
              <div className="flex flex-col gap-1.5 max-h-[54vh] overflow-y-auto pr-1">
                {STORY_DOCUMENTS.map((doc) => {
                  const found = knownDocs.has(doc.id);
                  const active = doc.id === selectedDocId;
                  return (
                    <button
                      key={doc.id}
                      type="button"
                      onClick={() => setSelectedDocId(doc.id)}
                      className={`flex items-center justify-between border px-3 py-2.5 text-left text-xs cursor-pointer ${
                        active
                          ? 'border-[#7bc0f2] bg-[#102235] text-white'
                          : 'border-white/10 bg-[#0a111a] text-[#acc2d4] hover:border-white/30'
                      }`}
                    >
                      <span className="truncate pr-2">
                        {found ? (fr ? doc.title : doc.titleEn) : '██████████████'}
                      </span>
                      {!found && <Lock className="h-3.5 w-3.5 shrink-0 text-[#687e91]" />}
                    </button>
                  );
                })}
              </div>

              <div className="border border-white/12 bg-[#0a111a] p-5">
                {activeDocUnlocked ? (
                  <>
                    <div className="font-mono text-[10px] tracking-[0.2em] text-[#7bc0f2] uppercase">
                      {activeDoc.chapterId.toUpperCase()} · {activeDoc.author} · {activeDoc.date}
                    </div>
                    <h3 className="mt-1 font-display text-lg font-bold text-white">
                      {fr ? activeDoc.title : activeDoc.titleEn}
                    </h3>
                    <p className="mt-4 text-sm leading-relaxed text-[#c9dae8]">
                      {fr ? activeDoc.body : activeDoc.bodyEn}
                    </p>
                  </>
                ) : (
                  <div className="flex h-full min-h-[180px] flex-col items-center justify-center text-center text-[#7d95a8]">
                    <Lock className="h-7 w-7 mb-2 text-[#5f768a]" />
                    <p className="text-sm font-semibold text-white">
                      {activeDoc.isPremiumBonus && !entitlements.premiumPass
                        ? fr
                          ? 'Dossier exclusif Premium Pass'
                          : 'Premium Pass Exclusive Dossier'
                        : fr
                          ? 'Document non encore découvert'
                          : 'Document not yet discovered'}
                    </p>
                    <p className="mt-1 text-xs max-w-xs">
                      {fr
                        ? `Explorez le ${activeDoc.chapterId.toUpperCase()} pour récupérer ce dossier.`
                        : `Explore ${activeDoc.chapterId.toUpperCase()} to recover this file.`}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {tab === 'tapes' && (
            <div className="space-y-3">
              {AUDIO_TAPES.map((tape) => {
                const unlocked = knownTapes.has(tape.id) || tape.id === 'tape_ch1_call';
                return (
                  <div
                    key={tape.id}
                    className="border border-white/12 bg-[#0a111a] p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
                  >
                    <div>
                      <div className="font-mono text-[10px] tracking-[0.18em] text-[#7bc0f2] uppercase">
                        {tape.chapterId.toUpperCase()} · {tape.speaker}
                      </div>
                      <h3 className="text-sm font-bold text-white mt-0.5">
                        {unlocked ? (fr ? tape.title : tape.titleEn) : fr ? 'Bande non trouvée' : 'Tape not found'}
                      </h3>
                      {unlocked && (
                        <p className="mt-1.5 text-xs leading-relaxed text-[#b9cde0]">
                          {fr ? tape.transcript : tape.transcriptEn}
                        </p>
                      )}
                    </div>
                    {unlocked && (
                      <button
                        type="button"
                        onClick={() => onPlayTape(tape.id)}
                        className="inline-flex min-h-[40px] shrink-0 items-center gap-2 border border-[#7bc0f2]/50 bg-[#102438] px-4 py-2 text-xs font-bold tracking-wider text-white uppercase hover:bg-[#193755] cursor-pointer"
                      >
                        <Play className="h-3.5 w-3.5 fill-current" />
                        <span>{fr ? 'Écouter' : 'Play'}</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'endings' && (
            <div className="grid gap-3 sm:grid-cols-3">
              {(['ending_a', 'ending_b', 'ending_c'] as EndingId[]).map((eid) => {
                const ed = ENDINGS[eid];
                const unlocked = progress.unlockedEndings.includes(eid);
                return (
                  <div
                    key={eid}
                    className={`border p-4 ${
                      unlocked
                        ? 'border-[#d4a24e]/50 bg-[#171207]'
                        : 'border-white/10 bg-[#0a111a] opacity-70'
                    }`}
                  >
                    <div className="font-mono text-[10px] tracking-[0.2em] text-[#f2cb79] uppercase">
                      {ed.code}
                    </div>
                    <h3 className="mt-1 font-display text-base font-bold text-white">
                      {unlocked ? (fr ? ed.titleFr : ed.titleEn) : '???'}
                    </h3>
                    <p className="mt-2 text-xs leading-relaxed text-[#b8cbd9]">
                      {unlocked
                        ? fr
                          ? ed.subtitleFr
                          : ed.subtitleEn
                        : eid === 'ending_c'
                          ? fr
                            ? 'Trouvez les 3 dossiers secrets au Chapitre 5 pour débloquer la fin secrète.'
                            : 'Recover all 3 classified files in Chapter 5 to unlock the secret ending.'
                          : fr
                            ? 'Terminez le Chapitre 6 pour débloquer cette fin.'
                            : 'Complete Chapter 6 to unlock this ending.'}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
