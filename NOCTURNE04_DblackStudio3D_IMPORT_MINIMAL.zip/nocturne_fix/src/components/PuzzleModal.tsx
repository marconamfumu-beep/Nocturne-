import { useState } from 'react';
import { Delete, ShieldCheck, X } from 'lucide-react';
import type { Language, PuzzleDefinition } from '../types/game';

interface PuzzleModalProps {
  puzzle: PuzzleDefinition;
  language: Language;
  onSolve: (code: string) => boolean;
  onCancel: () => void;
}

export function PuzzleModal({ puzzle, language, onSolve, onCancel }: PuzzleModalProps) {
  const [input, setInput] = useState(puzzle.kind === 'frequency' ? '360' : '');
  const [errorMsg, setErrorMsg] = useState(false);

  const fr = language === 'fr';

  const handleSubmit = (candidate = input) => {
    const ok = onSolve(candidate);
    if (!ok) {
      setErrorMsg(true);
      setTimeout(() => setErrorMsg(false), 1200);
    }
  };

  const pushDigit = (digit: string) => {
    if (input.length >= 4) return;
    const next = input + digit;
    setInput(next);
    if (next.length === puzzle.solutionCode.length) {
      handleSubmit(next);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#030509]/85 p-4 backdrop-blur-sm">
      <div className="w-full max-w-md border border-[#7bc0f2]/40 bg-[#070c14]/98 p-6 shadow-[0_24px_60px_rgba(0,0,0,0.9)]">
        <div className="flex items-start justify-between border-b border-white/10 pb-3">
          <div>
            <div className="font-mono text-[10px] tracking-[0.22em] text-[#7bc0f2] uppercase">
              {puzzle.chapterId.toUpperCase()} ·{' '}
              {puzzle.kind === 'keypad'
                ? 'DIGICODE'
                : puzzle.kind === 'circuit'
                  ? fr
                    ? 'CIRCUIT ÉLECTRIQUE'
                    : 'CIRCUIT SEQUENCE'
                  : 'EEG RESONATOR'}
            </div>
            <h2 className="font-display text-lg font-bold text-white mt-0.5">
              {fr ? puzzle.title : puzzle.titleEn}
            </h2>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="border border-white/15 bg-[#0e1724] p-2 text-[#b8ccde] hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-3 text-xs leading-relaxed text-[#bdd0e0]">
          {fr ? puzzle.prompt : puzzle.promptEn}
        </p>

        <div className="mt-3 border border-white/10 bg-[#0a121d] px-3 py-2 text-[11px] text-[#8ab4d6]">
          <span className="font-semibold text-[#f2cb79]">{fr ? 'Indice : ' : 'Hint: '}</span>
          {fr ? puzzle.clueHint : puzzle.clueHintEn}
        </div>

        {/* Display readout */}
        <div
          className={`mt-4 border px-4 py-3 text-center font-mono text-2xl font-bold tracking-[0.35em] ${
            errorMsg
              ? 'border-[#e14b56] bg-[#2a090d] text-[#ff8f97]'
              : 'border-[#7bc0f2]/35 bg-[#04080e] text-[#9ad4ff]'
          }`}
        >
          {puzzle.kind === 'frequency'
            ? `${input} Hz`
            : input.padEnd(puzzle.solutionCode.length, '_')}
        </div>

        {puzzle.kind === 'keypad' && (
          <div className="mt-4 grid grid-cols-3 gap-2">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => pushDigit(d)}
                className="min-h-[44px] border border-white/15 bg-[#0d1622] font-mono text-base font-bold text-white hover:border-[#7bc0f2] hover:bg-[#152538] cursor-pointer"
              >
                {d}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setInput('')}
              className="flex min-h-[44px] items-center justify-center border border-white/15 bg-[#121821] text-xs font-bold text-[#e14b56] cursor-pointer"
            >
              <Delete className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => pushDigit('0')}
              className="min-h-[44px] border border-white/15 bg-[#0d1622] font-mono text-base font-bold text-white hover:border-[#7bc0f2] hover:bg-[#152538] cursor-pointer"
            >
              0
            </button>
            <button
              type="button"
              onClick={() => handleSubmit(input)}
              className="flex min-h-[44px] items-center justify-center border border-[#4fe09b]/50 bg-[#0d271c] text-xs font-bold text-[#72f0b5] hover:bg-[#143a29] cursor-pointer"
            >
              OK
            </button>
          </div>
        )}

        {puzzle.kind === 'circuit' && (
          <div className="mt-4 space-y-3">
            <div className="grid grid-cols-4 gap-2">
              {['1', '2', '3', '4'].map((b) => {
                const used = input.includes(b);
                return (
                  <button
                    key={b}
                    type="button"
                    disabled={used}
                    onClick={() => pushDigit(b)}
                    className={`min-h-[48px] border font-mono text-base font-bold cursor-pointer ${
                      used
                        ? 'border-[#4fe09b] bg-[#0e2d20] text-[#72f0b5]'
                        : 'border-white/20 bg-[#0d1622] text-white hover:border-[#7bc0f2]'
                    }`}
                  >
                    #{b}
                  </button>
                );
              })}
            </div>
            <button
              type="button"
              onClick={() => setInput('')}
              className="w-full border border-white/15 bg-[#0c141f] py-2 text-xs font-semibold text-[#9eb5c7] hover:text-white cursor-pointer"
            >
              {fr ? 'Réinitialiser la séquence' : 'Reset Sequence'}
            </button>
          </div>
        )}

        {puzzle.kind === 'frequency' && (
          <div className="mt-4 space-y-4">
            <input
              type="range"
              min={320}
              max={480}
              step={4}
              value={Number(input)}
              onChange={(e) => setInput(e.target.value)}
              className="w-full accent-[#4fe09b]"
            />
            <button
              type="button"
              onClick={() => handleSubmit(input)}
              className="flex w-full min-h-[44px] items-center justify-center gap-2 border border-[#4fe09b]/50 bg-[#0e2a1e] py-2.5 text-xs font-bold tracking-wider text-[#8ff5c4] uppercase hover:bg-[#153e2c] cursor-pointer"
            >
              <ShieldCheck className="h-4 w-4" />
              <span>{fr ? 'Verrouiller la fréquence' : 'Lock Frequency'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
