import { useState } from 'react';
import {
  BatteryCharging,
  Crosshair,
  Flame,
  HeartPulse,
  KeyRound,
  Save,
  ShieldAlert,
  Wine,
  X,
} from 'lucide-react';
import { t } from '../i18n/translations';
import type { HudSnapshot, Language, SaveSlotData } from '../types/game';
import type { HospitalEngineHandle } from './HospitalViewport';

interface InventoryModalProps {
  hud: HudSnapshot;
  language: Language;
  engineRef: React.RefObject<HospitalEngineHandle | null>;
}

export function InventoryModal({ hud, language, engineRef }: InventoryModalProps) {
  const [savedSlotMsg, setSavedSlotMsg] = useState<string | null>(null);
  const fr = language === 'fr';
  const copy = t(language);

  const secretCount = ['doc_ch5_secret_1', 'doc_ch5_secret_2', 'doc_ch5_secret_3'].filter((id) =>
    hud.discoveredDocIds.includes(id),
  ).length;

  const handleSaveSlot = (slotId: SaveSlotData['slotId']) => {
    const ok = engineRef.current?.saveToSlot(slotId);
    if (ok) {
      setSavedSlotMsg(
        `${copy.savedSuccess} (${slotId.replace('slot', fr ? 'Empl. ' : 'Slot ')})`,
      );
      setTimeout(() => setSavedSlotMsg(null), 2600);
    }
  };

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-[#030509]/85 p-2 sm:p-4 backdrop-blur-sm">
      <div className="w-full max-w-3xl max-h-[min(90dvh,860px)] overflow-y-auto overscroll-contain border border-[#8db4d4]/30 bg-[#070c14]/96 p-3 sm:p-6 shadow-[0_24px_70px_rgba(0,0,0,0.9)]">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div>
            <div className="min-w-0 break-words font-mono text-[9px] sm:text-[10px] tracking-[0.16em] sm:tracking-[0.24em] text-[#7bc0f2] uppercase">
              {hud.chapterLabel} · {hud.chapterTitle}
            </div>
            <h2 className="font-display text-lg sm:text-xl font-bold tracking-wider text-white uppercase mt-0.5">
              {copy.inventory}
            </h2>
          </div>
          <button
            type="button"
            onClick={() => engineRef.current?.resumeGame()}
            className="flex min-h-[40px] items-center gap-1.5 border border-white/15 bg-[#0e1724] px-3 py-1.5 text-xs font-semibold text-[#d2e2f0] hover:border-white/40 cursor-pointer"
          >
            <X className="h-4 w-4" />
            <span>{copy.resume}</span>
          </button>
        </div>

        {/* Vital Stats Bar */}
        <div className="mt-3 sm:mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3 sm:gap-3">
          <div className="border border-white/10 bg-[#0b121c] p-3">
            <div className="flex items-center justify-between text-xs text-[#b7cad9]">
              <span>{copy.health}</span>
              <span className="font-mono font-bold text-white">
                {hud.health}/{hud.maxHealth}
              </span>
            </div>
            <div className="mt-2 h-1.5 w-full bg-[#16212d]">
              <div
                className="h-full bg-[#e14b56]"
                style={{ width: `${Math.max(0, Math.min(100, Math.round((hud.health / Math.max(1, hud.maxHealth)) * 100)))}%` }}
              />
            </div>
          </div>

          <div className="border border-white/10 bg-[#0b121c] p-3">
            <div className="flex items-center justify-between text-xs text-[#b7cad9]">
              <span>{copy.battery}</span>
              <span className="font-mono font-bold text-white">{Math.round(hud.battery * 100)}%</span>
            </div>
            <div className="mt-2 h-1.5 w-full bg-[#16212d]">
              <div
                className="h-full bg-[#63a5d8]"
                style={{ width: `${Math.max(0, Math.min(100, Math.round(hud.battery * 100)))}%` }}
              />
            </div>
          </div>

          <div className="border border-white/10 bg-[#0b121c] p-3">
            <div className="flex items-center justify-between text-xs text-[#b7cad9]">
              <span>{fr ? 'Dossiers secrets (Fin C)' : 'Secret Files (Ending C)'}</span>
              <span className="font-mono font-bold text-[#f2cb79]">{secretCount}/3</span>
            </div>
            <div className="mt-2 flex gap-1">
              {[0, 1, 2].map((idx) => (
                <div
                  key={idx}
                  className={`h-1.5 flex-1 ${idx < secretCount ? 'bg-[#d4a24e]' : 'bg-[#16212d]'}`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Gear Grid */}
        <div className="mt-3 sm:mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2 sm:gap-3">
          {/* Weapon */}
          <div className="flex flex-col justify-between border border-white/12 bg-[#0a111a] p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <Crosshair className="h-4 w-4 text-[#7bc0f2]" />
                <div>
                  <div className="text-sm font-bold text-white">
                    {fr ? 'Pistolet de service 9mm' : '9mm Service Pistol'}
                  </div>
                  <div className="text-xs text-[#8fa7ba]">
                    {hud.hasPistol
                      ? `${hud.pistolMag} / ${hud.pistolReserve} ${fr ? 'cartouches' : 'rounds'}`
                      : fr
                        ? 'Non récupéré (Poste de Soins)'
                        : 'Not acquired (Nursing Station)'}
                  </div>
                </div>
              </div>
            </div>
            {hud.hasPistol && (
              <button
                type="button"
                onClick={() => engineRef.current?.reloadWeapon()}
                disabled={hud.pistolReserve <= 0 || hud.pistolMag >= hud.pistolMagSize}
                className="mt-3 border border-[#7bc0f2]/45 bg-[#102336] py-2 text-xs font-bold tracking-wider text-white uppercase disabled:opacity-40 cursor-pointer"
              >
                {copy.reload}
              </button>
            )}
          </div>

          {/* Medkits */}
          <div className="flex flex-col justify-between border border-white/12 bg-[#0a111a] p-4">
            <div className="flex items-center gap-2.5">
              <HeartPulse className="h-4 w-4 text-[#e14b56]" />
              <div>
                <div className="text-sm font-bold text-white">
                  {fr ? 'Trousse médicale' : 'Medical Kit'} × {hud.medkits}
                </div>
                <div className="text-xs text-[#8fa7ba]">
                  {fr ? 'Restaure +48 PV immédiatement.' : 'Restores +48 HP immediately.'}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => engineRef.current?.useMedkit()}
              disabled={hud.medkits <= 0 || hud.health >= hud.maxHealth}
              className="mt-3 border border-[#e14b56]/50 bg-[#290c11] py-2 text-xs font-bold tracking-wider text-[#ffb8be] uppercase disabled:opacity-40 cursor-pointer"
            >
              {copy.useMedkit}
            </button>
          </div>

          {/* Batteries */}
          <div className="flex flex-col justify-between border border-white/12 bg-[#0a111a] p-4">
            <div className="flex items-center gap-2.5">
              <BatteryCharging className="h-4 w-4 text-[#63a5d8]" />
              <div>
                <div className="text-sm font-bold text-white">
                  {fr ? 'Piles Lithium' : 'Lithium Batteries'} × {hud.batteriesCount}
                </div>
                <div className="text-xs text-[#8fa7ba]">
                  {fr ? 'Recharge +55% de batterie torche.' : 'Recharges +55% flashlight battery.'}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => engineRef.current?.rechargeBattery()}
              disabled={hud.batteriesCount <= 0 || hud.battery >= 0.98}
              className="mt-3 border border-[#63a5d8]/50 bg-[#0e2234] py-2 text-xs font-bold tracking-wider text-[#b7e0ff] uppercase disabled:opacity-40 cursor-pointer"
            >
              {copy.useBattery}
            </button>
          </div>

          {/* Defense & Distraction */}
          <div className="flex flex-col justify-between border border-white/12 bg-[#0a111a] p-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-white">
                <span className="flex items-center gap-2">
                  <Flame className="h-4 w-4 text-[#f2cb79]" />
                  {fr ? 'Fusées défensives [X]' : 'Defense Flares [X]'}
                </span>
                <span className="font-mono font-bold text-[#f2cb79]">{hud.flaresCount}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-white">
                <span className="flex items-center gap-2">
                  <Wine className="h-4 w-4 text-[#5ee6a8]" />
                  {fr ? 'Bouteilles en verre [G]' : 'Glass Bottles [G]'}
                </span>
                <span className="font-mono font-bold text-[#5ee6a8]">
                  {hud.bottlesCount}/{hud.maxBottles}
                </span>
              </div>
            </div>
            <p className="mt-3 text-[11px] text-[#859db0]">
              {fr
                ? 'Les fusées étourdissent le Patient 04 à bout portant. Les bouteilles créent un leurre sonore.'
                : 'Flares stun Patient 04 at close range. Bottles lure him away with glass noise.'}
            </p>
          </div>
        </div>

        {/* Keys & Quest Items */}
        <div className="mt-4 border border-white/10 bg-[#0a111a] p-3.5">
          <div className="mb-2 flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-[#7bc0f2] uppercase">
            <KeyRound className="h-3.5 w-3.5" />
            <span>{fr ? 'Clés & Cartes d’accès' : 'Keys & Access Cards'}</span>
          </div>
          {hud.keys.length === 0 ? (
            <div className="text-xs text-[#708597]">
              {fr ? 'Aucune clé pour le moment.' : 'No keys collected yet.'}
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {hud.keys.map((k) => (
                <span
                  key={k.id}
                  className="inline-flex items-center gap-1.5 border border-[#d4a24e]/50 bg-[#241a08] px-2.5 py-1 text-xs font-semibold text-[#f3ce82]"
                >
                  <KeyRound className="h-3 w-3" />
                  {k.label}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Manual Save Slots */}
        <div className="mt-4 border-t border-white/10 pt-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="flex items-center gap-2 font-mono text-[11px] text-[#9eb5c7] uppercase">
              <Save className="h-3.5 w-3.5 text-[#7bc0f2]" />
              {fr ? 'Sauvegarde manuelle' : 'Manual Save Slots'}
            </span>
            {savedSlotMsg && (
              <span className="font-mono text-xs text-[#5ee6a8] flex items-center gap-1">
                <ShieldAlert className="h-3.5 w-3.5" />
                {savedSlotMsg}
              </span>
            )}
          </div>
          <div className="mt-2.5 grid grid-cols-1 min-[380px]:grid-cols-3 gap-2">
            {(['slot1', 'slot2', 'slot3'] as SaveSlotData['slotId'][]).map((sid, i) => (
              <button
                key={sid}
                type="button"
                onClick={() => handleSaveSlot(sid)}
                className="min-h-[40px] border border-white/15 bg-[#0c1622] px-3 py-2 text-xs font-semibold text-[#cfe0ee] hover:border-[#7bc0f2]/60 hover:text-white cursor-pointer"
              >
                {fr ? `Sauver Empl. ${i + 1}` : `Save Slot ${i + 1}`}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
