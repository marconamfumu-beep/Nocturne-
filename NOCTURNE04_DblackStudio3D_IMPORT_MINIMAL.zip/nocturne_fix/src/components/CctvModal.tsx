import { useEffect, useRef, useState } from 'react';
import { Camera, Radio, X } from 'lucide-react';
import { CCTV_FEEDS } from '../story/chaptersData';
import type { ChapterId, Language } from '../types/game';

interface CctvModalProps {
  chapterId: ChapterId;
  language: Language;
  onClose: () => void;
}

export function CctvModal({ chapterId, language, onClose }: CctvModalProps) {
  const chapterFeeds = CCTV_FEEDS.filter((f) => f.chapterId === chapterId);
  const feeds = chapterFeeds.length > 0 ? chapterFeeds : CCTV_FEEDS;
  const [selectedIndex, setSelectedIndex] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fr = language === 'fr';

  const activeFeed = feeds[selectedIndex] ?? feeds[0];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf = 0;
    let tick = 0;
    const draw = () => {
      tick += 0.04;
      const w = canvas.width;
      const h = canvas.height;
      ctx.fillStyle = '#040a07';
      ctx.fillRect(0, 0, w, h);

      // Perspective corridor lines
      ctx.strokeStyle = 'rgba(72, 214, 146, 0.25)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(w * 0.26, h * 0.2, w * 0.48, h * 0.56);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(w * 0.26, h * 0.2);
      ctx.moveTo(w, 0);
      ctx.lineTo(w * 0.74, h * 0.2);
      ctx.moveTo(0, h);
      ctx.lineTo(w * 0.26, h * 0.76);
      ctx.moveTo(w, h);
      ctx.lineTo(w * 0.74, h * 0.76);
      ctx.stroke();

      // Floor tiles
      ctx.strokeStyle = 'rgba(72, 214, 146, 0.14)';
      for (let i = 1; i <= 5; i++) {
        const y = h * 0.76 + ((h * 0.24) * i) / 5;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Monster silhouette pacing on feed if active
      if (activeFeed.monsterVisible) {
        const mx = w * 0.5 + Math.sin(tick * 1.1) * w * 0.14;
        const my = h * 0.54 + Math.abs(Math.sin(tick * 3)) * 3;
        ctx.fillStyle = 'rgba(130, 255, 190, 0.55)';
        ctx.beginPath();
        ctx.ellipse(mx, my - 26, 12, 16, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillRect(mx - 15, my - 8, 30, 52);
        // Eyes
        ctx.fillStyle = '#ff4d57';
        ctx.fillRect(mx - 6, my - 28, 3, 3);
        ctx.fillRect(mx + 3, my - 28, 3, 3);
      }

      // Scanlines & static grain
      ctx.fillStyle = 'rgba(0,0,0,0.28)';
      for (let y = 0; y < h; y += 4) {
        ctx.fillRect(0, y, w, 1.5);
      }
      ctx.fillStyle = 'rgba(160, 255, 210, 0.08)';
      for (let n = 0; n < 45; n++) {
        ctx.fillRect(Math.random() * w, Math.random() * h, 2, 2);
      }

      raf = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(raf);
  }, [activeFeed]);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#020508]/88 p-4 backdrop-blur-sm">
      <div className="w-full max-w-2xl border border-[#4fe09b]/40 bg-[#050a08]/98 p-5 shadow-[0_24px_70px_rgba(0,0,0,0.95)]">
        <div className="flex items-center justify-between border-b border-[#4fe09b]/20 pb-3">
          <div className="flex items-center gap-2.5">
            <Camera className="h-4 w-4 text-[#5ee6a8]" />
            <span className="font-mono text-xs font-bold tracking-[0.2em] text-[#8ff5c4] uppercase">
              KAMBALA CCTV · {activeFeed.camCode}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="border border-white/15 bg-[#0c1411] p-2 text-[#b8d4c4] hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="relative mt-4 border border-[#4fe09b]/35 bg-black">
          <canvas ref={canvasRef} width={640} height={320} className="w-full h-auto block" />
          <div className="absolute left-3 top-3 flex items-center gap-2 font-mono text-[11px] text-[#72f0b5]">
            <Radio className="h-3.5 w-3.5 animate-pulse text-[#ff5964]" />
            <span>REC · 02:17:44</span>
          </div>
          <div className="absolute bottom-3 left-3 bg-black/75 px-2.5 py-1 font-mono text-xs text-[#9bf7e6]">
            {fr ? activeFeed.statusText : activeFeed.statusTextEn}
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border border-white/10 bg-[#08100c] px-3.5 py-2.5">
          <div>
            <div className="font-mono text-[10px] text-[#72f0b5] uppercase">
              {fr ? activeFeed.location : activeFeed.locationEn}
            </div>
            <div className="text-xs text-[#d6ede0] mt-0.5">
              {fr ? activeFeed.hint : activeFeed.hintEn}
            </div>
          </div>
          <div className="flex gap-1.5">
            {feeds.map((f, idx) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setSelectedIndex(idx)}
                className={`border px-3 py-1.5 font-mono text-xs font-bold cursor-pointer ${
                  idx === selectedIndex
                    ? 'border-[#5ee6a8] bg-[#133827] text-white'
                    : 'border-white/15 bg-[#0a130f] text-[#8eb29f] hover:text-white'
                }`}
              >
                CAM-0{idx + 1}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
