import { useEffect, useRef, useState } from 'react';
import {
  BatteryCharging,
  BookOpen,
  Briefcase,
  Camera,
  ChevronDown,
  ChevronUp,
  Crosshair,
  Eye,
  EyeOff,
  Flame,
  Flashlight,
  HeartPulse,
  Home,
  KeyRound,
  Pause,
  Play,
  RotateCcw,
  Save,
  Skull,
  Volume2,
  VolumeX,
  Wine,
  Zap,
} from 'lucide-react';
import { t } from '../i18n/translations';
import type { HudSnapshot, Language, RenderProfileMode, SaveSlotData } from '../types/game';
import type { HospitalEngineHandle } from './HospitalViewport';

interface GameHudProps {
  hud: HudSnapshot;
  language: Language;
  engineRef: React.RefObject<HospitalEngineHandle | null>;
  onOpenCodex: () => void;
}

const PROFILE_OPTIONS: { id: RenderProfileMode; short: string; label: string }[] = [
  { id: 'auto', short: 'AUTO', label: 'AUTO ADAPTATIF' },
  { id: 'console_ultra', short: 'ULTRA', label: 'CONSOLE ULTRA' },
  { id: 'mobile_landscape', short: 'MOBILE', label: 'MOBILE' },
  { id: 'performance', short: 'PERF', label: 'PERFORMANCE' },
];

function formatTimer(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.max(0, Math.floor(seconds % 60));
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function GameHud({ hud, language, engineRef, onOpenCodex }: GameHudProps) {
  const [dockOpen, setDockOpen] = useState(false);
  const [forceTouchUi, setForceTouchUi] = useState(false);
  const [pauseSavedMsg, setPauseSavedMsg] = useState<string | null>(null);

  const joyRef = useRef<HTMLDivElement | null>(null);
  const stickRef = useRef<HTMLDivElement | null>(null);
  const lookTouchRef = useRef<{ id: number; x: number; y: number } | null>(null);

  const fr = language === 'fr';
  const copy = t(language);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'F8' && hud.phase === 'playing') {
        setDockOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [hud.phase]);

  if (
    hud.phase === 'title' ||
    hud.phase === 'intro_cinematic' ||
    hud.phase === 'chapter_transition' ||
    hud.phase === 'ending_cinematic' ||
    hud.phase === 'credits' ||
    hud.phase === 'shop'
  ) {
    return null;
  }

  const showTouchControls = hud.isTouchDevice || forceTouchUi;

  const updateJoystick = (clientX: number, clientY: number) => {
    const el = joyRef.current;
    const stick = stickRef.current;
    if (!el || !stick) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.36;
    let dx = (clientX - cx) / maxR;
    let dy = (clientY - cy) / maxR;
    const len = Math.hypot(dx, dy);
    if (len > 1) {
      dx /= len;
      dy /= len;
    }
    stick.style.transform = `translate(${dx * maxR * 0.72}px, ${dy * maxR * 0.72}px)`;
    engineRef.current?.setJoystick(dx, dy);
  };

  const resetJoystick = () => {
    if (stickRef.current) {
      stickRef.current.style.transform = 'translate(0px, 0px)';
    }
    engineRef.current?.setJoystick(0, 0);
  };

  const handlePauseSave = (slotId: SaveSlotData['slotId']) => {
    if (engineRef.current?.saveToSlot(slotId)) {
      setPauseSavedMsg(copy.savedSuccess);
      setTimeout(() => setPauseSavedMsg(null), 2200);
    }
  };

  const healthPct = Math.max(0, Math.min(100, Math.round((hud.health / hud.maxHealth) * 100)));
  const batteryPct = Math.max(0, Math.min(100, Math.round(hud.battery * 100)));

  return (
    <div className="fixed inset-0 z-10 pointer-events-none select-none">
      {/* Premium Visual Filters (VHS / Night Vision) */}
      {hud.entitlements.premiumPass && hud.visualFilter === 'vhs' && (
        <div className="vhs-scanlines fixed inset-0 pointer-events-none" />
      )}
      {hud.entitlements.premiumPass && hud.visualFilter === 'night_vision' && (
        <div className="nightvision-tint fixed inset-0 pointer-events-none" />
      )}

      {/* Hideout vignette */}
      {hud.phase === 'playing' && hud.isHiding && (
        <div
          className="fixed inset-0 pointer-events-none"
          style={{
            background:
              hud.hideoutKind === 'locker'
                ? 'radial-gradient(ellipse at center, transparent 42%, rgba(2, 4, 8, 0.85) 100%)'
                : 'linear-gradient(to bottom, rgba(2, 4, 8, 0.88) 0%, transparent 28%, transparent 74%, rgba(2, 4, 8, 0.8) 100%)',
          }}
        />
      )}

      {/* Danger Pulse */}
      {hud.phase === 'playing' && (hud.dangerLevel > 0.08 || hud.health < 35) && (
        <div
          className="fixed inset-0 pointer-events-none transition-opacity duration-150"
          style={{
            opacity: Math.max(
              hud.health < 35 ? 0.38 : 0,
              hud.isSoftwareGl
                ? Math.min(0.86, hud.dangerLevel * 0.88)
                : Math.min(0.32, hud.dangerLevel * 0.34),
            ),
            background:
              'radial-gradient(circle at center, transparent 46%, rgba(135, 10, 16, 0.62) 100%)',
          }}
        />
      )}

      {/* Touch Look Zone */}
      {hud.phase === 'playing' && showTouchControls && (
        <div
          className="fixed inset-y-0 right-0 left-[36%] pointer-events-auto"
          style={{ touchAction: 'none', overscrollBehavior: 'none' }}
          onPointerDown={(e) => {
            if (e.pointerType === 'mouse' && !forceTouchUi) return;
            // Capture the finger so camera control continues even when it slides
            // outside the look zone (common on iOS Safari).
            try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* Safari fallback */ }
            lookTouchRef.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
            e.preventDefault();
          }}
          onPointerMove={(e) => {
            if (lookTouchRef.current && lookTouchRef.current.id === e.pointerId) {
              const dx = e.clientX - lookTouchRef.current.x;
              const dy = e.clientY - lookTouchRef.current.y;
              lookTouchRef.current.x = e.clientX;
              lookTouchRef.current.y = e.clientY;
              engineRef.current?.applyLookDelta(dx, dy);
              e.preventDefault();
            }
          }}
          onPointerUp={(e) => {
            if (lookTouchRef.current?.id === e.pointerId) lookTouchRef.current = null;
            try { if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* Safari fallback */ }
          }}
          onPointerCancel={(e) => {
            if (lookTouchRef.current?.id === e.pointerId) lookTouchRef.current = null;
          }}
          onLostPointerCapture={(e) => {
            if (lookTouchRef.current?.id === e.pointerId) lookTouchRef.current = null;
          }}
        />
      )}

      {/* Top HUD Bar */}
      <div className="absolute top-[max(0.75rem,env(safe-area-inset-top))] left-[max(0.875rem,env(safe-area-inset-left))] right-[max(0.875rem,env(safe-area-inset-right))] flex items-start justify-between gap-3">
        {/* Left: Chapter Objective & Vitals */}
        <div className="w-[min(320px,68vw)] border border-[#8db4d4]/25 bg-[#060b12]/90 px-3.5 py-2.5">
          <div className="flex items-center justify-between gap-2">
            <span className="font-mono text-[10px] font-bold tracking-[0.2em] text-[#7bc0f2] uppercase">
              {hud.chapterLabel}
            </span>
            <span className="font-mono text-[11px] font-bold text-[#dcecf8]">
              {hud.cluesCollected}/{hud.totalClues}
            </span>
          </div>
          <div className="mt-0.5 text-xs font-medium text-[#d4e4f0] leading-snug">
            {hud.objectiveText}
          </div>

          {/* Health, Stamina & Battery bars */}
          <div className="mt-2.5 grid grid-cols-2 gap-2">
            <div>
              <div className="flex justify-between font-mono text-[9px] text-[#9bb4c7] uppercase">
                <span>{copy.health}</span>
                <span className={healthPct < 35 ? 'text-[#ff7882]' : 'text-white'}>{healthPct}%</span>
              </div>
              <div className="mt-0.5 h-1 bg-[#14202b]">
                <div
                  className="h-full bg-[#e14b56] transition-all duration-150"
                  style={{ width: `${healthPct}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between font-mono text-[9px] text-[#9bb4c7] uppercase">
                <span>{copy.battery}</span>
                <span className={batteryPct < 20 ? 'text-[#f2cb79]' : 'text-white'}>
                  {batteryPct}%
                </span>
              </div>
              <div className="mt-0.5 h-1 bg-[#14202b]">
                <div
                  className="h-full bg-[#63a5d8] transition-all duration-150"
                  style={{ width: `${batteryPct}%` }}
                />
              </div>
            </div>
          </div>

          {hud.stamina < 0.98 && (
            <div className="mt-1.5 h-0.5 w-full bg-[#15202b]">
              <div
                className="h-full bg-[#8ff5c4] transition-all duration-100"
                style={{ width: `${Math.round(hud.stamina * 100)}%` }}
              />
            </div>
          )}

          {/* Compact Tactical Strip */}
          <div className="mt-2 flex flex-wrap items-center gap-1.5 font-mono text-[10px]">
            {hud.hasPistol && (
              <span className="inline-flex items-center gap-1 border border-[#7bc0f2]/40 bg-[#0d1f30] px-1.5 py-0.5 text-[#d9efff]">
                <Crosshair className="h-2.5 w-2.5" />
                {hud.isReloading ? '...' : `${hud.pistolMag}/${hud.pistolReserve}`}
              </span>
            )}
            <span className="inline-flex items-center gap-1 border border-white/15 bg-[#0f1722] px-1.5 py-0.5 text-[#ffb8be]">
              <HeartPulse className="h-2.5 w-2.5" />
              {hud.medkits}
            </span>
            <span className="inline-flex items-center gap-1 border border-white/15 bg-[#0f1722] px-1.5 py-0.5 text-[#9ed4ff]">
              <BatteryCharging className="h-2.5 w-2.5" />
              {hud.batteriesCount}
            </span>
            <span className="inline-flex items-center gap-1 border border-white/15 bg-[#0f1722] px-1.5 py-0.5 text-[#f2cb79]">
              <Flame className="h-2.5 w-2.5" />
              {hud.flaresCount}
            </span>
            <span className="inline-flex items-center gap-1 border border-white/15 bg-[#0f1722] px-1.5 py-0.5 text-[#8ff5c4]">
              <Wine className="h-2.5 w-2.5" />
              {hud.bottlesCount}
            </span>
            {hud.keys.map((k) => (
              <span
                key={k.id}
                className="inline-flex items-center gap-1 border border-[#d4a24e]/50 bg-[#241a08] px-1.5 py-0.5 text-[#f5d388]"
              >
                <KeyRound className="h-2.5 w-2.5" />
                {k.label}
              </span>
            ))}
            {hud.generatorRestored && (
              <span className="inline-flex items-center gap-1 border border-[#4fe09b]/50 bg-[#0c291d] px-1.5 py-0.5 text-[#72f0b5]">
                <Zap className="h-2.5 w-2.5" />
                ON
              </span>
            )}
            {hud.isHiding ? (
              <span className="inline-flex items-center gap-1 border border-[#5be0c8]/60 bg-[#0f2b36] px-1.5 py-0.5 font-bold text-[#9bf7e6]">
                <EyeOff className="h-2.5 w-2.5" />
                {copy.hidden.toUpperCase()}
              </span>
            ) : (
              hud.isHidden && (
                <span className="inline-flex items-center gap-1 border border-[#6cb7ed]/45 bg-[#0e2233] px-1.5 py-0.5 text-[#9ed2fa]">
                  <EyeOff className="h-2.5 w-2.5" />
                  {copy.stealth.toUpperCase()}
                </span>
              )
            )}
          </div>
        </div>

        {/* Right: Danger / Self-destruct + Quick Actions */}
        <div className="flex flex-col items-end gap-2 pointer-events-auto">
          <div className="flex items-center gap-1.5">
            {hud.selfDestructActive && (
              <div className="border border-[#ff4d57] bg-[#3b090d]/95 px-3 py-1.5 font-mono text-xs font-bold tracking-wider text-[#ffd3d6] animate-pulse">
                {copy.selfDestruct} · {formatTimer(hud.selfDestructTimer)}
              </div>
            )}

            {hud.monsterChasing && (
              <div className="border border-[#ff4d57]/80 bg-[#3b090d]/92 px-2.5 py-1.5 font-mono text-[10px] font-bold tracking-[0.2em] text-[#ffb8bc] animate-pulse">
                {copy.chaseAlert}
              </div>
            )}

            <button
              type="button"
              onClick={() => engineRef.current?.togglePerspective()}
              title={copy.cameraToggle}
              className="hidden sm:flex min-h-[38px] items-center gap-1.5 border border-[#8db4d4]/25 bg-[#060b12]/88 px-2.5 py-1.5 font-mono text-[10px] font-semibold text-[#d4e4f0] hover:border-[#7bc0f2] cursor-pointer"
            >
              <Eye className="h-3.5 w-3.5 text-[#7bc0f2]" />
              <span>{hud.perspective === 'first_person' ? '1P' : '3P'}</span>
            </button>

            <button
              type="button"
              onClick={() => engineRef.current?.setPhase('inventory')}
              title={copy.openInventory}
              className="hidden sm:flex min-h-[38px] items-center gap-1.5 border border-[#8db4d4]/25 bg-[#060b12]/88 px-2.5 py-1.5 text-xs text-[#d4e4f0] hover:border-[#7bc0f2] cursor-pointer"
            >
              <Briefcase className="h-3.5 w-3.5" />
            </button>

            <button
              type="button"
              onClick={() => engineRef.current?.toggleMute()}
              title="Audio (M)"
              className="flex min-h-[38px] min-w-[38px] items-center justify-center border border-[#8db4d4]/25 bg-[#060b12]/88 text-[#d4e4f0] hover:border-[#7bc0f2] cursor-pointer"
            >
              {hud.muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>

            <button
              type="button"
              onClick={() => engineRef.current?.pauseGame()}
              title="Pause (Échap)"
              className="flex min-h-[38px] min-w-[38px] items-center justify-center border border-[#8db4d4]/25 bg-[#060b12]/88 text-[#d4e4f0] hover:border-[#7bc0f2] cursor-pointer"
            >
              <Pause className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Center Crosshair & Interact Prompt */}
      {hud.phase === 'playing' && (
        <div className="fixed inset-0 flex flex-col items-center justify-center pointer-events-none">
          {!hud.isHiding && (
            <div className="h-1.5 w-1.5 rounded-full bg-white/85 shadow-[0_0_6px_#000]" />
          )}
          {hud.isHiding && hud.hidingSpotLabel && (
            <div className="mb-3 border border-[#5be0c8]/40 bg-[#060b12]/85 px-3 py-1 font-mono text-[10px] font-semibold tracking-[0.18em] text-[#9bf7e6] uppercase">
              {hud.hidingSpotLabel}
            </div>
          )}
          {hud.promptText && (
            <button
              type="button"
              onClick={() => engineRef.current?.triggerInteract()}
              className={`pointer-events-auto ${
                hud.isHiding ? 'mt-2' : 'mt-5'
              } min-h-[40px] border border-[#72bdf2]/65 bg-[#060b12]/92 px-4 py-1.5 text-xs font-semibold tracking-wider text-[#eef6fc] shadow-[0_4px_16px_rgba(0,0,0,0.8)] cursor-pointer`}
            >
              {hud.isTouchDevice ? hud.promptText : `[E] ${hud.promptText}`}
            </button>
          )}
        </div>
      )}

      {/* Clue / Story Note Toast */}
      {hud.phase === 'playing' && hud.activeNote && (
        <div className="pointer-events-auto absolute top-24 left-1/2 w-[min(460px,92vw)] -translate-x-1/2 border border-[#73b8ea]/45 bg-[#060b12]/95 px-4 py-3 shadow-[0_12px_32px_rgba(0,0,0,0.8)]">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="font-mono text-[10px] font-semibold tracking-[0.2em] text-[#7bc0f2] uppercase">
                {hud.activeNote.subtitle}
              </div>
              <div className="text-xs font-bold tracking-wider text-white mt-0.5">
                {hud.activeNote.title}
              </div>
            </div>
            <button
              type="button"
              onClick={() => engineRef.current?.dismissNote()}
              className="border border-white/15 px-2 py-0.5 text-[10px] text-[#8ba5ba] hover:text-white cursor-pointer"
            >
              OK
            </button>
          </div>
          <p className="mt-1.5 text-xs leading-relaxed text-[#c6d8e6]">{hud.activeNote.body}</p>
        </div>
      )}

      {/* Subtitles Bar */}
      {hud.phase === 'playing' && hud.subtitleText && (
        <div className="pointer-events-none absolute bottom-20 left-1/2 w-[min(600px,90vw)] -translate-x-1/2 border border-white/12 bg-[#04070c]/88 px-4 py-2.5 text-center">
          {hud.subtitleSpeaker && (
            <div className="font-mono text-[10px] tracking-[0.2em] text-[#7bc0f2] uppercase">
              {hud.subtitleSpeaker}
            </div>
          )}
          <p className="mt-0.5 text-sm text-[#eef6fc]">{hud.subtitleText}</p>
        </div>
      )}

      {/* Mobile Touch Controls */}
      {hud.phase === 'playing' && showTouchControls && (
        <>
          <div
            ref={joyRef}
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              updateJoystick(e.clientX, e.clientY);
            }}
            onPointerMove={(e) => {
              if (e.buttons || e.pointerType === 'touch') {
                updateJoystick(e.clientX, e.clientY);
              }
            }}
            onPointerUp={resetJoystick}
            onPointerCancel={resetJoystick}
            style={{ touchAction: 'none' }}
            className="pointer-events-auto absolute left-[max(1rem,env(safe-area-inset-left))] bottom-[max(4.25rem,calc(env(safe-area-inset-bottom)+3rem))] flex h-28 w-28 items-center justify-center rounded-full border border-[#a8c7e0]/40 bg-[#060b12]/65"
          >
            <div
              ref={stickRef}
              className="h-11 w-11 rounded-full border border-[#d6e9f7]/70 bg-[#b9d7ee]/35"
            />
          </div>

          <div className="pointer-events-auto absolute right-[max(1rem,env(safe-area-inset-right))] bottom-[max(4.25rem,calc(env(safe-area-inset-bottom)+3rem))] flex flex-col items-end gap-2">
            <div className="flex items-center gap-1.5">
              {hud.hasPistol && !hud.isHiding && (
                <>
                  <button
                    type="button"
                    onClick={() => engineRef.current?.fireWeapon()}
                    className="h-12 min-w-[54px] border border-[#e14b56] bg-[#360b10]/90 px-2 font-mono text-[10px] font-bold text-[#ffb8be] cursor-pointer"
                  >
                    TIR
                  </button>
                  <button
                    type="button"
                    onClick={() => engineRef.current?.reloadWeapon()}
                    className="h-11 min-w-[44px] border border-white/25 bg-[#0b131f]/90 px-2 font-mono text-[10px] font-bold text-white cursor-pointer"
                  >
                    RECH
                  </button>
                </>
              )}
              {hud.flaresCount > 0 && !hud.isHiding && (
                <button
                  type="button"
                  onClick={() => engineRef.current?.useFlare()}
                  className="h-11 min-w-[44px] border border-[#d4a24e] bg-[#241a08]/90 px-2 font-mono text-[10px] font-bold text-[#f3ce82] cursor-pointer"
                >
                  FUSÉE
                </button>
              )}
              {hud.bottlesCount > 0 && !hud.isHiding && (
                <button
                  type="button"
                  onClick={() => engineRef.current?.throwBottle()}
                  className="h-11 min-w-[44px] border border-[#5ee6a8] bg-[#0d271c]/90 px-2 font-mono text-[10px] font-bold text-[#8ff5c4] cursor-pointer"
                >
                  BOUT.
                </button>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => engineRef.current?.togglePerspective()}
                className="h-11 min-w-[42px] border border-white/25 bg-[#071019]/88 font-mono text-[10px] font-bold text-white cursor-pointer"
              >
                1P/3P
              </button>
              <button
                type="button"
                onClick={() => engineRef.current?.triggerJump()}
                className="h-11 min-w-[44px] border border-white/25 bg-[#071019]/88 font-mono text-[10px] font-bold text-white cursor-pointer"
              >
                SAUT
              </button>
              <button
                type="button"
                onClick={() => engineRef.current?.toggleCrouch()}
                className={`h-11 min-w-[50px] border font-mono text-[10px] font-bold cursor-pointer ${
                  hud.crouching
                    ? 'border-white bg-[#63a5d8] text-[#040910]'
                    : 'border-white/25 bg-[#071019]/88 text-white'
                }`}
              >
                BAISS.
              </button>
              <button
                type="button"
                onPointerDown={() => engineRef.current?.setTouchSprint(true)}
                onPointerUp={() => engineRef.current?.setTouchSprint(false)}
                onPointerCancel={() => engineRef.current?.setTouchSprint(false)}
                className={`h-12 min-w-[54px] border font-mono text-[10px] font-bold cursor-pointer ${
                  hud.sprinting
                    ? 'border-white bg-[#63a5d8] text-[#040910]'
                    : 'border-white/25 bg-[#071019]/88 text-white'
                }`}
              >
                COURIR
              </button>
              <button
                type="button"
                onClick={() => engineRef.current?.toggleFlashlight()}
                className={`h-12 min-w-[54px] border font-mono text-[10px] font-bold cursor-pointer ${
                  hud.flashlightOn
                    ? 'border-[#7ac1f4] bg-[#13293d]/92 text-[#dff1ff]'
                    : 'border-white/25 bg-[#071019]/88 text-[#889dad]'
                }`}
              >
                LAMPE
              </button>
            </div>
          </div>
        </>
      )}

      {/* Collapsible Quick Utility Dock */}
      {hud.phase === 'playing' && (
        <div className="pointer-events-auto absolute bottom-[max(0.65rem,env(safe-area-inset-bottom))] left-1/2 z-20 -translate-x-1/2 flex flex-col items-center">
          <button
            type="button"
            onClick={() => setDockOpen((v) => !v)}
            className="flex items-center gap-1.5 border border-[#8db4d4]/25 bg-[#060b12]/88 px-3 py-1 font-mono text-[10px] font-semibold tracking-[0.16em] text-[#adc6da] hover:text-white cursor-pointer"
          >
            {dockOpen ? <ChevronDown className="h-3 w-3" /> : <ChevronUp className="h-3 w-3" />}
            <span>{dockOpen ? (fr ? 'MASQUER' : 'HIDE') : fr ? 'OUTILS & RENDU' : 'TOOLS & RENDER'}</span>
          </button>

          {dockOpen && (
            <div className="mt-1 flex max-w-[92vw] flex-wrap items-center justify-center gap-1.5 border border-[#8db4d4]/30 bg-[#060b12]/95 px-3 py-2">
              {PROFILE_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => engineRef.current?.setProfileMode(opt.id)}
                  className={`px-2 py-1 font-mono text-[10px] font-bold border cursor-pointer ${
                    hud.profileMode === opt.id
                      ? 'border-[#7bc0f2] bg-[#63a5d8] text-[#040910]'
                      : 'border-white/15 text-[#a8c1d4] hover:text-white'
                  }`}
                >
                  {opt.short}
                </button>
              ))}
              <button
                type="button"
                onClick={() => engineRef.current?.toggleFlashlight()}
                className="flex items-center gap-1 border border-white/20 px-2 py-1 font-mono text-[10px] text-[#d4e4f0] cursor-pointer"
              >
                <Flashlight className="h-3 w-3" />
                <span>{hud.flashlightOn ? 'ON' : 'OFF'}</span>
              </button>
              <button
                type="button"
                onClick={() => engineRef.current?.toggleGaussianScan()}
                className="border border-white/20 px-2 py-1 font-mono text-[10px] text-[#d4e4f0] cursor-pointer"
              >
                SPLAT {hud.gaussianScanEnabled ? 'ON' : 'OFF'}
              </button>
              {!hud.isTouchDevice && (
                <button
                  type="button"
                  onClick={() => setForceTouchUi((v) => !v)}
                  className="border border-white/20 px-2 py-1 font-mono text-[10px] text-[#d4e4f0] cursor-pointer"
                >
                  TACTILE {forceTouchUi ? 'ON' : 'OFF'}
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* PAUSE MODAL */}
      {hud.phase === 'paused' && (
        <div className="pointer-events-auto fixed inset-0 z-30 flex items-center justify-center bg-[#030509]/82 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md border border-[#8db4d4]/30 bg-[#070c14]/98 p-6 shadow-[0_24px_60px_rgba(0,0,0,0.9)]">
            <div className="font-mono text-[10px] font-semibold tracking-[0.25em] text-[#7bc0f2] uppercase">
              PAUSE · {hud.chapterLabel}
            </div>
            <h2 className="mt-1 font-display text-2xl font-bold text-white">{hud.chapterTitle}</h2>

            <div className="mt-4 space-y-2">
              <button
                type="button"
                onClick={() => engineRef.current?.resumeGame()}
                className="flex min-h-[44px] w-full items-center justify-center gap-2 bg-[#e6f1fa] py-3 text-xs font-bold tracking-[0.2em] text-[#050a12] uppercase hover:bg-white cursor-pointer"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>{copy.resume}</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => engineRef.current?.setPhase('inventory')}
                  className="flex min-h-[42px] items-center justify-center gap-2 border border-white/15 bg-[#0e1724] text-xs font-semibold text-[#d4e4f0] hover:border-white/40 cursor-pointer"
                >
                  <Briefcase className="h-3.5 w-3.5" />
                  <span>{copy.inventory}</span>
                </button>
                <button
                  type="button"
                  onClick={onOpenCodex}
                  className="flex min-h-[42px] items-center justify-center gap-2 border border-white/15 bg-[#0e1724] text-xs font-semibold text-[#d4e4f0] hover:border-white/40 cursor-pointer"
                >
                  <BookOpen className="h-3.5 w-3.5" />
                  <span>{fr ? 'Codex' : 'Archives'}</span>
                </button>
              </div>

              {hud.entitlements.premiumPass && (
                <button
                  type="button"
                  onClick={() => engineRef.current?.setPhase('photo_mode')}
                  className="flex min-h-[42px] w-full items-center justify-center gap-2 border border-[#d4a24e]/50 bg-[#231908] text-xs font-bold tracking-wider text-[#f3ce82] uppercase hover:bg-[#31230b] cursor-pointer"
                >
                  <Camera className="h-3.5 w-3.5" />
                  <span>{copy.photoMode}</span>
                </button>
              )}

              {/* Quick Save Slots */}
              <div className="border border-white/10 bg-[#0a111a] p-3">
                <div className="flex items-center justify-between font-mono text-[10px] text-[#8aa9c2] uppercase">
                  <span className="flex items-center gap-1.5">
                    <Save className="h-3 w-3" />
                    {copy.saveGame}
                  </span>
                  {pauseSavedMsg && <span className="text-[#5ee6a8]">{pauseSavedMsg}</span>}
                </div>
                <div className="mt-2 grid grid-cols-3 gap-1.5">
                  {(['slot1', 'slot2', 'slot3'] as SaveSlotData['slotId'][]).map((sid, i) => (
                    <button
                      key={sid}
                      type="button"
                      onClick={() => handlePauseSave(sid)}
                      className="border border-white/15 bg-[#0e1825] py-1.5 font-mono text-[11px] font-semibold text-[#cfe0ee] hover:border-[#7bc0f2] cursor-pointer"
                    >
                      SLOT {i + 1}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => engineRef.current?.restartChapter()}
                  className="flex min-h-[42px] items-center justify-center gap-2 border border-white/15 bg-[#0e1724] text-xs font-semibold text-[#cfe0ee] hover:border-white/40 cursor-pointer"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>{copy.restart}</span>
                </button>
                <button
                  type="button"
                  onClick={() => engineRef.current?.setPhase('title')}
                  className="flex min-h-[42px] items-center justify-center gap-2 border border-white/15 bg-[#0e1724] text-xs font-semibold text-[#cfe0ee] hover:border-white/40 cursor-pointer"
                >
                  <Home className="h-3.5 w-3.5" />
                  <span>{copy.mainMenu}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* GAME OVER / CAUGHT MODAL */}
      {hud.phase === 'caught' && (
        <div className="pointer-events-auto fixed inset-0 z-30 flex items-center justify-center bg-[#140305]/88 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md border border-[#ff4d57]/55 bg-[#0a0507]/96 p-6 shadow-[0_24px_60px_rgba(0,0,0,0.92)]">
            <div className="flex items-center gap-2 font-mono text-[10px] font-semibold tracking-[0.25em] text-[#ff6b73] uppercase">
              <Skull className="h-4 w-4" />
              <span>{copy.caughtTitle}</span>
            </div>
            <h2 className="mt-1 font-display text-2xl font-extrabold tracking-wider text-white">
              {copy.caughtHeadline}
            </h2>
            <p className="mt-2 text-xs leading-relaxed text-[#d6b8bc]">{copy.caughtBody}</p>

            <div className="mt-4 grid grid-cols-2 gap-3 border border-white/10 bg-[#140a0d] p-3.5">
              <div>
                <div className="font-mono text-[10px] tracking-[0.18em] text-[#b0868b] uppercase">
                  {hud.chapterLabel}
                </div>
                <div className="mt-0.5 font-mono text-base font-bold text-white">
                  {formatTimer(hud.elapsedSeconds)}
                </div>
              </div>
              <div>
                <div className="font-mono text-[10px] tracking-[0.18em] text-[#b0868b] uppercase">
                  {fr ? 'INDICES' : 'CLUES'}
                </div>
                <div className="mt-0.5 font-mono text-base font-bold text-[#ff7b82]">
                  {hud.cluesCollected}/{hud.totalClues}
                </div>
              </div>
            </div>

            <div className="mt-5 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => engineRef.current?.restartChapter()}
                className="flex min-h-[44px] w-full items-center justify-center gap-2 bg-[#ff5964] py-3 text-xs font-bold tracking-[0.2em] text-[#0a0305] uppercase hover:bg-[#ff707a] cursor-pointer"
              >
                <RotateCcw className="h-4 w-4" />
                <span>{copy.retryCheckpoint}</span>
              </button>
              <button
                type="button"
                onClick={() => engineRef.current?.setPhase('title')}
                className="flex min-h-[42px] w-full items-center justify-center gap-2 border border-white/15 bg-[#12090c] py-2.5 text-xs font-semibold tracking-wider text-[#dfb9be] uppercase hover:text-white cursor-pointer"
              >
                <Home className="h-3.5 w-3.5" />
                <span>{copy.mainMenu}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
