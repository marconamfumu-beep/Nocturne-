import { useEffect, useState } from 'react';
import { ArrowRight, KeyRound, PhoneIncoming, ShieldAlert, SkipForward } from 'lucide-react';
import { SaveManager } from '../save/saveManager';
import { CHAPTERS, ENDINGS } from '../story/chaptersData';
import type { HudSnapshot, Language, MoralDecisionId } from '../types/game';
import type { HospitalEngineHandle } from './HospitalViewport';

interface CinematicOverlayProps {
  hud: HudSnapshot;
  language: Language;
  engineRef: React.RefObject<HospitalEngineHandle | null>;
}

export function CinematicOverlay({ hud, language, engineRef }: CinematicOverlayProps) {
  const [endingBeatIndex, setEndingBeatIndex] = useState(0);
  const fr = language === 'fr';

  useEffect(() => {
    setEndingBeatIndex(0);
  }, [hud.phase, hud.activeEnding]);

  if (hud.phase === 'intro_cinematic') {
    return (
      <div className="fixed inset-0 z-40 flex flex-col justify-between bg-[#030509]/92 p-6 sm:p-12 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <span className="font-mono text-xs tracking-[0.26em] text-[#7bc0f2]">
            {fr ? 'KAMBALA · 02:17 DU MATIN' : 'KAMBALA · 02:17 AM'}
          </span>
          <button
            type="button"
            onClick={() => engineRef.current?.advanceFromIntro()}
            className="flex min-h-[40px] items-center gap-2 border border-white/20 bg-[#0b131e] px-4 py-2 text-xs font-semibold tracking-wider text-[#d4e4f0] hover:border-white/50 cursor-pointer"
          >
            <SkipForward className="h-3.5 w-3.5" />
            <span>{fr ? 'Passer' : 'Skip'}</span>
          </button>
        </div>

        <div className="mx-auto max-w-2xl text-center">
          <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center border border-[#7bc0f2]/40 bg-[#0c1b2c]">
            <PhoneIncoming className="h-6 w-6 animate-pulse text-[#7bc0f2]" />
          </div>
          <div className="font-mono text-xs tracking-[0.28em] text-[#e14b56] uppercase">
            {fr ? 'APPEL ENTRANT · MAYA KANZA' : 'INCOMING CALL · MAYA KANZA'}
          </div>
          <blockquote className="mt-5 font-display text-xl sm:text-2xl leading-relaxed text-[#f1f7fc]">
            {fr
              ? '« Noah… si tu entends ma voix, ne viens pas seul. Ils ont rallumé les lumières. Le Patient 04 est encore là. Et surtout… ne lui réponds pas quand il prononce ton nom. »'
              : '"Noah… if you hear my voice, don’t come alone. They turned the lights back on. Patient 04 is still here. And above all… never answer when he speaks your name."'}
          </blockquote>
          <p className="mt-6 text-sm text-[#9cb4c7]">
            {fr
              ? 'La grille du Pavillon Kambala est ouverte. Dès que Noah franchit le seuil, le mécanisme se verrouille derrière lui.'
              : 'The gate of Kambala Pavilion stands ajar. The moment Noah steps inside, the iron lock snaps shut behind him.'}
          </p>

          <button
            type="button"
            onClick={() => engineRef.current?.advanceFromIntro()}
            className="mt-8 inline-flex min-h-[46px] items-center gap-3 bg-[#e6f1fa] px-7 py-3 text-xs font-bold tracking-[0.2em] text-[#040910] uppercase hover:bg-white cursor-pointer"
          >
            <span>{fr ? 'Entrer dans le Pavillon' : 'Enter the Pavilion'}</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="text-center font-mono text-[11px] text-[#6d8599]">
          NOCTURNE 04 — PAVILLON KAMBALA
        </div>
      </div>
    );
  }

  if (hud.phase === 'chapter_transition') {
    const cfg = CHAPTERS[hud.chapterId];
    return (
      <div className="fixed inset-0 z-40 flex flex-col items-center justify-center bg-[#030509]/94 p-6 text-center backdrop-blur-md">
        <div className="max-w-xl border border-[#8db4d4]/25 bg-[#060c14] p-8 sm:p-10 shadow-[0_24px_70px_rgba(0,0,0,0.92)]">
          <div className="font-mono text-xs tracking-[0.3em] text-[#7bc0f2] uppercase">
            {fr ? cfg.labelFr : cfg.labelEn}
          </div>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold tracking-wider text-white uppercase">
            {fr ? cfg.titleFr : cfg.titleEn}
          </h2>
          <div className="mt-2 font-mono text-xs text-[#8ea8be]">
            {fr ? cfg.locationFr : cfg.locationEn}
          </div>
          <p className="mt-5 text-sm leading-relaxed text-[#c3d5e3]">
            {fr ? cfg.summaryFr : cfg.summaryEn}
          </p>
          <div className="mt-5 border-t border-white/10 pt-4 font-mono text-[11px] text-[#e1858d]">
            {fr ? cfg.monsterBehaviorNoteFr : cfg.monsterBehaviorNoteEn}
          </div>

          <button
            type="button"
            onClick={() => engineRef.current?.advanceFromTransition()}
            className="mt-7 inline-flex min-h-[46px] items-center gap-3 bg-[#e6f1fa] px-8 py-3 text-xs font-bold tracking-[0.2em] text-[#040910] uppercase hover:bg-white cursor-pointer"
          >
            <span>{fr ? 'Commencer le chapitre' : 'Start Chapter'}</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  if (hud.phase === 'moral_choice') {
    const knownDocs = new Set([
      ...hud.discoveredDocIds,
      ...SaveManager.loadProgress().discoveredDocIds,
    ]);
    const secretCount = ['doc_ch5_secret_1', 'doc_ch5_secret_2', 'doc_ch5_secret_3'].filter((id) =>
      knownDocs.has(id),
    ).length;
    const canTakeControl = secretCount >= 3;

    const choose = (d: MoralDecisionId) => engineRef.current?.chooseMoralDecision(d);

    return (
      <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#030509]/92 p-4 backdrop-blur-md">
        <div className="w-full max-w-2xl border border-[#8db4d4]/35 bg-[#070c14]/98 p-6 sm:p-8 shadow-[0_24px_70px_rgba(0,0,0,0.92)]">
          <div className="flex items-center gap-2 font-mono text-xs tracking-[0.24em] text-[#d4a24e] uppercase">
            <ShieldAlert className="h-4 w-4" />
            <span>
              {hud.chapterId === 'ch6'
                ? fr
                  ? 'DÉCISION FINALE · NOYAU NOCTURNE'
                  : 'FINAL DECISION · NOCTURNE CORE'
                : fr
                  ? 'CHOIX MORAL · CUVES DE CONFINEMENT'
                  : 'MORAL CHOICE · CONTAINMENT PODS'}
            </span>
          </div>
          <h2 className="mt-2 font-display text-2xl font-bold text-white">
            {fr
              ? 'Quel avenir décidez-vous pour le Pavillon Kambala ?'
              : 'What fate do you choose for Kambala Pavilion?'}
          </h2>
          <p className="mt-2 text-xs leading-relaxed text-[#a8bfd1]">
            {fr
              ? 'Trois patients survivent encore en stase dans le laboratoire. Votre choix déterminera le dénouement final.'
              : 'Three patients remain alive in stasis inside the lab. Your decision determines the final outcome.'}
          </p>

          <div className="mt-5 space-y-3">
            <button
              type="button"
              onClick={() => choose('seal_wing')}
              className="w-full border border-[#7bc0f2]/40 bg-[#0b1623] p-4 text-left hover:border-[#7bc0f2] hover:bg-[#102135] cursor-pointer"
            >
              <div className="font-display text-sm font-bold text-white uppercase">
                {fr
                  ? 'Priorité à Maya — Sceller l’aile et fuir (Fin A)'
                  : 'Prioritize Maya — Seal Wing & Escape (Ending A)'}
              </div>
              <div className="mt-1 text-xs text-[#9fb8cb]">
                {fr
                  ? 'Vous sacrifiez les cuves pour ouvrir le passage de Maya et quitter l’hôpital avant l’explosion.'
                  : 'Sacrifice the stasis pods to clear Maya’s exit route and escape before detonation.'}
              </div>
            </button>

            <button
              type="button"
              onClick={() => choose('free_patients')}
              className="w-full border border-[#4fe09b]/40 bg-[#091c15] p-4 text-left hover:border-[#4fe09b] hover:bg-[#0e2a20] cursor-pointer"
            >
              <div className="font-display text-sm font-bold text-white uppercase">
                {fr
                  ? 'Libérer les patients — Retenir Elias (Fin B)'
                  : 'Free the Patients — Stay Behind for Elias (Ending B)'}
              </div>
              <div className="mt-1 text-xs text-[#9bd4b8]">
                {fr
                  ? 'Vous évacuez Maya et tous les survivants des cuves, puis affrontez le destin dans la chambre 04.'
                  : 'Evacuate Maya and every pod survivor, then stay inside to seal Patient 04 with you.'}
              </div>
            </button>

            {canTakeControl ? (
              <button
                type="button"
                onClick={() => choose('take_control')}
                className="w-full border border-[#d4a24e]/60 bg-[#221807] p-4 text-left hover:border-[#f2cb79] hover:bg-[#31230a] cursor-pointer"
              >
                <div className="flex items-center gap-2 font-display text-sm font-bold text-[#f4cf81] uppercase">
                  <KeyRound className="h-4 w-4" />
                  <span>
                    {fr
                      ? '[FIN SECRÈTE] Reprendre le contrôle du programme NOCTURNE (Fin C)'
                      : '[SECRET ENDING] Assume Control of Project NOCTURNE (Ending C)'}
                  </span>
                </div>
                <div className="mt-1 text-xs text-[#e3cb95]">
                  {fr
                    ? 'Grâce aux 3 dossiers classifiés du Chapitre 5, annulez l’autodestruction et devenez le nouveau directeur.'
                    : 'Using all 3 classified Chapter 5 files, abort self-destruct and assume administrative command.'}
                </div>
              </button>
            ) : (
              <div className="border border-white/10 bg-[#080d14] p-3.5 text-xs text-[#6f8699]">
                {fr
                  ? `Voie secrète verrouillée (${secretCount}/3 dossiers classifiés trouvés au Chapitre 5).`
                  : `Secret override locked (${secretCount}/3 classified Chapter 5 files recovered).`}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (hud.phase === 'ending_cinematic') {
    const ending = ENDINGS[hud.activeEnding ?? 'ending_a'];
    const scenes = fr ? ending.scenesFr : ending.scenesEn;
    const isLastBeat = endingBeatIndex >= scenes.length - 1;
    const currentBeat = scenes[Math.min(endingBeatIndex, scenes.length - 1)];

    return (
      <div className="fixed inset-0 z-40 flex flex-col justify-between bg-[#020408]/96 p-6 sm:p-12 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <span className="font-mono text-xs tracking-[0.26em] text-[#d4a24e] uppercase">
            {ending.code} · {fr ? ending.titleFr : ending.titleEn}
          </span>
          <button
            type="button"
            onClick={() => engineRef.current?.finishEndingToCredits()}
            className="border border-white/20 bg-[#0a121b] px-4 py-2 text-xs font-semibold text-[#cfe0ee] hover:text-white cursor-pointer"
          >
            {fr ? 'Générique' : 'Credits'}
          </button>
        </div>

        <div className="mx-auto max-w-2xl text-center">
          <div className="font-mono text-xs tracking-[0.22em] text-[#7bc0f2] uppercase">
            {currentBeat.speaker}
          </div>
          <p className="mt-4 font-display text-xl sm:text-2xl leading-relaxed text-white">
            {currentBeat.line}
          </p>

          {isLastBeat && ending.finalBannerFr && (
            <div className="mt-8 border border-[#e14b56] bg-[#1e0608] px-6 py-4 font-mono text-sm sm:text-base font-bold tracking-[0.25em] text-[#ff8a93] animate-pulse">
              {fr ? ending.finalBannerFr : ending.finalBannerEn}
            </div>
          )}

          <div className="mt-8">
            {!isLastBeat ? (
              <button
                type="button"
                onClick={() => setEndingBeatIndex((i) => i + 1)}
                className="inline-flex min-h-[44px] items-center gap-2 bg-[#e6f1fa] px-7 py-3 text-xs font-bold tracking-[0.2em] text-[#040910] uppercase hover:bg-white cursor-pointer"
              >
                <span>{fr ? 'Continuer' : 'Next'}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => engineRef.current?.finishEndingToCredits()}
                className="inline-flex min-h-[44px] items-center gap-2 bg-[#e6f1fa] px-7 py-3 text-xs font-bold tracking-[0.2em] text-[#040910] uppercase hover:bg-white cursor-pointer"
              >
                <span>{fr ? 'Voir le générique final' : 'Roll Final Credits'}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        <div className="text-center font-mono text-[11px] text-[#748b9e]">
          {fr ? ending.subtitleFr : ending.subtitleEn}
        </div>
      </div>
    );
  }

  if (hud.phase === 'credits') {
    return (
      <div className="fixed inset-0 z-40 flex flex-col justify-between overflow-hidden bg-[#020408] p-6 sm:p-10">
        <div className="flex justify-end">
          <button
            type="button"
            onClick={() => engineRef.current?.setPhase('title')}
            className="border border-white/25 bg-[#0a121c] px-5 py-2.5 text-xs font-bold tracking-[0.2em] text-white uppercase hover:border-white cursor-pointer"
          >
            {fr ? 'Retour au menu principal' : 'Return to Main Menu'}
          </button>
        </div>

        <div className="relative mx-auto h-[65vh] w-full max-w-xl overflow-hidden text-center">
          <div className="animate-credits space-y-6 py-12">
            <h2 className="font-display text-3xl font-bold tracking-[0.2em] text-white">
              NOCTURNE 04
            </h2>
            <div className="font-mono text-xs tracking-[0.3em] text-[#7bc0f2]">
              PAVILLON KAMBALA
            </div>
            <div className="space-y-4 pt-6 text-sm text-[#b9cde0]">
              <div>
                <div className="font-mono text-[10px] text-[#7c96ab] uppercase">
                  {fr ? 'Direction & Réalisation 3D' : 'Direction & 3D Engineering'}
                </div>
                <div className="text-white font-semibold mt-0.5">Studio Nocturne Interactive</div>
              </div>
              <div>
                <div className="font-mono text-[10px] text-[#7c96ab] uppercase">
                  {fr ? 'Moteur Temps Réel' : 'Real-Time Engine'}
                </div>
                <div className="text-white font-semibold mt-0.5">
                  Babylon.js WebGL2 · Gaussian Splatting
                </div>
              </div>
              <div>
                <div className="font-mono text-[10px] text-[#7c96ab] uppercase">
                  {fr ? 'Design Sonore & Synthèse' : 'Audio Design & Spatial Synthesis'}
                </div>
                <div className="text-white font-semibold mt-0.5">
                  Web Audio API · Synthèse Vocale NOCTURNE
                </div>
              </div>
              <div>
                <div className="font-mono text-[10px] text-[#7c96ab] uppercase">
                  {fr ? 'Merci d’avoir joué' : 'Thank You for Playing'}
                </div>
                <div className="text-[#f2cb79] font-semibold mt-0.5">
                  {fr
                    ? 'Explorez les autres chapitres et fins dans le Codex.'
                    : 'Explore alternate endings and classified files in the Codex.'}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center font-mono text-[11px] text-[#6d8599]">
          © 2026 NOCTURNE 04 — PAVILLON KAMBALA
        </div>
      </div>
    );
  }

  return null;
}
