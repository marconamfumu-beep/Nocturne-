import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { Engine, Scalar, Vector3 } from '@babylonjs/core';
import { Patient04AI } from '../ai/monsterAI';
import { NocturneAudioEngine } from '../audio/soundEngine';
import {
  buildHospitalWorld,
  type Aabb2D,
  type DoorTarget,
  type HideoutTarget,
  type HospitalWorld,
  type InteractableTarget,
} from '../engine/hospitalScene';
import { BabylonCinematicPipeline } from '../engine/postProcessing';
import {
  detectSoftwareWebGL,
  detectTouchEnvironment,
  DynamicRenderProfiler,
} from '../engine/renderProfile';
import { DIFFICULTY_CONFIGS } from '../gameplay/difficulty';
import { SaveManager } from '../save/saveManager';
import { AUDIO_TAPES, CHAPTERS, PUZZLES, STORY_DOCUMENTS } from '../story/chaptersData';
import type {
  CameraPerspective,
  ChapterId,
  ClueNote,
  DifficultyId,
  EndingId,
  EntitlementState,
  GamePhase,
  GameSettings,
  HudSnapshot,
  KeyBadgeInfo,
  MoralDecisionId,
  PuzzleDefinition,
  RenderProfileMode,
  SaveSlotData,
  VisualFilterMode,
} from '../types/game';

export interface HospitalEngineHandle {
  startNewGame: (difficulty: DifficultyId, chapterId?: ChapterId) => void;
  startChapterDirect: (chapterId: ChapterId, difficulty?: DifficultyId) => void;
  loadFromSave: (slot: SaveSlotData) => void;
  saveToSlot: (slotId: SaveSlotData['slotId']) => boolean;
  setPhase: (phase: GamePhase) => void;
  advanceFromIntro: () => void;
  advanceFromTransition: () => void;
  finishEndingToCredits: () => void;
  resumeGame: () => void;
  pauseGame: () => void;
  restartChapter: () => void;
  toggleFlashlight: () => void;
  toggleCrouch: () => void;
  triggerJump: () => void;
  togglePerspective: () => void;
  triggerInteract: () => void;
  fireWeapon: () => void;
  reloadWeapon: () => void;
  useMedkit: () => void;
  rechargeBattery: () => void;
  throwBottle: () => void;
  useFlare: () => void;
  solveActivePuzzle: (code: string) => boolean;
  cancelPuzzleOrCctv: () => void;
  chooseMoralDecision: (decision: MoralDecisionId) => void;
  toggleMute: () => void;
  toggleGaussianScan: () => void;
  setProfileMode: (mode: RenderProfileMode) => void;
  applySettings: (settings: GameSettings) => void;
  setEntitlements: (ent: EntitlementState) => void;
  setVisualFilter: (filter: VisualFilterMode) => void;
  capturePhotoSnapshot: () => string | null;
  setJoystick: (x: number, y: number) => void;
  setTouchSprint: (sprinting: boolean) => void;
  applyLookDelta: (dx: number, dy: number) => void;
  dismissNote: () => void;
  playAudioTape: (tapeId: string) => void;
}

interface HospitalViewportProps {
  initialSettings: GameSettings;
  initialEntitlements: EntitlementState;
  onHudChange: (snapshot: HudSnapshot) => void;
}

const _forward = new Vector3();
const _right = new Vector3();
const _moveDir = new Vector3();
const _toItem = new Vector3();
const _camForward = new Vector3();

function resolveAabbCircle(
  px: number,
  pz: number,
  radius: number,
  colliders: Aabb2D[],
): [number, number] {
  let x = px;
  let z = pz;
  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < colliders.length; i++) {
      const b = colliders[i];
      if (b.disabled) continue;
      const closestX = Math.max(b.minX, Math.min(x, b.maxX));
      const closestZ = Math.max(b.minZ, Math.min(z, b.maxZ));
      const dx = x - closestX;
      const dz = z - closestZ;
      const distSq = dx * dx + dz * dz;
      if (distSq < radius * radius) {
        if (distSq > 1e-6) {
          const dist = Math.sqrt(distSq);
          const push = radius - dist;
          x += (dx / dist) * push;
          z += (dz / dist) * push;
        } else {
          const dl = Math.abs(x - b.minX);
          const dr = Math.abs(b.maxX - x);
          const dt = Math.abs(z - b.minZ);
          const db = Math.abs(b.maxZ - z);
          const m = Math.min(dl, dr, dt, db);
          if (m === dl) x = b.minX - radius;
          else if (m === dr) x = b.maxX + radius;
          else if (m === dt) z = b.minZ - radius;
          else z = b.maxZ + radius;
        }
      }
    }
  }
  return [x, z];
}

function segmentIntersectsAabb2D(
  ax: number,
  az: number,
  bx: number,
  bz: number,
  box: Aabb2D,
): boolean {
  const dx = bx - ax;
  const dz = bz - az;
  let tmin = 0;
  let tmax = 1;

  if (Math.abs(dx) < 1e-6) {
    if (ax < box.minX || ax > box.maxX) return false;
  } else {
    const invD = 1 / dx;
    let t1 = (box.minX - ax) * invD;
    let t2 = (box.maxX - ax) * invD;
    if (t1 > t2) {
      const tmp = t1;
      t1 = t2;
      t2 = tmp;
    }
    tmin = Math.max(tmin, t1);
    tmax = Math.min(tmax, t2);
    if (tmin > tmax) return false;
  }

  if (Math.abs(dz) < 1e-6) {
    if (az < box.minZ || az > box.maxZ) return false;
  } else {
    const invD = 1 / dz;
    let t1 = (box.minZ - az) * invD;
    let t2 = (box.maxZ - az) * invD;
    if (t1 > t2) {
      const tmp = t1;
      t1 = t2;
      t2 = tmp;
    }
    tmin = Math.max(tmin, t1);
    tmax = Math.min(tmax, t2);
    if (tmin > tmax) return false;
  }

  return true;
}

function hasLineOfSight2D(
  ax: number,
  az: number,
  bx: number,
  bz: number,
  colliders: Aabb2D[],
): boolean {
  for (let i = 0; i < colliders.length; i++) {
    const box = colliders[i];
    if (box.disabled) continue;
    if (segmentIntersectsAabb2D(ax, az, bx, bz, box)) return false;
  }
  return true;
}

function getZone(x: number, z: number): string {
  if (x > 2.25) return z > 0 ? 'reception' : 'surgery';
  if (x < -2.25) return z > 0 ? 'generator' : 'observation';
  return 'corridor';
}

function getZoneThreshold(zone: string): [number, number] {
  switch (zone) {
    case 'reception':
      return [1.45, 4.5];
    case 'observation':
      return [-1.45, -4.5];
    case 'surgery':
      return [1.45, -9.8];
    case 'generator':
      return [-1.45, 5.2];
    default:
      return [0, 0];
  }
}

export const HospitalViewport = forwardRef<HospitalEngineHandle, HospitalViewportProps>(
  function HospitalViewport({ initialSettings, initialEntitlements, onHudChange }, ref) {
    const mountRef = useRef<HTMLDivElement | null>(null);
    const onHudChangeRef = useRef(onHudChange);
    onHudChangeRef.current = onHudChange;

    const apiRef = useRef<HospitalEngineHandle>({
      startNewGame: () => {},
      startChapterDirect: () => {},
      loadFromSave: () => {},
      saveToSlot: () => false,
      setPhase: () => {},
      advanceFromIntro: () => {},
      advanceFromTransition: () => {},
      finishEndingToCredits: () => {},
      resumeGame: () => {},
      pauseGame: () => {},
      restartChapter: () => {},
      toggleFlashlight: () => {},
      toggleCrouch: () => {},
      triggerJump: () => {},
      togglePerspective: () => {},
      triggerInteract: () => {},
      fireWeapon: () => {},
      reloadWeapon: () => {},
      useMedkit: () => {},
      rechargeBattery: () => {},
      throwBottle: () => {},
      useFlare: () => {},
      solveActivePuzzle: () => false,
      cancelPuzzleOrCctv: () => {},
      chooseMoralDecision: () => {},
      toggleMute: () => {},
      toggleGaussianScan: () => {},
      setProfileMode: () => {},
      applySettings: () => {},
      setEntitlements: () => {},
      setVisualFilter: () => {},
      capturePhotoSnapshot: () => null,
      setJoystick: () => {},
      setTouchSprint: () => {},
      applyLookDelta: () => {},
      dismissNote: () => {},
      playAudioTape: () => {},
    });

    useImperativeHandle(ref, () => ({
      startNewGame: (d, c) => apiRef.current.startNewGame(d, c),
      startChapterDirect: (c, d) => apiRef.current.startChapterDirect(c, d),
      loadFromSave: (s) => apiRef.current.loadFromSave(s),
      saveToSlot: (id) => apiRef.current.saveToSlot(id),
      setPhase: (p) => apiRef.current.setPhase(p),
      advanceFromIntro: () => apiRef.current.advanceFromIntro(),
      advanceFromTransition: () => apiRef.current.advanceFromTransition(),
      finishEndingToCredits: () => apiRef.current.finishEndingToCredits(),
      resumeGame: () => apiRef.current.resumeGame(),
      pauseGame: () => apiRef.current.pauseGame(),
      restartChapter: () => apiRef.current.restartChapter(),
      toggleFlashlight: () => apiRef.current.toggleFlashlight(),
      toggleCrouch: () => apiRef.current.toggleCrouch(),
      triggerJump: () => apiRef.current.triggerJump(),
      togglePerspective: () => apiRef.current.togglePerspective(),
      triggerInteract: () => apiRef.current.triggerInteract(),
      fireWeapon: () => apiRef.current.fireWeapon(),
      reloadWeapon: () => apiRef.current.reloadWeapon(),
      useMedkit: () => apiRef.current.useMedkit(),
      rechargeBattery: () => apiRef.current.rechargeBattery(),
      throwBottle: () => apiRef.current.throwBottle(),
      useFlare: () => apiRef.current.useFlare(),
      solveActivePuzzle: (code) => apiRef.current.solveActivePuzzle(code),
      cancelPuzzleOrCctv: () => apiRef.current.cancelPuzzleOrCctv(),
      chooseMoralDecision: (dec) => apiRef.current.chooseMoralDecision(dec),
      toggleMute: () => apiRef.current.toggleMute(),
      toggleGaussianScan: () => apiRef.current.toggleGaussianScan(),
      setProfileMode: (m) => apiRef.current.setProfileMode(m),
      applySettings: (s) => apiRef.current.applySettings(s),
      setEntitlements: (e) => apiRef.current.setEntitlements(e),
      setVisualFilter: (f) => apiRef.current.setVisualFilter(f),
      capturePhotoSnapshot: () => apiRef.current.capturePhotoSnapshot(),
      setJoystick: (x, y) => apiRef.current.setJoystick(x, y),
      setTouchSprint: (s) => apiRef.current.setTouchSprint(s),
      applyLookDelta: (dx, dy) => apiRef.current.applyLookDelta(dx, dy),
      dismissNote: () => apiRef.current.dismissNote(),
      playAudioTape: (id) => apiRef.current.playAudioTape(id),
    }));

    useEffect(() => {
      const container = mountRef.current;
      if (!container) return;

      const canvas = document.createElement('canvas');
      canvas.style.display = 'block';
      canvas.style.width = '100%';
      canvas.style.height = '100%';
      canvas.style.outline = 'none';
      canvas.style.touchAction = 'none';
      container.appendChild(canvas);

      const isSoftwareGl = detectSoftwareWebGL();
      const isTouch = detectTouchEnvironment();
      const profiler = new DynamicRenderProfiler(isSoftwareGl, isTouch);
      let settings: GameSettings = { ...initialSettings };
      let entitlements: EntitlementState = { ...initialEntitlements };
      profiler.setMode(settings.profileMode);

      const audio = new NocturneAudioEngine();
      audio.setVolumes(settings.masterVolume, settings.musicVolume, settings.sfxVolume);

      const engine = new Engine(canvas, false, {
        preserveDrawingBuffer: true, // Needed for Photo Mode PNG capture
        stencil: false,
        antialias: false,
        powerPreference: 'high-performance',
      });

      // Cinematic presets use GPU-bounded supersampling. The final pixel count is
      // still limited by the device display, GPU, browser and WebGL max texture size.
      // Hardware scaling is managed centrally by HospitalWorld.applyQuality().
      // Avoid a second competing scaling pass here (it caused abrupt canvas resizes).

      let chapterId: ChapterId = 'ch1';
      let difficulty: DifficultyId = 'normal';
      let world: HospitalWorld = buildHospitalWorld(
        engine,
        isSoftwareGl,
        profiler.getConfig(),
        chapterId,
        entitlements.premiumPass,
      );
      let post = new BabylonCinematicPipeline(
        world.scene,
        world.camera,
        isSoftwareGl,
        profiler.getConfig(),
      );
      world.camera.fov = settings.fov;

      const monsterAI = new Patient04AI();

      // Core Game State
      let phase: GamePhase = 'title';
      let perspective: CameraPerspective = 'first_person';
      let playerX = 0;
      let playerZ = 13.6;
      let playerY = 0;
      let verticalVel = 0;
      let isGrounded = true;
      let eyeHeight = 1.62;
      let yaw = Math.PI;
      let pitch = 0.02;
      let targetYaw = Math.PI;
      let targetPitch = 0.02;
      let headBobPhase = 0;
      let lastStrideHalf = 0;

      // Survival & Combat State
      let health = 100;
      let maxHealth = 100;
      let battery = 1.0;
      let flashlightOn = true;
      let flashlightOutageTimer = 0;
      let hasPistol = false;
      let pistolMag = 8;
      const pistolMagSize = 8;
      let pistolReserve = 8;
      let reloadTimer = 0;
      let fireCooldown = 0;
      let recoilPitch = 0;
      let muzzleFlashTimer = 0;
      let medkits = 1;
      let batteriesCount = 1;
      let flaresCount = 1;
      let flareFlashTimer = 0;
      let crouching = false;
      let activeHideout: HideoutTarget | null = null;
      let hideoutSeenByMonster = false;
      let lockerDoorTimer = 0;
      let bottlesCount = 0;
      const maxBottles = 3;
      const bottleProj = {
        active: false,
        x: 0,
        y: 0,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        age: 0,
      };
      let stamina = 1.0;
      let exhausted = false;
      let damageFlashTimer = 0;

      // Story & Progression State
      let generatorRestored = false;
      let powerRestored = false;
      let selfDestructActive = false;
      let selfDestructTimer = 180;
      let elapsedPlayTime = 0;
      let cluesCollected = 0;
      const collectedIds: string[] = [];
      const keys: KeyBadgeInfo[] = [];
      const solvedPuzzleIds: string[] = [];
      const discoveredDocIds: string[] = [];
      const discoveredTapeIds: string[] = [];
      let moralDecision: MoralDecisionId | null = null;
      let activePuzzle: PuzzleDefinition | null = null;
      let activeCctvChapter: ChapterId | null = null;
      let activeEnding: EndingId | null = null;
      let activeNote: ClueNote | null = null;
      let noteTimer = 0;
      let subtitleText: string | null = null;
      let subtitleSpeaker: string | null = null;
      let subtitleTimer = 0;
      let currentPrompt: string | null = null;
      let currentTarget: InteractableTarget | null = null;
      let hudSyncTimer = 0;
      let autoSaveTimer = 0;

      // Photo mode free-cam offsets
      let photoCamX = 0;
      let photoCamY = 1.6;
      let photoCamZ = 10;

      const heldKeys = new Set<string>();
      let joyX = 0;
      let joyY = 0;
      let touchSprint = false;
      let mouseDragging = false;
      let lastPointerX = 0;
      let lastPointerY = 0;

      const hasKey = (id: string) => keys.some((k) => k.id === id);

      const showSubtitle = (speaker: string, text: string, duration = 4.6, mimic = false) => {
        if (!settings.subtitlesEnabled) return;
        subtitleSpeaker = speaker;
        subtitleText = text;
        subtitleTimer = duration;
        audio.speakDialogue(text, settings.language, mimic);
      };

      const rebuildSceneForChapter = (targetChapter: ChapterId) => {
        chapterId = targetChapter;
        post.dispose();
        world.dispose();
        world = buildHospitalWorld(
          engine,
          isSoftwareGl,
          profiler.getConfig(),
          chapterId,
          entitlements.premiumPass,
        );
        post = new BabylonCinematicPipeline(
          world.scene,
          world.camera,
          isSoftwareGl,
          profiler.getConfig(),
        );
        world.camera.fov = settings.fov;
      };

      const buildSaveSnapshot = (slotId: SaveSlotData['slotId']): SaveSlotData => ({
        slotId,
        savedAt: new Date().toISOString(),
        chapterId,
        difficulty,
        elapsedSeconds: Math.floor(elapsedPlayTime),
        health,
        maxHealth,
        stamina,
        battery,
        hasPistol,
        pistolMag,
        pistolReserve,
        medkits,
        batteriesCount,
        bottlesCount,
        flaresCount,
        cluesCollected,
        collectedIds: [...collectedIds],
        keys: [...keys],
        solvedPuzzleIds: [...solvedPuzzleIds],
        discoveredDocIds: [...discoveredDocIds],
        discoveredTapeIds: [...discoveredTapeIds],
        moralDecision,
        generatorRestored,
        powerRestored,
        selfDestructActive,
        selfDestructTimer,
        playerX,
        playerZ,
        playerYaw: yaw,
        perspective,
      });

      const getChapterAndObjective = (): {
        chapterLabel: string;
        chapterTitle: string;
        objectiveText: string;
      } => {
        const cfg = CHAPTERS[chapterId];
        const fr = settings.language === 'fr';
        const chapterLabel = fr ? cfg.labelFr : cfg.labelEn;
        const chapterTitle = fr ? cfg.titleFr : cfg.titleEn;

        if (powerRestored) {
          return {
            chapterLabel,
            chapterTitle,
            objectiveText: fr
              ? chapterId === 'ch6'
                ? 'Sas ouvert ! Rejoignez la Sortie Nord avec Maya avant la déflagration !'
                : 'Sas Nord déverrouillé ! Traversez la porte blindée pour passer au chapitre suivant.'
              : chapterId === 'ch6'
                ? 'Airlock open! Reach the North Exit with Maya before detonation!'
                : 'North Airlock unlocked! Cross the blast door to advance.',
          };
        }

        if (chapterId === 'ch1') {
          if (generatorRestored && cluesCollected >= cfg.totalClues) {
            return {
              chapterLabel,
              chapterTitle,
              objectiveText: fr
                ? 'Activez le panneau électrique près de la Sortie Nord.'
                : 'Activate the North Exit breaker panel.',
            };
          }
          if (hasKey('cle_generateur')) {
            return {
              chapterLabel,
              chapterTitle,
              objectiveText: fr
                ? 'Déverrouillez le Local Générateur (Sud-Ouest), amorcez-le et récupérez le dernier module.'
                : 'Unlock the Generator Room (South-West), start it, and collect the final module.',
            };
          }
          if (hasKey('cle_chirurgie')) {
            return {
              chapterLabel,
              chapterTitle,
              objectiveText: fr
                ? 'Ouvrez le Bloc Chirurgical (Nord-Est) et fouillez la Salle d’Observation (Ouest).'
                : 'Unlock the Surgical Block (North-East) and search Observation (West).',
            };
          }
          return {
            chapterLabel,
            chapterTitle,
            objectiveText: fr
              ? 'Fouillez le Poste de Soins (Est) pour la clé et le pistolet 9mm.'
              : 'Search the Nursing Station (East) for the key and 9mm pistol.',
          };
        }

        if (chapterId === 'ch2') {
          return {
            chapterLabel,
            chapterTitle,
            objectiveText: fr
              ? 'Consultez les caméras CCTV, écoutez la bande #04, récupérez les dossiers et saisissez le code (0217) au sas Nord.'
              : 'Check CCTV feeds, listen to Tape #04, collect files, and enter code (0217) at the North airlock.',
          };
        }

        if (chapterId === 'ch3') {
          return {
            chapterLabel,
            chapterTitle,
            objectiveText: fr
              ? 'Explorez les salles d’opération, récupérez les protocoles 04-A/04-B et calibrez le stimulateur sur 408 Hz.'
              : 'Explore the surgical rooms, collect Protocols 04-A/04-B, and tune the stimulator to 408 Hz.',
          };
        }

        if (chapterId === 'ch4') {
          return {
            chapterLabel,
            chapterTitle,
            objectiveText: fr
              ? 'Parlez à Maya (Ouest), fouillez le labo du Dr Voss (Est) et accédez à la Console des Cuves au Nord.'
              : 'Find Maya (West), search Dr. Voss’s lab (East), and reach the Bio-Pod Console at North.',
          };
        }

        if (chapterId === 'ch5') {
          return {
            chapterLabel,
            chapterTitle,
            objectiveText: fr
              ? 'Trouvez les 3 dossiers secrets classifiés et saisissez le code Chambre 04 (0411) au sas Nord.'
              : 'Recover the 3 classified secret files and enter Room 04 code (0411) at the North airlock.',
          };
        }

        if (chapterId === 'ch6') {
          return {
            chapterLabel,
            chapterTitle,
            objectiveText: selfDestructActive
              ? fr
                ? 'AUTODESTRUCTION ACTIVE ! Rejoignez le sas Nord avec Maya !'
                : 'SELF-DESTRUCT ACTIVE! Reach the North Exit with Maya!'
              : fr
                ? 'Activez le Noyau d’Autodestruction (Sud-Ouest · 0404) puis affrontez Voss et fuyez au Nord.'
                : 'Arm the Self-Destruct Core (South-West · 0404), confront Voss, and escape North.',
          };
        }

        return {
          chapterLabel,
          chapterTitle,
          objectiveText: fr
            ? 'Récupérez les preuves du Bloc Zéro et ouvrez la vanne anti-incendie (4231) au Nord.'
            : 'Recover Block Zero evidence and open the fire valve (4231) at North.',
        };
      };

      const pushHud = () => {
        const wantsSprint = touchSprint || heldKeys.has('ShiftLeft') || heldKeys.has('ShiftRight');
        const { chapterLabel, chapterTitle, objectiveText } = getChapterAndObjective();
        const cfg = CHAPTERS[chapterId];
        onHudChangeRef.current({
          phase,
          chapterId,
          chapterLabel,
          chapterTitle,
          objectiveText,
          difficulty,
          perspective,
          health: Math.round(health),
          maxHealth,
          battery,
          flashlightOn,
          flashlightFlickering: flashlightOn && (battery < 0.18 || monsterAI.dangerLevel > 0.55),
          flashlightOutage: flashlightOutageTimer > 0,
          hasPistol,
          pistolMag,
          pistolMagSize,
          pistolReserve,
          isReloading: reloadTimer > 0,
          medkits,
          batteriesCount,
          bottlesCount,
          maxBottles,
          flaresCount,
          cluesCollected,
          totalClues: cfg.totalClues,
          collectedIds: [...collectedIds],
          keys: [...keys],
          discoveredDocIds: [...discoveredDocIds],
          discoveredTapeIds: [...discoveredTapeIds],
          solvedPuzzleIds: [...solvedPuzzleIds],
          moralDecision,
          generatorRestored,
          powerRestored,
          selfDestructActive,
          selfDestructTimer: Math.ceil(selfDestructTimer),
          activePuzzle,
          activeCctvChapter,
          activeEnding,
          promptText: currentPrompt,
          activeNote,
          subtitleText,
          subtitleSpeaker,
          sprinting: !activeHideout && wantsSprint && !crouching && !exhausted && stamina > 0.02,
          crouching,
          isHidden: activeHideout !== null || (crouching && !flashlightOn),
          isHiding: activeHideout !== null,
          hideoutKind: activeHideout?.kind ?? null,
          hidingSpotLabel: activeHideout?.label ?? null,
          dangerLevel: monsterAI.dangerLevel,
          monsterState: monsterAI.state,
          monsterChasing: monsterAI.state === 'chase' || monsterAI.state === 'attack',
          gaussianScanEnabled: world.isGaussianEnabled(),
          stamina,
          muted: audio.isMuted(),
          elapsedSeconds: Math.floor(elapsedPlayTime),
          profileMode: profiler.getMode(),
          activeTier: profiler.getTier(),
          fps: profiler.currentFps,
          frameMs: profiler.currentFrameMs,
          isTouchDevice: isTouch,
          isSoftwareGl,
          entitlements,
          visualFilter: settings.visualFilter,
        });
      };

      const resetChapterState = (
        targetChapter: ChapterId,
        targetDiff: DifficultyId,
        keepCampaignGear: boolean,
      ) => {
        difficulty = targetDiff;
        const diffCfg = DIFFICULTY_CONFIGS[targetDiff];
        rebuildSceneForChapter(targetChapter);

        playerX = 0;
        playerZ = 13.6;
        playerY = 0;
        verticalVel = 0;
        isGrounded = true;
        eyeHeight = 1.62;
        yaw = Math.PI;
        pitch = 0.02;
        targetYaw = Math.PI;
        targetPitch = 0.02;
        headBobPhase = 0;
        lastStrideHalf = 0;

        maxHealth = diffCfg.playerMaxHealth;
        if (!keepCampaignGear) {
          health = maxHealth;
          battery = 1.0;
          hasPistol = targetChapter !== 'ch1' && targetChapter !== 'dlc1';
          pistolMag = 8;
          pistolReserve = diffCfg.startingAmmo;
          medkits = diffCfg.startingMedkits;
          batteriesCount = diffCfg.startingBatteries;
          flaresCount = 1;
          bottlesCount = 1;
          moralDecision = null;
          elapsedPlayTime = 0;
        } else {
          health = Math.max(health, Math.round(maxHealth * 0.65));
          battery = Math.max(battery, 0.5);
          if (targetChapter !== 'ch1') hasPistol = true;
        }

        flashlightOn = true;
        flashlightOutageTimer = 0;
        reloadTimer = 0;
        fireCooldown = 0;
        recoilPitch = 0;
        muzzleFlashTimer = 0;
        flareFlashTimer = 0;
        crouching = false;
        activeHideout = null;
        hideoutSeenByMonster = false;
        lockerDoorTimer = 0;
        bottleProj.active = false;
        stamina = 1.0;
        exhausted = false;
        damageFlashTimer = 0;

        generatorRestored = targetChapter !== 'ch1';
        powerRestored = false;
        selfDestructActive = false;
        selfDestructTimer = 180;
        cluesCollected = 0;
        collectedIds.length = 0;
        keys.length = 0;
        solvedPuzzleIds.length = 0;
        activePuzzle = null;
        activeCctvChapter = null;
        activeEnding = null;
        currentPrompt = null;
        currentTarget = null;

        const chapCfg = CHAPTERS[targetChapter];
        activeNote = {
          id: `note_${targetChapter}_start`,
          title: settings.language === 'fr' ? chapCfg.titleFr : chapCfg.titleEn,
          subtitle: settings.language === 'fr' ? chapCfg.labelFr : chapCfg.labelEn,
          body: settings.language === 'fr' ? chapCfg.summaryFr : chapCfg.summaryEn,
        };
        noteTimer = 7.5;

        monsterAI.reset(0, -14.2, targetChapter === 'ch1');
        world.resetObjectives();

        // In chapters 2..6, unlock Observation & Surgery / Generator doors if needed for flow
        if (targetChapter !== 'ch1') {
          for (const d of world.doors) {
            if (d.kind === 'locked') {
              d.isUnlocked = true;
              d.isOpen = true;
              d.openAngle = d.position.x > 0 ? -1.42 : 1.42;
              d.targetAngle = d.openAngle;
              d.collider.disabled = true;
              d.leftLeaf.rotation.y = d.openAngle;
            }
          }
        }

        SaveManager.unlockChapter(targetChapter);
        SaveManager.saveSlot(buildSaveSnapshot('auto'));
      };

      const enterHideout = (h: HideoutTarget) => {
        if (activeHideout) return;
        hideoutSeenByMonster =
          monsterAI.state === 'chase' &&
          hasLineOfSight2D(monsterAI.x, monsterAI.z, playerX, playerZ, world.colliders) &&
          Math.hypot(playerX - monsterAI.x, playerZ - monsterAI.z) < 6.5;

        activeHideout = h;
        flashlightOn = false;
        crouching = false;
        playerX = h.cameraPos.x;
        playerZ = h.cameraPos.z;
        targetYaw = h.baseYaw;
        yaw = h.baseYaw;
        targetPitch = h.kind === 'bed' ? 0.04 : 0;
        pitch = targetPitch;
        eyeHeight = h.cameraPos.y;
        if (h.kind === 'locker') {
          h.targetDoorAngle = -1.45;
          lockerDoorTimer = 0.28;
        }
        audio.playHideoutToggle(h.kind, true);
        currentTarget = null;
        currentPrompt = settings.language === 'fr' ? 'Sortir de la cachette' : 'Exit hideout';
        pushHud();
      };

      const exitHideout = () => {
        if (!activeHideout) return;
        const h = activeHideout;
        activeHideout = null;
        hideoutSeenByMonster = false;
        if (h.kind === 'locker') {
          h.targetDoorAngle = -1.45;
          lockerDoorTimer = 0.36;
        }
        playerX = h.exitPos.x;
        playerZ = h.exitPos.z;
        crouching = h.kind === 'bed';
        eyeHeight = h.kind === 'bed' ? 1.05 : 1.62;
        targetYaw = h.baseYaw;
        yaw = h.baseYaw;
        audio.playHideoutToggle(h.kind, false);
        pushHud();
      };

      const throwBottle = () => {
        if (phase !== 'playing' || activeHideout || bottlesCount <= 0 || bottleProj.active) return;
        bottlesCount--;
        world.camera.getDirectionToRef(Vector3.Forward(), _camForward);
        const sx = playerX + _camForward.x * 0.42;
        const sy = eyeHeight - 0.08 + _camForward.y * 0.32;
        const sz = playerZ + _camForward.z * 0.42;
        bottleProj.active = true;
        bottleProj.x = sx;
        bottleProj.y = sy;
        bottleProj.z = sz;
        bottleProj.vx = _camForward.x * 11.5;
        bottleProj.vy = _camForward.y * 11.5 + 2.8;
        bottleProj.vz = _camForward.z * 11.5;
        bottleProj.age = 0;
        world.thrownBottleMesh.position.set(sx, sy, sz);
        world.thrownBottleMesh.setEnabled(true);
        audio.playBottleThrow();
        pushHud();
      };

      const useFlare = () => {
        if (phase !== 'playing' || activeHideout || flaresCount <= 0) return;
        flaresCount--;
        flareFlashTimer = 0.85;
        audio.playPowerRestore();
        const dist = Math.hypot(monsterAI.x - playerX, monsterAI.z - playerZ);
        if (dist < 6.5) {
          const dx = monsterAI.x - playerX;
          const dz = monsterAI.z - playerZ;
          const len = Math.max(0.1, Math.hypot(dx, dz));
          monsterAI.applyHitStagger(
            DIFFICULTY_CONFIGS[difficulty].staggerDurationSec * 1.4,
            (dx / len) * 0.8,
            (dz / len) * 0.8,
          );
          audio.playMonsterStagger();
          showSubtitle(
            'Noah',
            settings.language === 'fr'
              ? 'Fusée éclairante activée ! Le Patient 04 recule sous la lumière !'
              : 'Defense flare ignited! Patient 04 recoils from the light!',
            3.5,
          );
        }
        pushHud();
      };

      const fireWeapon = () => {
        if (phase !== 'playing' || activeHideout || !hasPistol) return;
        if (reloadTimer > 0 || fireCooldown > 0) return;
        if (pistolMag <= 0) {
          audio.playDryFire();
          if (pistolReserve > 0) reloadWeapon();
          return;
        }
        pistolMag--;
        fireCooldown = 0.36;
        recoilPitch = 0.075;
        muzzleFlashTimer = 0.09;
        audio.playGunshot();

        // Notify Patient 04 of gunshot sound anywhere in wing
        monsterAI.notifySound(
          playerX,
          playerZ,
          24 * DIFFICULTY_CONFIGS[difficulty].monsterHearingMultiplier,
          true,
        );

        // Hitscan check against Patient 04
        const fwdX = Math.sin(yaw);
        const fwdZ = Math.cos(yaw);
        const toMx = monsterAI.x - playerX;
        const toMz = monsterAI.z - playerZ;
        const mDist = Math.hypot(toMx, toMz);
        if (mDist < 19.0 && mDist > 0.2) {
          const dot = (toMx / mDist) * fwdX + (toMz / mDist) * fwdZ;
          if (dot > 0.92 && hasLineOfSight2D(playerX, playerZ, monsterAI.x, monsterAI.z, world.colliders)) {
            const kbX = (toMx / mDist) * 0.55;
            const kbZ = (toMz / mDist) * 0.55;
            const [rx, rz] = resolveAabbCircle(
              monsterAI.x + kbX,
              monsterAI.z + kbZ,
              0.38,
              world.colliders,
            );
            monsterAI.applyHitStagger(
              DIFFICULTY_CONFIGS[difficulty].staggerDurationSec,
              rx - monsterAI.x,
              rz - monsterAI.z,
            );
            audio.playMonsterStagger();
            showSubtitle(
              'Noah',
              settings.language === 'fr'
                ? 'Impact direct ! Il est sonné pour quelques secondes !'
                : 'Direct hit! He is staggered for a few seconds!',
              2.6,
            );
          }
        }
        pushHud();
      };

      const reloadWeapon = () => {
        if (!hasPistol || reloadTimer > 0 || pistolMag >= pistolMagSize || pistolReserve <= 0) return;
        reloadTimer = 0.9;
        audio.playReload();
        pushHud();
      };

      const useMedkit = () => {
        if (medkits <= 0 || health >= maxHealth) return;
        medkits--;
        health = Math.min(maxHealth, health + 48);
        audio.playCluePickup();
        pushHud();
      };

      const rechargeBattery = () => {
        if (batteriesCount <= 0 || battery >= 0.98) return;
        batteriesCount--;
        battery = Math.min(1.0, battery + 0.55);
        flashlightOutageTimer = 0;
        audio.playFlashlightClick(true);
        pushHud();
      };

      const openPuzzleModal = (puzzleId: string) => {
        const puz = PUZZLES[puzzleId];
        if (!puz) return;
        activePuzzle = puz;
        phase = 'puzzle';
        heldKeys.clear();
        if (document.pointerLockElement === canvas) document.exitPointerLock?.();
        pushHud();
      };

      const openCctvModal = (chap: ChapterId) => {
        activeCctvChapter = chap;
        phase = 'cctv';
        heldKeys.clear();
        if (document.pointerLockElement === canvas) document.exitPointerLock?.();
        pushHud();
      };

      const unlockAirlock = () => {
        powerRestored = true;
        world.breakerLedMat.diffuseColor.set(0.22, 1.0, 0.62);
        world.breakerLedMat.emissiveColor.set(0.22, 1.0, 0.62);
        audio.playPowerRestore();
        SaveManager.saveSlot(buildSaveSnapshot('auto'));
      };

      const interactWithDoor = (door: DoorTarget) => {
        if (door.kind === 'barricaded') {
          audio.playDoorLocked();
          activeNote = {
            id: door.id,
            title: door.label.toUpperCase(),
            subtitle: settings.language === 'fr' ? 'Accès impossible' : 'Blocked',
            body: door.barricadeMessage ?? 'Cette porte est solidement barricadée.',
          };
          noteTimer = 4.2;
          pushHud();
          return;
        }

        if (door.kind === 'locked' && !door.isUnlocked) {
          if (door.requiredKeyId && hasKey(door.requiredKeyId)) {
            door.isUnlocked = true;
            door.isOpen = true;
            door.targetAngle = door.position.x > 0 ? -1.42 : 1.42;
            door.collider.disabled = true;
            audio.playDoorUnlock();
            activeNote = {
              id: `${door.id}_unlocked`,
              title: `${door.label.toUpperCase()}`,
              subtitle: `${door.requiredKeyLabel ?? ''}`,
              body:
                settings.language === 'fr'
                  ? 'La serrure cède dans un claquement métallique.'
                  : 'The lock clicks open.',
            };
            noteTimer = 3.8;
          } else {
            audio.playDoorLocked();
            activeNote = {
              id: `${door.id}_locked`,
              title: settings.language === 'fr' ? 'PORTE VERROUILLÉE' : 'LOCKED DOOR',
              subtitle: door.label,
              body:
                settings.language === 'fr'
                  ? `Il faut la ${door.requiredKeyLabel ?? 'clé correspondante'} pour ouvrir cette porte.`
                  : `Requires ${door.requiredKeyLabel ?? 'matching key'}.`,
            };
            noteTimer = 3.8;
          }
          pushHud();
          return;
        }

        door.isOpen = !door.isOpen;
        door.targetAngle = door.isOpen ? 1.35 : 0;
        door.collider.disabled = door.isOpen;
        audio.playDoorUnlock();
        pushHud();
      };

      const tryInteract = () => {
        if (phase !== 'playing') return;
        if (activeHideout) {
          exitHideout();
          return;
        }
        if (!currentTarget) return;
        const item = currentTarget;

        if (item.hideoutRef) {
          enterHideout(item.hideoutRef);
          return;
        }

        // Drawers
        if (item.id.startsWith('drawer_')) {
          const dr = world.drawers.find((d) => d.id === item.id);
          if (dr && !dr.isOpen) {
            dr.isOpen = true;
            item.collected = true;
            item.ringMesh.isVisible = false;
            audio.playDoorUnlock();
            monsterAI.notifySound(
              item.position.x,
              item.position.z,
              8.5 * DIFFICULTY_CONFIGS[difficulty].monsterHearingMultiplier,
              false,
            );
            if (dr.lootType === 'ammo') {
              pistolReserve += 6;
              activeNote = {
                id: dr.id,
                title: dr.label,
                subtitle: '+6 Munitions 9mm',
                body: 'Vous trouvez une boîte de cartouches 9mm au fond du tiroir.',
              };
            } else if (dr.lootType === 'medkit') {
              medkits++;
              activeNote = {
                id: dr.id,
                title: dr.label,
                subtitle: '+1 Trousse de soins',
                body: 'Pansements stériles et adrénaline récupérés.',
              };
            } else {
              batteriesCount++;
              activeNote = {
                id: dr.id,
                title: dr.label,
                subtitle: '+1 Pile Lithium',
                body: 'Pile de rechange pour lampe torche [B].',
              };
            }
            noteTimer = 4.0;
            pushHud();
          }
          return;
        }

        // Pistol Pickup
        if (item.id === 'pickup_pistol_9mm') {
          item.collected = true;
          item.root.setEnabled(false);
          hasPistol = true;
          pistolMag = 8;
          pistolReserve += 4;
          audio.playKeyPickup();
          activeNote = item.note ?? null;
          noteTimer = 6.0;
          pushHud();
          return;
        }

        // Supplies
        if (item.id.startsWith('pickup_ammo')) {
          item.collected = true;
          item.root.setEnabled(false);
          pistolReserve += 6;
          audio.playKeyPickup();
          pushHud();
          return;
        }
        if (item.id.startsWith('pickup_battery')) {
          item.collected = true;
          item.root.setEnabled(false);
          batteriesCount++;
          audio.playKeyPickup();
          pushHud();
          return;
        }
        if (item.id.startsWith('pickup_medkit')) {
          item.collected = true;
          item.root.setEnabled(false);
          medkits++;
          audio.playCluePickup();
          pushHud();
          return;
        }
        if (item.id.startsWith('pickup_flare')) {
          item.collected = true;
          item.root.setEnabled(false);
          flaresCount++;
          audio.playCluePickup();
          pushHud();
          return;
        }

        // CCTV Terminal
        if (item.id.startsWith('cctv_terminal')) {
          audio.playUiClick();
          openCctvModal(chapterId);
          return;
        }

        // Puzzles
        if (item.id.startsWith('puzzle_')) {
          if (solvedPuzzleIds.includes(item.id)) {
            audio.playDoorLocked();
            return;
          }
          audio.playUiClick();
          openPuzzleModal(item.id);
          return;
        }

        // Audio Tapes
        if (item.id.startsWith('tape_')) {
          item.collected = true;
          item.root.setEnabled(false);
          if (!discoveredTapeIds.includes(item.id)) discoveredTapeIds.push(item.id);
          SaveManager.recordDiscovery([], [item.id]);
          const tape = AUDIO_TAPES.find((tp) => tp.id === item.id);
          if (tape) {
            const tr = settings.language === 'fr' ? tape.transcript : tape.transcriptEn;
            showSubtitle(tape.speaker, tr, 7.5);
            activeNote = {
              id: tape.id,
              title: settings.language === 'fr' ? tape.title : tape.titleEn,
              subtitle: tape.speaker,
              body: tr,
            };
            noteTimer = 7.0;
          }
          audio.playCluePickup();
          pushHud();
          return;
        }

        // Story / Secret / Premium Documents
        if (item.id.startsWith('doc_')) {
          const doc = STORY_DOCUMENTS.find((d) => d.id === item.id);
          if (doc?.isPremiumBonus && !entitlements.premiumPass) {
            audio.playDoorLocked();
            activeNote = {
              id: 'premium_doc_locked',
              title: 'ARCHIVES PREMIUM PASS',
              subtitle: 'Contenu bonus',
              body:
                settings.language === 'fr'
                  ? 'Ce dossier bonus fait partie du Nocturne 04 Premium Pass (Boutique).'
                  : 'This bonus dossier is part of the Nocturne 04 Premium Pass (Store).',
            };
            noteTimer = 4.5;
            pushHud();
            return;
          }
          item.collected = true;
          item.root.setEnabled(false);
          if (!discoveredDocIds.includes(item.id)) discoveredDocIds.push(item.id);
          SaveManager.recordDiscovery([item.id], []);
          if (!collectedIds.includes(item.id) && !doc?.isPremiumBonus) {
            cluesCollected = Math.min(CHAPTERS[chapterId].totalClues, cluesCollected + 1);
            collectedIds.push(item.id);
          }
          audio.playCluePickup();
          if (doc) {
            activeNote = {
              id: doc.id,
              title: settings.language === 'fr' ? doc.title : doc.titleEn,
              subtitle: `${doc.author} · ${doc.date}`,
              body: settings.language === 'fr' ? doc.body : doc.bodyEn,
            };
            noteTimer = 7.5;
          }
          pushHud();
          return;
        }

        if (item.isBottle) {
          if (bottlesCount >= maxBottles) {
            audio.playDoorLocked();
            return;
          }
          item.collected = true;
          item.root.setEnabled(false);
          bottlesCount++;
          audio.playCluePickup();
          pushHud();
          return;
        }

        if (item.doorRef) {
          interactWithDoor(item.doorRef);
          return;
        }

        if (item.isGeneratorSwitch) {
          if (!generatorRestored) {
            if (chapterId === 'ch1' && !solvedPuzzleIds.includes('puzzle_ch1_gen')) {
              openPuzzleModal('puzzle_ch1_gen');
              return;
            }
            generatorRestored = true;
            item.collected = true;
            item.ringMesh.isVisible = false;
            world.generatorLedMat.diffuseColor.set(0.25, 1.0, 0.58);
            world.generatorLedMat.emissiveColor.set(0.25, 1.0, 0.58);
            audio.playPowerRestore();
            monsterAI.notifySound(-1.5, 5.2, 26, true);
            activeNote = {
              id: 'gen_on',
              title: 'GROUPE ÉLECTROGÈNE ACTIF',
              subtitle: 'Alerte sonore',
              body: 'Le tableau électrique de la Sortie Nord est alimenté. Rejoignez le sas Nord.',
            };
            noteTimer = 5.5;
            pushHud();
          }
          return;
        }

        if (item.isExitPanel) {
          if (chapterId === 'ch1' && (!generatorRestored || cluesCollected < 4)) {
            audio.playDoorLocked();
            activeNote = {
              id: 'need_parts',
              title: 'ALIMENTATION INSUFFISANTE',
              subtitle: `${cluesCollected}/4 composants · Générateur ${generatorRestored ? 'ON' : 'OFF'}`,
              body: !generatorRestored
                ? 'Activez le groupe électrogène au Sud-Ouest et récupérez les 4 composants.'
                : 'Il manque encore des composants dans les ailes.',
            };
            noteTimer = 4.8;
            pushHud();
            return;
          }
          if (chapterId !== 'ch1' && !powerRestored) {
            const requiredPuzzle =
              chapterId === 'ch2'
                ? 'puzzle_ch2_keypad'
                : chapterId === 'ch3'
                  ? 'puzzle_ch3_freq'
                  : chapterId === 'ch4'
                    ? 'puzzle_ch4_lab'
                    : chapterId === 'ch5'
                      ? 'puzzle_ch5_cell04'
                      : chapterId === 'ch6'
                        ? 'puzzle_ch6_core'
                        : 'puzzle_dlc_fire';
            if (!solvedPuzzleIds.includes(requiredPuzzle)) {
              openPuzzleModal(requiredPuzzle);
              return;
            }
          }
          if (!powerRestored) {
            unlockAirlock();
            activeNote = {
              id: 'power_on',
              title: 'SAS NORD DÉVERROUILLÉ',
              subtitle: 'Les portes blindées s’ouvrent',
              body: 'Traversez le sas Nord immédiatement !',
            };
            noteTimer = 4.5;
            pushHud();
          }
          return;
        }

        if (!item.collected) {
          item.collected = true;
          item.root.setEnabled(false);
          if (item.isKey) {
            keys.push({ id: item.id, label: item.keyLabel ?? item.label });
            audio.playKeyPickup();
          } else {
            cluesCollected++;
            collectedIds.push(item.id);
            audio.playCluePickup();
          }
          monsterAI.wakeUp();
          if (item.note) {
            activeNote = item.note;
            noteTimer = 6.5;
          }
          pushHud();
        }
      };

      const completeChapterOrEnding = () => {
        heldKeys.clear();
        if (document.pointerLockElement === canvas) document.exitPointerLock?.();

        if (chapterId === 'dlc1') {
          activeEnding = 'ending_a';
          phase = 'ending_cinematic';
          pushHud();
          return;
        }

        const next = CHAPTERS[chapterId].nextChapter;
        if (next) {
          SaveManager.unlockChapter(next);
          resetChapterState(next, difficulty, true);
          phase = 'chapter_transition';
          pushHud();
          return;
        }

        // Chapter 6 Final Ending resolution!
        const allKnownDocs = new Set([
          ...discoveredDocIds,
          ...SaveManager.loadProgress().discoveredDocIds,
        ]);
        const secretCount = ['doc_ch5_secret_1', 'doc_ch5_secret_2', 'doc_ch5_secret_3'].filter((id) =>
          allKnownDocs.has(id),
        ).length;

        // If player hasn't made a decision yet (e.g. Chapter Select) OR unlocked secret Ending C in Ch5,
        // present the final core override choice before playing the ending cinematic.
        if (!moralDecision || (secretCount >= 3 && moralDecision !== 'take_control')) {
          phase = 'moral_choice';
          pushHud();
          return;
        }

        let chosenEnding: EndingId = 'ending_a';
        if (moralDecision === 'take_control' && secretCount >= 3) {
          chosenEnding = 'ending_c';
        } else if (moralDecision === 'free_patients') {
          chosenEnding = 'ending_b';
        } else {
          chosenEnding = 'ending_a';
        }
        activeEnding = chosenEnding;
        SaveManager.unlockEnding(chosenEnding);
        phase = 'ending_cinematic';
        pushHud();
      };

      apiRef.current = {
        startNewGame: (diff, startChapter = 'ch1') => {
          audio.unlock();
          audio.playUiClick();
          resetChapterState(startChapter, diff, false);
          phase = startChapter === 'ch1' ? 'intro_cinematic' : 'chapter_transition';
          pushHud();
        },
        startChapterDirect: (targetChap, diff) => {
          audio.unlock();
          audio.playUiClick();
          resetChapterState(targetChap, diff ?? difficulty, false);
          phase = 'chapter_transition';
          pushHud();
        },
        loadFromSave: (slot) => {
          audio.unlock();
          audio.playUiClick();
          resetChapterState(slot.chapterId, slot.difficulty, false);
          elapsedPlayTime = slot.elapsedSeconds;
          health = slot.health;
          maxHealth = slot.maxHealth;
          stamina = slot.stamina;
          battery = slot.battery;
          hasPistol = slot.hasPistol;
          pistolMag = slot.pistolMag;
          pistolReserve = slot.pistolReserve;
          medkits = slot.medkits;
          batteriesCount = slot.batteriesCount;
          bottlesCount = slot.bottlesCount;
          flaresCount = slot.flaresCount;
          cluesCollected = slot.cluesCollected;
          collectedIds.splice(0, collectedIds.length, ...slot.collectedIds);
          keys.splice(0, keys.length, ...slot.keys);
          solvedPuzzleIds.splice(0, solvedPuzzleIds.length, ...slot.solvedPuzzleIds);
          discoveredDocIds.splice(0, discoveredDocIds.length, ...slot.discoveredDocIds);
          discoveredTapeIds.splice(0, discoveredTapeIds.length, ...slot.discoveredTapeIds);
          moralDecision = slot.moralDecision;
          generatorRestored = slot.generatorRestored;
          powerRestored = slot.powerRestored;
          selfDestructActive = slot.selfDestructActive;
          selfDestructTimer = slot.selfDestructTimer || 180;
          playerX = slot.playerX;
          playerZ = slot.playerZ;
          yaw = slot.playerYaw;
          targetYaw = slot.playerYaw;
          perspective = slot.perspective;

          // Disable already-collected items
          for (const item of world.interactables) {
            if (collectedIds.includes(item.id) || keys.some((k) => k.id === item.id)) {
              item.collected = true;
              item.root.setEnabled(false);
            }
          }
          if (generatorRestored) {
            world.generatorLedMat.diffuseColor.set(0.25, 1.0, 0.58);
            world.generatorLedMat.emissiveColor.set(0.25, 1.0, 0.58);
          }
          if (powerRestored) {
            world.breakerLedMat.diffuseColor.set(0.22, 1.0, 0.62);
            world.breakerLedMat.emissiveColor.set(0.22, 1.0, 0.62);
          }
          phase = 'playing';
          pushHud();
        },
        saveToSlot: (slotId) => {
          const snap = buildSaveSnapshot(slotId);
          SaveManager.saveSlot(snap);
          return true;
        },
        setPhase: (nextPhase) => {
          if (nextPhase === 'photo_mode') {
            photoCamX = world.camera.position.x;
            photoCamY = world.camera.position.y;
            photoCamZ = world.camera.position.z;
          }
          if (nextPhase !== 'playing' && document.pointerLockElement === canvas) {
            document.exitPointerLock?.();
          }
          phase = nextPhase;
          heldKeys.clear();
          pushHud();
        },
        advanceFromIntro: () => {
          audio.unlock();
          audio.stopSpeech();
          phase = 'chapter_transition';
          pushHud();
        },
        advanceFromTransition: () => {
          audio.unlock();
          audio.stopSpeech();
          phase = 'playing';
          const chapCfg = CHAPTERS[chapterId];
          showSubtitle(
            chapCfg.introSpeaker,
            settings.language === 'fr' ? chapCfg.introQuoteFr : chapCfg.introQuoteEn,
            7.5,
          );
          if (!isTouch) {
            try {
              canvas.requestPointerLock?.();
            } catch {
              // Drag look fallback
            }
          }
          pushHud();
        },
        finishEndingToCredits: () => {
          audio.stopSpeech();
          phase = 'credits';
          pushHud();
        },
        resumeGame: () => {
          audio.unlock();
          phase = 'playing';
          if (!isTouch) {
            try {
              canvas.requestPointerLock?.();
            } catch {
              // Fallback
            }
          }
          pushHud();
        },
        pauseGame: () => {
          phase = 'paused';
          heldKeys.clear();
          if (document.pointerLockElement === canvas) document.exitPointerLock?.();
          pushHud();
        },
        restartChapter: () => {
          audio.unlock();
          resetChapterState(chapterId, difficulty, false);
          phase = 'playing';
          pushHud();
        },
        toggleFlashlight: () => {
          audio.unlock();
          if (battery <= 0.01) {
            audio.playDoorLocked();
            return;
          }
          flashlightOn = !flashlightOn;
          audio.playFlashlightClick(flashlightOn);
          pushHud();
        },
        toggleCrouch: () => {
          if (activeHideout) return;
          crouching = !crouching;
          pushHud();
        },
        triggerJump: () => {
          if (phase !== 'playing' || activeHideout || !isGrounded || crouching) return;
          verticalVel = 4.1;
          isGrounded = false;
        },
        togglePerspective: () => {
          if (activeHideout) return;
          perspective = perspective === 'first_person' ? 'third_person' : 'first_person';
          audio.playUiClick();
          pushHud();
        },
        triggerInteract: () => {
          audio.unlock();
          tryInteract();
        },
        fireWeapon: () => {
          audio.unlock();
          fireWeapon();
        },
        reloadWeapon: () => {
          audio.unlock();
          reloadWeapon();
        },
        useMedkit: () => {
          audio.unlock();
          useMedkit();
        },
        rechargeBattery: () => {
          audio.unlock();
          rechargeBattery();
        },
        throwBottle: () => {
          audio.unlock();
          throwBottle();
        },
        useFlare: () => {
          audio.unlock();
          useFlare();
        },
        solveActivePuzzle: (code) => {
          if (!activePuzzle) return false;
          if (code.trim() === activePuzzle.solutionCode) {
            solvedPuzzleIds.push(activePuzzle.id);
            const solvedId = activePuzzle.id;
            activePuzzle = null;
            audio.playPowerRestore();

            // Mark puzzle mesh collected
            const item = world.interactables.find((i) => i.id === solvedId);
            if (item) {
              item.collected = true;
              item.ringMesh.isVisible = false;
            }

            if (solvedId === 'puzzle_ch1_gen') {
              generatorRestored = true;
              world.generatorLedMat.diffuseColor.set(0.25, 1.0, 0.58);
              world.generatorLedMat.emissiveColor.set(0.25, 1.0, 0.58);
              monsterAI.notifySound(-1.5, 5.2, 26, true);
              phase = 'playing';
            } else if (solvedId === 'puzzle_ch4_lab') {
              phase = 'moral_choice';
            } else if (solvedId === 'puzzle_ch6_core') {
              selfDestructActive = true;
              selfDestructTimer = 180;
              unlockAirlock();
              monsterAI.wakeUp();
              monsterAI.notifySound(playerX, playerZ, 32, true);
              phase = 'playing';
            } else {
              unlockAirlock();
              phase = 'playing';
            }
            pushHud();
            return true;
          }
          audio.playDoorLocked();
          return false;
        },
        cancelPuzzleOrCctv: () => {
          activePuzzle = null;
          activeCctvChapter = null;
          phase = 'playing';
          pushHud();
        },
        chooseMoralDecision: (decision) => {
          moralDecision = decision;
          if (chapterId === 'ch6') {
            const chosenEnding: EndingId =
              decision === 'take_control'
                ? 'ending_c'
                : decision === 'free_patients'
                  ? 'ending_b'
                  : 'ending_a';
            activeEnding = chosenEnding;
            SaveManager.unlockEnding(chosenEnding);
            phase = 'ending_cinematic';
            pushHud();
            return;
          }
          unlockAirlock();
          phase = 'playing';
          showSubtitle(
            'Maya Kanza',
            decision === 'free_patients'
              ? settings.language === 'fr'
                ? 'Les cuves s’ouvrent ! Cours vers le sas Nord, je t’y retrouve !'
                : 'The pods are opening! Run to the North airlock, I’ll meet you there!'
              : settings.language === 'fr'
                ? 'Le sas est ouvert ! Dépêche-toi avant que le Patient 04 ne bloque la sortie !'
                : 'The airlock is open! Hurry before Patient 04 blocks the exit!',
            5.5,
          );
          SaveManager.saveSlot(buildSaveSnapshot('auto'));
          pushHud();
        },
        toggleMute: () => {
          audio.unlock();
          audio.setMuted(!audio.isMuted());
          pushHud();
        },
        toggleGaussianScan: () => {
          world.setGaussianEnabled(!world.isGaussianEnabled());
          pushHud();
        },
        setProfileMode: (mode) => {
          settings.profileMode = mode;
          SaveManager.saveSettings(settings);
          const tierChanged = profiler.setMode(mode);
          if (tierChanged || mode === 'cinematic_4k' || mode === 'cinematic_8k') {
            const cfg = profiler.getConfig();
            world.applyQuality(cfg);
            post.applyQuality(cfg);
            engine.resize();
          }
          pushHud();
        },
        applySettings: (nextSettings) => {
          settings = { ...nextSettings };
          SaveManager.saveSettings(settings);
          audio.setVolumes(settings.masterVolume, settings.musicVolume, settings.sfxVolume);
          world.camera.fov = settings.fov;
          if (profiler.setMode(settings.profileMode)) {
            const cfg = profiler.getConfig();
            world.applyQuality(cfg);
            post.applyQuality(cfg);
            engine.resize();
          }
          pushHud();
        },
        setEntitlements: (ent) => {
          entitlements = { ...ent };
          world.setPremiumSkins(ent.premiumPass);
          pushHud();
        },
        setVisualFilter: (filter) => {
          settings.visualFilter = filter;
          SaveManager.saveSettings(settings);
          pushHud();
        },
        capturePhotoSnapshot: () => {
          try {
            world.scene.render();
            return canvas.toDataURL('image/png');
          } catch {
            return null;
          }
        },
        setJoystick: (x, y) => {
          joyX = x;
          joyY = y;
        },
        setTouchSprint: (s) => {
          touchSprint = s;
        },
        applyLookDelta: (dx, dy) => {
          const sens = settings.mouseSensitivity;
          // Slightly lower touch sensitivity and cap large frame-to-frame jumps to
          // prevent sudden camera snaps on mobile Safari.
          const safeDx = Math.max(-90, Math.min(90, dx));
          const safeDy = Math.max(-90, Math.min(90, dy));
          targetYaw += safeDx * 0.0038 * sens;
          targetPitch = Scalar.Clamp(targetPitch + safeDy * 0.0034 * sens, -1.05, 1.05);
        },
        dismissNote: () => {
          activeNote = null;
          noteTimer = 0;
          pushHud();
        },
        playAudioTape: (tapeId) => {
          audio.unlock();
          const tape = AUDIO_TAPES.find((tp) => tp.id === tapeId);
          if (tape) {
            const text = settings.language === 'fr' ? tape.transcript : tape.transcriptEn;
            audio.speakDialogue(text, settings.language, false);
          }
        },
      };

      const onKeyDown = (e: KeyboardEvent) => {
        if (e.repeat) return;
        const code = e.code;
        heldKeys.add(code);

        if (code === 'Escape' || code === 'KeyP') {
          if (phase === 'playing') apiRef.current.pauseGame();
          else if (phase === 'paused' || phase === 'inventory' || phase === 'codex') {
            apiRef.current.resumeGame();
          } else if (phase === 'puzzle' || phase === 'cctv') {
            apiRef.current.cancelPuzzleOrCctv();
          }
          return;
        }

        if (code === 'KeyM') {
          apiRef.current.toggleMute();
          return;
        }

        if (phase === 'playing') {
          if (code === 'KeyF') apiRef.current.toggleFlashlight();
          else if (code === 'KeyC') apiRef.current.toggleCrouch();
          else if (code === 'Space') {
            e.preventDefault();
            apiRef.current.triggerJump();
          } else if (code === 'KeyV') apiRef.current.togglePerspective();
          else if (code === 'KeyE') tryInteract();
          else if (code === 'KeyR') reloadWeapon();
          else if (code === 'KeyG') throwBottle();
          else if (code === 'KeyX') useFlare();
          else if (code === 'KeyB') rechargeBattery();
          else if (code === 'KeyH') useMedkit();
          else if (code === 'Tab' || code === 'KeyI') {
            e.preventDefault();
            apiRef.current.setPhase('inventory');
          } else if (code === 'KeyJ') {
            apiRef.current.setPhase('codex');
          }
        } else if (phase === 'inventory' && (code === 'Tab' || code === 'KeyI')) {
          e.preventDefault();
          apiRef.current.resumeGame();
        } else if (phase === 'codex' && code === 'KeyJ') {
          apiRef.current.resumeGame();
        }
      };

      const onKeyUp = (e: KeyboardEvent) => {
        heldKeys.delete(e.code);
      };

      const onWindowBlur = () => {
        heldKeys.clear();
        mouseDragging = false;
        joyX = 0;
        joyY = 0;
        touchSprint = false;
      };

      const onCanvasPointerDown = (e: PointerEvent) => {
        if (phase !== 'playing' && phase !== 'photo_mode') return;
        audio.unlock();
        if (e.pointerType === 'mouse' && e.button === 2) {
          e.preventDefault();
          apiRef.current.throwBottle();
          return;
        }
        if (e.pointerType === 'mouse' && e.button === 0) {
          if (phase === 'playing' && document.pointerLockElement === canvas && hasPistol) {
            fireWeapon();
            return;
          }
          mouseDragging = true;
          lastPointerX = e.clientX;
          lastPointerY = e.clientY;
          if (phase === 'playing' && document.pointerLockElement !== canvas) {
            try {
              canvas.requestPointerLock?.();
            } catch {
              // Ignore
            }
          }
        }
      };

      const onContextMenu = (e: MouseEvent) => {
        if (phase === 'playing') e.preventDefault();
      };

      const onPointerMove = (e: PointerEvent) => {
        if (phase !== 'playing' && phase !== 'photo_mode') return;
        const sens = settings.mouseSensitivity;
        if (document.pointerLockElement === canvas) {
          targetYaw += e.movementX * 0.0022 * sens;
          targetPitch = Scalar.Clamp(targetPitch + e.movementY * 0.0022 * sens, -1.18, 1.18);
        } else if (mouseDragging && e.pointerType === 'mouse') {
          const dx = e.clientX - lastPointerX;
          const dy = e.clientY - lastPointerY;
          lastPointerX = e.clientX;
          lastPointerY = e.clientY;
          targetYaw += dx * 0.0042 * sens;
          targetPitch = Scalar.Clamp(targetPitch + dy * 0.0038 * sens, -1.18, 1.18);
        }
      };

      const onPointerUp = () => {
        mouseDragging = false;
      };

      const onResize = () => {
        engine.resize();
      };

      window.addEventListener('keydown', onKeyDown);
      window.addEventListener('keyup', onKeyUp);
      window.addEventListener('blur', onWindowBlur);
      window.addEventListener('resize', onResize);
      canvas.addEventListener('pointerdown', onCanvasPointerDown);
      canvas.addEventListener('contextmenu', onContextMenu);
      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);

      pushHud();

      let frameId = 0;
      let lastTime = performance.now();
      let totalElapsed = 0;
      let disposed = false;

      const gl = canvas.getContext('webgl2') as WebGL2RenderingContext | null;
      function afterDraw(cb: () => void) {
        if (!gl || !gl.fenceSync) {
          frameId = window.setTimeout(cb, 80);
          return;
        }
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      }

      const tick = () => {
        if (disposed) return;
        const now = performance.now();
        const rawDt = (now - lastTime) / 1000;
        lastTime = now;
        const dt = Math.min(Math.max(rawDt, 0.001), 0.05);
        totalElapsed += dt;

        if (profiler.recordFrame(rawDt)) {
          const cfg = profiler.getConfig();
          world.applyQuality(cfg);
          post.applyQuality(cfg);
          engine.resize();
        }

        if (subtitleTimer > 0) {
          subtitleTimer -= dt;
          if (subtitleTimer <= 0) {
            subtitleText = null;
            subtitleSpeaker = null;
          }
        }

        if (phase === 'title' || phase === 'intro_cinematic' || phase === 'chapter_transition' || phase === 'shop') {
          const panZ = 10.5 - (Math.sin(totalElapsed * 0.16) * 0.5 + 0.5) * 19.5;
          const panX = Math.sin(totalElapsed * 0.27) * 0.42;
          world.camera.position.set(panX, 1.48 + Math.sin(totalElapsed * 0.65) * 0.03, panZ);
          world.camera.rotation.set(
            0.04 + Math.sin(totalElapsed * 0.22) * 0.03,
            Math.PI + Math.sin(totalElapsed * 0.18) * 0.14,
            0,
          );
          world.noahRig.root.setEnabled(false);
          world.fpGear.root.setEnabled(false);
          world.monster.root.position.set(0, 0, -14.2);
          world.updateDynamicElements(totalElapsed, dt, true, 1.0, false, false, 0, () => {});
        } else if (phase === 'photo_mode') {
          const angAlpha = 1 - Math.exp(-16 * dt);
          yaw = Scalar.Lerp(yaw, targetYaw, angAlpha);
          pitch = Scalar.Lerp(pitch, targetPitch, angAlpha);
          let mf = 0;
          let mr = 0;
          if (heldKeys.has('KeyW') || heldKeys.has('KeyZ') || heldKeys.has('ArrowUp')) mf += 1;
          if (heldKeys.has('KeyS') || heldKeys.has('ArrowDown')) mf -= 1;
          if (heldKeys.has('KeyD') || heldKeys.has('ArrowRight')) mr += 1;
          if (heldKeys.has('KeyA') || heldKeys.has('KeyQ') || heldKeys.has('ArrowLeft')) mr -= 1;
          const fwdX = Math.sin(yaw);
          const fwdZ = Math.cos(yaw);
          const rgtX = Math.cos(yaw);
          const rgtZ = -Math.sin(yaw);
          photoCamX += (fwdX * mf + rgtX * mr) * 3.0 * dt;
          photoCamZ += (fwdZ * mf + rgtZ * mr) * 3.0 * dt;
          if (heldKeys.has('Space')) photoCamY += 2.0 * dt;
          if (heldKeys.has('KeyC')) photoCamY = Math.max(0.25, photoCamY - 2.0 * dt);
          world.camera.position.set(photoCamX, photoCamY, photoCamZ);
          world.camera.rotation.set(pitch, yaw, 0);
          world.noahRig.root.setEnabled(true);
          world.fpGear.root.setEnabled(false);
        } else if (phase === 'playing') {
          elapsedPlayTime += dt;
          const diffCfg = DIFFICULTY_CONFIGS[difficulty];

          // Self-destruct countdown in Chapter 6
          if (selfDestructActive) {
            selfDestructTimer -= dt;
            if (selfDestructTimer <= 0) {
              health = 0;
              phase = 'caught';
              audio.playCaughtSting();
              pushHud();
            }
          }

          // Auto-save every 45 seconds
          autoSaveTimer += dt;
          if (autoSaveTimer >= 45) {
            autoSaveTimer = 0;
            SaveManager.saveSlot(buildSaveSnapshot('auto'));
          }

          // Timers
          if (fireCooldown > 0) fireCooldown = Math.max(0, fireCooldown - dt);
          if (damageFlashTimer > 0) damageFlashTimer = Math.max(0, damageFlashTimer - dt);
          if (flareFlashTimer > 0) flareFlashTimer = Math.max(0, flareFlashTimer - dt);
          recoilPitch = Scalar.Lerp(recoilPitch, 0, 1 - Math.exp(-14 * dt));

          if (muzzleFlashTimer > 0) {
            muzzleFlashTimer -= dt;
            world.fpGear.muzzleFlashMesh.isVisible = true;
            world.fpGear.muzzleFlashLight.intensity = 12;
          } else {
            world.fpGear.muzzleFlashMesh.isVisible = false;
            world.fpGear.muzzleFlashLight.intensity = 0;
          }

          if (reloadTimer > 0) {
            reloadTimer -= dt;
            if (reloadTimer <= 0) {
              const needed = pistolMagSize - pistolMag;
              const load = Math.min(needed, pistolReserve);
              pistolMag += load;
              pistolReserve -= load;
              pushHud();
            }
          }

          // Flashlight battery & monster EMP flicker/outage
          if (flashlightOutageTimer > 0) {
            flashlightOutageTimer = Math.max(0, flashlightOutageTimer - dt);
          }
          if (flashlightOn && !activeHideout) {
            battery = Math.max(0, battery - diffCfg.batteryDrainPerSec * dt);
            if (battery <= 0.002) {
              flashlightOn = false;
              audio.playFlashlightClick(false);
            }
          }

          let flickerMult = 1.0;
          if (flashlightOutageTimer > 0) {
            flickerMult = 0.04;
          } else if (battery < 0.16 || monsterAI.dangerLevel > 0.58) {
            flickerMult = Math.sin(totalElapsed * 42) > -0.25 ? 0.92 : 0.15;
          }
          if (flareFlashTimer > 0) {
            world.bounceLight.intensity = 5.5;
            world.bounceLight.diffuse.set(1.0, 0.45, 0.25);
          } else {
            world.bounceLight.diffuse.set(0.55, 0.74, 0.92);
          }

          if (lockerDoorTimer > 0) {
            lockerDoorTimer -= dt;
            if (lockerDoorTimer <= 0) {
              if (activeHideout && activeHideout.kind === 'locker') {
                activeHideout.targetDoorAngle = 0;
              } else {
                for (const h of world.hideouts) {
                  if (h.kind === 'locker') h.targetDoorAngle = 0;
                }
              }
            }
          }

          if (activeHideout) {
            const maxYawOff = activeHideout.kind === 'locker' ? 0.48 : 0.85;
            let yawDiff = targetYaw - activeHideout.baseYaw;
            while (yawDiff > Math.PI) yawDiff -= Math.PI * 2;
            while (yawDiff < -Math.PI) yawDiff += Math.PI * 2;
            yawDiff = Scalar.Clamp(yawDiff, -maxYawOff, maxYawOff);
            targetYaw = activeHideout.baseYaw + yawDiff;
            targetPitch = Scalar.Clamp(targetPitch, -0.26, 0.25);
          }

          const angAlpha = 1 - Math.exp(-18 * dt);
          yaw = Scalar.Lerp(yaw, targetYaw, angAlpha);
          pitch = Scalar.Lerp(pitch, targetPitch, angAlpha);

          let canSprint = false;
          let movingMag = 0;
          if (activeHideout) {
            stamina = Math.min(1, stamina + dt * 0.28);
            if (exhausted && stamina > 0.25) exhausted = false;
            const breath = Math.sin(totalElapsed * 2.1) * 0.004;
            world.camera.position.set(
              activeHideout.cameraPos.x,
              activeHideout.cameraPos.y + breath,
              activeHideout.cameraPos.z,
            );
            world.camera.rotation.set(pitch, yaw, 0);
            world.noahRig.root.setEnabled(false);
            world.fpGear.root.setEnabled(false);
          } else {
            let moveForward = 0;
            let moveRight = 0;
            if (heldKeys.has('KeyW') || heldKeys.has('KeyZ') || heldKeys.has('ArrowUp')) moveForward += 1;
            if (heldKeys.has('KeyS') || heldKeys.has('ArrowDown')) moveForward -= 1;
            if (heldKeys.has('KeyD') || heldKeys.has('ArrowRight')) moveRight += 1;
            if (heldKeys.has('KeyA') || heldKeys.has('KeyQ') || heldKeys.has('ArrowLeft')) moveRight -= 1;

            moveForward -= joyY;
            moveRight += joyX;

            const wantsSprint =
              touchSprint || heldKeys.has('ShiftLeft') || heldKeys.has('ShiftRight');
            const movingInput = Math.abs(moveForward) > 0.05 || Math.abs(moveRight) > 0.05;
            canSprint = wantsSprint && !crouching && !exhausted && movingInput && stamina > 0.01;

            if (canSprint) {
              stamina = Math.max(0, stamina - dt * 0.22);
              if (stamina <= 0.01) exhausted = true;
            } else {
              stamina = Math.min(1, stamina + dt * (crouching ? 0.24 : 0.16));
              if (exhausted && stamina > 0.25) exhausted = false;
            }

            const speed = crouching ? 1.25 : canSprint ? 3.55 : 2.05;

            _forward.set(Math.sin(yaw), 0, Math.cos(yaw));
            _right.set(Math.cos(yaw), 0, -Math.sin(yaw));
            _moveDir.set(
              _forward.x * moveForward + _right.x * moveRight,
              0,
              _forward.z * moveForward + _right.z * moveRight,
            );

            movingMag = _moveDir.length();
            if (movingMag > 0.02) {
              if (movingMag > 1) _moveDir.scaleInPlace(1 / movingMag);
              const nextX = playerX + _moveDir.x * speed * dt;
              const nextZ = playerZ + _moveDir.z * speed * dt;
              const [rx, rz] = resolveAabbCircle(nextX, nextZ, 0.36, world.colliders);
              playerX = rx;
              playerZ = rz;

              const strideSpeed = crouching ? 5.2 : canSprint ? 11.2 : 7.4;
              headBobPhase += dt * strideSpeed * Math.min(1, movingMag);
              const halfStep = Math.floor(headBobPhase / Math.PI);
              if (halfStep !== lastStrideHalf) {
                lastStrideHalf = halfStep;
                const inPuddle = world.puddles.some(
                  (p) => Math.hypot(playerX - p.x, playerZ - p.z) < p.radius,
                );
                audio.playFootstep(canSprint, crouching, inPuddle && isGrounded);
              }
            }

            // Jump vertical physics
            if (!isGrounded) {
              verticalVel -= 12.5 * dt;
              playerY += verticalVel * dt;
              if (playerY <= 0) {
                playerY = 0;
                verticalVel = 0;
                isGrounded = true;
              }
            }

            const targetEye = (crouching ? 1.05 : 1.62) + playerY;
            eyeHeight = Scalar.Lerp(eyeHeight, targetEye, 1 - Math.exp(-12 * dt));
            const bobY =
              movingMag > 0.05 && isGrounded
                ? Math.sin(headBobPhase * 2) * (crouching ? 0.015 : canSprint ? 0.042 : 0.026)
                : Math.sin(totalElapsed * 1.9) * (health < 45 ? 0.014 : 0.004);
            const bobX =
              movingMag > 0.05 && isGrounded
                ? Math.cos(headBobPhase) * (canSprint ? 0.024 : 0.014)
                : 0;

            if (perspective === 'first_person') {
              world.noahRig.root.setEnabled(false);
              world.fpGear.root.setEnabled(true);
              world.fpGear.flashlightNode.setEnabled(flashlightOn);
              world.fpGear.pistolNode.setEnabled(hasPistol);
              world.fpGear.pistolNode.position.y = -0.19 - (reloadTimer > 0 ? 0.14 : 0) + recoilPitch * 0.25;
              world.fpGear.pistolNode.rotation.x = -recoilPitch * 2.2 + (reloadTimer > 0 ? 0.55 : 0);

              world.camera.position.set(playerX + bobX, eyeHeight + bobY, playerZ);
              world.camera.rotation.set(pitch - recoilPitch, yaw, 0);
            } else {
              // 3rd Person Over-the-Shoulder Camera + Noah 3D Character Rig
              world.fpGear.root.setEnabled(false);
              world.noahRig.root.setEnabled(true);
              world.noahRig.root.position.set(playerX, playerY, playerZ);
              world.noahRig.root.rotation.y = yaw;
              world.noahRig.root.scaling.y = crouching ? 0.72 : 1.0;
              world.noahRig.pistolMesh.setEnabled(hasPistol);
              const limbSwing = movingMag > 0.05 ? Math.sin(headBobPhase) * 0.55 : 0;
              world.noahRig.leftLeg.rotation.x = limbSwing;
              world.noahRig.rightLeg.rotation.x = -limbSwing;
              world.noahRig.leftArm.rotation.x = flashlightOn ? -1.1 : -limbSwing * 0.4;
              world.noahRig.rightArm.rotation.x = hasPistol ? -1.3 : limbSwing * 0.4;

              const backDist = 1.65;
              const sideOff = 0.36;
              let camX = playerX - Math.sin(yaw) * backDist + Math.cos(yaw) * sideOff;
              let camZ = playerZ - Math.cos(yaw) * backDist - Math.sin(yaw) * sideOff;
              [camX, camZ] = resolveAabbCircle(camX, camZ, 0.22, world.colliders);
              world.camera.position.set(camX, eyeHeight + 0.28 + bobY, camZ);
              world.camera.rotation.set(pitch - recoilPitch * 0.4, yaw, 0);
            }
          }

          // Thrown bottle physics
          if (bottleProj.active) {
            bottleProj.age += dt;
            bottleProj.vy -= 14.5 * dt;
            const nx = bottleProj.x + bottleProj.vx * dt;
            const ny = bottleProj.y + bottleProj.vy * dt;
            const nz = bottleProj.z + bottleProj.vz * dt;
            const [rx, rz] = resolveAabbCircle(nx, nz, 0.09, world.colliders);
            const hitWall = Math.hypot(rx - nx, rz - nz) > 0.015;
            bottleProj.x = rx;
            bottleProj.y = ny;
            bottleProj.z = rz;
            world.thrownBottleMesh.position.set(rx, Math.max(0.05, ny), rz);
            world.thrownBottleMesh.rotation.x += dt * 11;
            world.thrownBottleMesh.rotation.z += dt * 7;

            if (ny <= 0.08 || hitWall || bottleProj.age > 3.5) {
              bottleProj.active = false;
              world.thrownBottleMesh.setEnabled(false);
              world.triggerGlassShatter(new Vector3(rx, 0.04, rz));
              audio.playBottleBreak();
              monsterAI.notifySound(rx, rz, 26, true);
              pushHud();
            }
          }

          // Update Patient 04 AI
          const mSnap = monsterAI.update({
            dt,
            elapsed: elapsedPlayTime,
            chapterId,
            diff: diffCfg,
            playerX,
            playerZ,
            playerCrouching: crouching,
            playerSprinting: canSprint,
            flashlightOn,
            activeHideout,
            hideoutSeenByMonster,
            generatorRestored,
            cluesCollected,
            colliders: world.colliders,
            doors: world.doors,
            hideouts: world.hideouts,
            hasLineOfSight: (ax, az, bx, bz) => hasLineOfSight2D(ax, az, bx, bz, world.colliders),
            resolveCircle: (px, pz, rad) => resolveAabbCircle(px, pz, rad, world.colliders),
            getZone,
            getZoneThreshold,
            onAlert: () => {
              audio.playMonsterAlert();
              if (Math.random() < 0.35) flashlightOutageTimer = 1.1;
            },
            onStep: (mx, mz) => audio.playMonsterStepSpatial(mx, mz, playerX, playerZ, yaw),
            onDoorBang: () => audio.playDoorBang(),
            onDoorBreak: (d) => {
              d.isOpen = true;
              d.targetAngle = d.position.x > 0 ? -1.42 : 1.42;
              d.collider.disabled = true;
              audio.playDoorUnlock();
            },
            onFlushHideout: () => exitHideout(),
            onAttackPlayer: (dmg) => {
              health = Math.max(0, health - dmg);
              damageFlashTimer = 0.45;
              audio.playDamageHit();
              if (health <= 0) {
                phase = 'caught';
                heldKeys.clear();
                if (document.pointerLockElement === canvas) document.exitPointerLock?.();
                audio.playCaughtSting();
                targetYaw = Math.atan2(monsterAI.x - playerX, monsterAI.z - playerZ);
                yaw = targetYaw;
                pitch = 0.06;
                targetPitch = 0.06;
                world.camera.rotation.set(pitch, yaw, 0);
              }
              pushHud();
            },
            onMimicVoice: () => {
              const cfg = CHAPTERS[chapterId];
              const lines = settings.language === 'fr' ? cfg.mimicLinesFr : cfg.mimicLinesEn;
              const line = lines[Math.floor(Math.random() * lines.length)];
              showSubtitle('Patient 04 (Voix imitée)', line, 4.4, true);
            },
          });

          // Animate Monster 3D Rig
          const swing =
            mSnap.state === 'staggered'
              ? 0.15 * Math.sin(totalElapsed * 16)
              : Math.sin(mSnap.walkPhase) * (mSnap.state === 'chase' ? 0.55 : 0.35);
          world.monster.root.position.set(
            mSnap.x,
            mSnap.state === 'staggered' ? -0.06 : Math.abs(Math.sin(mSnap.walkPhase)) * 0.05,
            mSnap.z,
          );
          world.monster.root.rotation.y = mSnap.yaw;
          world.monster.leftLeg.rotation.x = swing;
          world.monster.rightLeg.rotation.x = -swing;
          world.monster.leftArm.rotation.x =
            mSnap.state === 'chase' || mSnap.state === 'attack' ? -0.95 - swing * 0.4 : -swing * 0.45;
          world.monster.rightArm.rotation.x =
            mSnap.state === 'chase' || mSnap.state === 'attack' ? -0.95 + swing * 0.4 : swing * 0.45;
          world.monster.head.rotation.z =
            mSnap.state === 'staggered' ? 0.35 : Math.sin(totalElapsed * 2.4) * 0.14;
          const eyePulse =
            mSnap.state === 'chase' ? 1.0 : mSnap.state === 'staggered' ? 0.25 : 0.55 + 0.25 * Math.sin(totalElapsed * 4.0);
          world.monster.eyeMat.emissiveColor.set(eyePulse, 0.14 * eyePulse, 0.1 * eyePulse);

          audio.update(
            dt,
            mSnap.dangerLevel,
            mSnap.state === 'chase' || mSnap.state === 'attack',
            stamina,
            health / maxHealth,
            selfDestructActive,
          );

          // Interactable detection
          let bestItem: InteractableTarget | null = null;
          let nextPrompt: string | null = null;
          if (activeHideout) {
            nextPrompt = settings.language === 'fr' ? 'Sortir de la cachette' : 'Exit hideout';
          } else {
            let bestScore = 0.55;
            world.camera.getDirectionToRef(Vector3.Forward(), _camForward);
            for (let i = 0; i < world.interactables.length; i++) {
              const item = world.interactables[i];
              if (item.collected && !item.doorRef) continue;
              item.position.subtractToRef(world.camera.position, _toItem);
              const dist = _toItem.length();
              const maxDist = item.doorRef ? 2.9 : item.hideoutRef ? 2.6 : 2.75;
              if (dist < maxDist && dist > 1e-4) {
                _toItem.scaleInPlace(1 / dist);
                const align = Vector3.Dot(_toItem, _camForward);
                if (align > 0.55 && align > bestScore) {
                  bestScore = align;
                  bestItem = item;
                }
              }
            }

            if (bestItem) {
              if (bestItem.hideoutRef) {
                nextPrompt = `${settings.language === 'fr' ? 'Se cacher' : 'Hide'} : ${bestItem.hideoutRef.label}`;
              } else if (bestItem.isBottle) {
                nextPrompt =
                  bottlesCount >= maxBottles
                    ? `${settings.language === 'fr' ? 'Bouteilles max' : 'Bottles full'} (${bottlesCount}/${maxBottles})`
                    : bestItem.label;
              } else if (bestItem.doorRef) {
                const d = bestItem.doorRef;
                if (d.kind === 'barricaded') nextPrompt = `${d.label} · Inspecter`;
                else if (d.kind === 'locked' && !d.isUnlocked) {
                  nextPrompt =
                    d.requiredKeyId && hasKey(d.requiredKeyId)
                      ? `Déverrouiller : ${d.label}`
                      : `${d.label} (${d.requiredKeyLabel})`;
                } else {
                  nextPrompt = d.isOpen ? `Fermer : ${d.label}` : `Ouvrir : ${d.label}`;
                }
              } else {
                nextPrompt = bestItem.label;
              }
            }
          }

          currentTarget = bestItem;
          if (nextPrompt !== currentPrompt) {
            currentPrompt = nextPrompt;
            pushHud();
          }

          if (activeNote && noteTimer > 0) {
            noteTimer -= dt;
            if (noteTimer <= 0) {
              activeNote = null;
              pushHud();
            }
          }

          // North Exit Airlock Trigger -> Advance Chapter or Ending!
          if (powerRestored && playerZ < -15.32 && Math.abs(playerX) < 1.35) {
            completeChapterOrEnding();
          }

          world.updateDynamicElements(
            totalElapsed,
            dt,
            flashlightOn,
            flickerMult,
            powerRestored,
            generatorRestored,
            cluesCollected,
            () => audio.playFlickerBuzz(),
          );
        } else {
          world.updateDynamicElements(
            totalElapsed,
            dt,
            flashlightOn,
            1.0,
            powerRestored,
            generatorRestored,
            cluesCollected,
            () => {},
          );
        }

        hudSyncTimer += dt;
        if (hudSyncTimer >= 0.2) {
          hudSyncTimer = 0;
          pushHud();
        }

        const shaderDanger =
          phase === 'title' || phase === 'ending_cinematic' || phase === 'credits'
            ? 0
            : phase === 'caught'
              ? 0.94
              : Math.max(monsterAI.dangerLevel, damageFlashTimer > 0 ? 0.72 : 0);
        post.updateDanger(shaderDanger, totalElapsed);

        world.scene.render();

        if (isSoftwareGl) {
          afterDraw(tick);
        } else {
          frameId = requestAnimationFrame(tick);
        }
      };

      tick();

      return () => {
        disposed = true;
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);
        window.removeEventListener('keydown', onKeyDown);
        window.removeEventListener('keyup', onKeyUp);
        window.removeEventListener('blur', onWindowBlur);
        window.removeEventListener('resize', onResize);
        canvas.removeEventListener('pointerdown', onCanvasPointerDown);
        canvas.removeEventListener('contextmenu', onContextMenu);
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        audio.dispose();
        post.dispose();
        world.dispose();
        engine.dispose();
        if (canvas.parentElement === container) {
          container.removeChild(canvas);
        }
      };
    }, []);

    return <div ref={mountRef} className="absolute inset-0 w-full h-full overflow-hidden bg-[#030509]" />;
  },
);
