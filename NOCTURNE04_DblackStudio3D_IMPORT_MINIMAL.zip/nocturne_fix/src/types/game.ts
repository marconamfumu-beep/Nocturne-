export type GamePhase =
  | 'title'
  | 'intro_cinematic'
  | 'chapter_transition'
  | 'playing'
  | 'paused'
  | 'inventory'
  | 'codex'
  | 'puzzle'
  | 'cctv'
  | 'moral_choice'
  | 'photo_mode'
  | 'ending_cinematic'
  | 'credits'
  | 'caught'
  | 'shop';

export type ChapterId = 'ch1' | 'ch2' | 'ch3' | 'ch4' | 'ch5' | 'ch6' | 'dlc1';

export type DifficultyId = 'easy' | 'normal' | 'nightmare';

export type CameraPerspective = 'first_person' | 'third_person';

export type Language = 'fr' | 'en';

export type EndingId = 'ending_a' | 'ending_b' | 'ending_c';

export type MoralDecisionId = 'free_patients' | 'seal_wing' | 'take_control';

export type MonsterAIState =
  | 'dormant'
  | 'patrol'
  | 'suspicion'
  | 'investigate'
  | 'chase'
  | 'search'
  | 'attack'
  | 'staggered'
  | 'return';

export type RenderProfileMode =
  | 'auto'
  | 'console_ultra'
  | 'cinematic_4k'
  | 'cinematic_8k'
  | 'mobile_landscape'
  | 'performance';

export type DynamicTier = 'ultra' | 'high' | 'balanced' | 'performance';

export type VisualFilterMode = 'none' | 'vhs' | 'night_vision';

export interface RenderQualityConfig {
  tier: DynamicTier;
  label: string;
  pixelRatioCap: number;
  shadowMapSize: number;
  shadowsEnabled: boolean;
  pcfShadows: boolean;
  hdrEnabled: boolean;
  bloomEnabled: boolean;
  bloomScale: number;
  ssaoEnabled: boolean;
  mirrorReflections: boolean;
  sharpenEnabled: boolean;
  gradingEnabled: boolean;
  lensEffectsEnabled: boolean;
  volumetricsEnabled: boolean;
  puddleRipples: boolean;
  maxActivePointLights: number;
  dustRatio: number;
  gaussianEnabled: boolean;
}

export interface ClueNote {
  id: string;
  title: string;
  subtitle: string;
  body: string;
  speaker?: string;
}

export interface KeyBadgeInfo {
  id: string;
  label: string;
}

export interface StoryDocument {
  id: string;
  chapterId: ChapterId;
  title: string;
  titleEn: string;
  category: 'dossier' | 'memo' | 'secret' | 'premium';
  date: string;
  author: string;
  body: string;
  bodyEn: string;
  isSecretForEndingC?: boolean;
  isPremiumBonus?: boolean;
}

export interface AudioTape {
  id: string;
  chapterId: ChapterId;
  title: string;
  titleEn: string;
  speaker: string;
  durationSec: number;
  transcript: string;
  transcriptEn: string;
}

export interface CctvFeed {
  id: string;
  camCode: string;
  location: string;
  locationEn: string;
  chapterId: ChapterId;
  monsterVisible: boolean;
  statusText: string;
  statusTextEn: string;
  hint: string;
  hintEn: string;
}

export interface PuzzleDefinition {
  id: string;
  chapterId: ChapterId;
  kind: 'keypad' | 'circuit' | 'frequency';
  title: string;
  titleEn: string;
  prompt: string;
  promptEn: string;
  solutionCode: string;
  clueHint: string;
  clueHintEn: string;
}

export interface InventoryItem {
  id: string;
  kind: 'weapon' | 'key' | 'medical' | 'battery' | 'ammo' | 'bottle' | 'flare' | 'quest' | 'secret';
  label: string;
  labelEn: string;
  description: string;
  descriptionEn: string;
  quantity: number;
}

export interface GameSettings {
  language: Language;
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  mouseSensitivity: number;
  fov: number;
  subtitlesEnabled: boolean;
  profileMode: RenderProfileMode;
  visualFilter: VisualFilterMode;
}

export interface EntitlementState {
  premiumPass: boolean;
  dlcForgottenFiles: boolean;
  token: string | null;
  customerEmail: string | null;
  verifiedAt: string | null;
}

export interface ShopProduct {
  id: 'premium_pass' | 'dlc_dossiers';
  sku: string;
  name: string;
  nameEn: string;
  priceUsd: number;
  priceDisplay: string;
  tagline: string;
  taglineEn: string;
  imageUrl: string;
  features: string[];
  featuresEn: string[];
}

export interface TransactionRecord {
  id: string;
  productId: 'premium_pass' | 'dlc_dossiers';
  productName: string;
  amountCents: number;
  currency: string;
  status: 'paid' | 'pending' | 'failed';
  createdAt: string;
  customerEmail: string;
  sessionId: string;
}

export interface SaveSlotData {
  slotId: 'auto' | 'slot1' | 'slot2' | 'slot3';
  savedAt: string;
  chapterId: ChapterId;
  difficulty: DifficultyId;
  elapsedSeconds: number;
  health: number;
  maxHealth: number;
  stamina: number;
  battery: number;
  hasPistol: boolean;
  pistolMag: number;
  pistolReserve: number;
  medkits: number;
  batteriesCount: number;
  bottlesCount: number;
  flaresCount: number;
  cluesCollected: number;
  collectedIds: string[];
  keys: KeyBadgeInfo[];
  solvedPuzzleIds: string[];
  discoveredDocIds: string[];
  discoveredTapeIds: string[];
  moralDecision: MoralDecisionId | null;
  generatorRestored: boolean;
  powerRestored: boolean;
  selfDestructActive: boolean;
  selfDestructTimer: number;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  perspective: CameraPerspective;
}

export interface GlobalProgressData {
  unlockedChapters: ChapterId[];
  unlockedEndings: EndingId[];
  discoveredDocIds: string[];
  discoveredTapeIds: string[];
  profileId: string;
  lastPlayedAt: string | null;
}

export interface HudSnapshot {
  phase: GamePhase;
  chapterId: ChapterId;
  chapterLabel: string;
  chapterTitle: string;
  objectiveText: string;
  difficulty: DifficultyId;
  perspective: CameraPerspective;
  health: number;
  maxHealth: number;
  battery: number;
  flashlightOn: boolean;
  flashlightFlickering: boolean;
  flashlightOutage: boolean;
  hasPistol: boolean;
  pistolMag: number;
  pistolMagSize: number;
  pistolReserve: number;
  isReloading: boolean;
  medkits: number;
  batteriesCount: number;
  bottlesCount: number;
  maxBottles: number;
  flaresCount: number;
  cluesCollected: number;
  totalClues: number;
  collectedIds: string[];
  keys: KeyBadgeInfo[];
  discoveredDocIds: string[];
  discoveredTapeIds: string[];
  solvedPuzzleIds: string[];
  moralDecision: MoralDecisionId | null;
  generatorRestored: boolean;
  powerRestored: boolean;
  selfDestructActive: boolean;
  selfDestructTimer: number;
  activePuzzle: PuzzleDefinition | null;
  activeCctvChapter: ChapterId | null;
  activeEnding: EndingId | null;
  promptText: string | null;
  activeNote: ClueNote | null;
  subtitleText: string | null;
  subtitleSpeaker: string | null;
  sprinting: boolean;
  crouching: boolean;
  isHidden: boolean;
  isHiding: boolean;
  hideoutKind: 'locker' | 'bed' | null;
  hidingSpotLabel: string | null;
  dangerLevel: number;
  monsterState: MonsterAIState;
  monsterChasing: boolean;
  gaussianScanEnabled: boolean;
  stamina: number;
  muted: boolean;
  elapsedSeconds: number;
  profileMode: RenderProfileMode;
  activeTier: DynamicTier;
  fps: number;
  frameMs: number;
  isTouchDevice: boolean;
  isSoftwareGl: boolean;
  entitlements: EntitlementState;
  visualFilter: VisualFilterMode;
}
