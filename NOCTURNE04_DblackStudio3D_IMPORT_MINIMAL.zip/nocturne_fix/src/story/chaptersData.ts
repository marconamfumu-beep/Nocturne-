import type {
  AudioTape,
  CctvFeed,
  ChapterId,
  EndingId,
  PuzzleDefinition,
  ShopProduct,
  StoryDocument,
} from '../types/game';

export interface ChapterConfig {
  id: ChapterId;
  order: number;
  labelFr: string;
  labelEn: string;
  titleFr: string;
  titleEn: string;
  locationFr: string;
  locationEn: string;
  summaryFr: string;
  summaryEn: string;
  introQuoteFr: string;
  introQuoteEn: string;
  introSpeaker: string;
  fogColor: [number, number, number];
  fogDensity: number;
  ambientTint: [number, number, number];
  totalClues: number;
  nextChapter: ChapterId | null;
  isDlc?: boolean;
  monsterBehaviorNoteFr: string;
  monsterBehaviorNoteEn: string;
  mimicLinesFr: string[];
  mimicLinesEn: string[];
}

export const CHAPTERS: Record<ChapterId, ChapterConfig> = {
  ch1: {
    id: 'ch1',
    order: 1,
    labelFr: 'CHAPITRE 1',
    labelEn: 'CHAPTER 1',
    titleFr: 'L’Aile de Quarantaine',
    titleEn: 'The Quarantine Wing',
    locationFr: 'Pavillon Kambala · Secteur Nord-Est',
    locationEn: 'Kambala Pavilion · North-East Wing',
    summaryFr:
      '02h17. Maya appelle Noah avant que la grille de l’hôpital ne se referme. Trouvez les clés, relancez le générateur et survivez à la première traque du Patient 04.',
    summaryEn:
      '02:17 AM. Maya calls Noah before the hospital gate locks behind him. Find the keys, restore the generator, and survive Patient 04’s first hunt.',
    introQuoteFr:
      '« Noah… si tu entends ma voix, ne viens pas seul. Ils ont rallumé les lumières. Le Patient 04 est encore là. Et surtout… ne lui réponds pas quand il prononce ton nom. »',
    introQuoteEn:
      '"Noah… if you hear my voice, don’t come alone. They turned the lights back on. Patient 04 is still here. And above all… never answer when he speaks your name."',
    introSpeaker: 'Maya Kanza · Appel 02h17',
    fogColor: [0.022, 0.035, 0.052],
    fogDensity: 0.044,
    ambientTint: [0.42, 0.56, 0.74],
    totalClues: 4,
    nextChapter: 'ch2',
    monsterBehaviorNoteFr: 'Patrouille lente · Attiré par la lampe torche et le bruit du générateur.',
    monsterBehaviorNoteEn: 'Slow patrol · Drawn to flashlight beams and generator noise.',
    mimicLinesFr: [
      'Noah… c’est moi, Maya… ouvre la porte…',
      'Ne cours pas… je sais que tu es derrière le chariot…',
    ],
    mimicLinesEn: [
      'Noah… it’s me, Maya… open the door…',
      'Don’t run… I know you’re behind the cart…',
    ],
  },
  ch2: {
    id: 'ch2',
    order: 2,
    labelFr: 'CHAPITRE 2',
    labelEn: 'CHAPTER 2',
    titleFr: 'Les Archives Interdites',
    titleEn: 'The Forbidden Archives',
    locationFr: 'Sous-sol -1 · Dépôt des Dossiers NOCTURNE',
    locationEn: 'Basement -1 · NOCTURNE Records Vault',
    summaryFr:
      'Explorez les archives souterraines, consultez les caméras de surveillance, écoutez les bandes audio du programme NOCTURNE et déverrouillez l’accès au Bloc Opératoire.',
    summaryEn:
      'Explore the underground archives, inspect CCTV feeds, listen to NOCTURNE audio tapes, and unlock access to the Surgical Block.',
    introQuoteFr:
      '« Les dossiers de l’incendie d’il y a onze ans n’ont jamais brûlé. Ils ont été descendus ici sous clé. Trouve le code du terminal de sécurité. »',
    introQuoteEn:
      '"The files from the fire eleven years ago never burned. They were locked down here. Find the security terminal code."',
    introSpeaker: 'Enregistrement #02 · Infirmière Maya',
    fogColor: [0.024, 0.032, 0.038],
    fogDensity: 0.048,
    ambientTint: [0.36, 0.52, 0.58],
    totalClues: 4,
    nextChapter: 'ch3',
    monsterBehaviorNoteFr: 'IA auditive affûtée · Inspecte les bruits de tiroirs et les caméras actives.',
    monsterBehaviorNoteEn: 'Sharpened hearing AI · Investigates drawer sounds and active terminals.',
    mimicLinesFr: [
      'Dossier zéro-quatre… Noah Kanza… nous attendons…',
      'J’entends tes pas entre les rayonnages, Noah…',
    ],
    mimicLinesEn: [
      'File zero-four… Noah Kanza… we are waiting…',
      'I hear your footsteps between the shelves, Noah…',
    ],
  },
  ch3: {
    id: 'ch3',
    order: 3,
    labelFr: 'CHAPITRE 3',
    labelEn: 'CHAPTER 3',
    titleFr: 'Le Bloc Opératoire',
    titleEn: 'The Operating Block',
    locationFr: 'Sous-sol -2 · Salles Chirurgicales & Traumatologie',
    locationEn: 'Basement -2 · Surgical Suites & Trauma',
    summaryFr:
      'Découvrez les expériences chirurgicales menées sur la mémoire traumatique, résolvez l’énigme des fréquences neuronales et percez le lien qui unit Noah au Patient 04.',
    summaryEn:
      'Uncover the surgical memory-trauma experiments, solve the neural frequency puzzle, and discover the link between Noah and Patient 04.',
    introQuoteFr:
      '« Sujet 04 et Sujet 04-B… Le Dr Voss a écrit nos deux noms sur le même protocole opératoire. Pourquoi ne m’en souviens-je pas ? »',
    introQuoteEn:
      '"Subject 04 and Subject 04-B… Dr. Voss wrote both our names on the same surgical chart. Why can’t I remember?"',
    introSpeaker: 'Noah Kanza · Monologue',
    fogColor: [0.018, 0.036, 0.036],
    fogDensity: 0.047,
    ambientTint: [0.32, 0.62, 0.56],
    totalClues: 4,
    nextChapter: 'ch4',
    monsterBehaviorNoteFr: 'Tactique d’embuscade · Attend dans les intersections sombres et réagit aux tirs.',
    monsterBehaviorNoteEn: 'Ambush tactics · Waits at dark intersections and reacts to gunfire.',
    mimicLinesFr: [
      'Tu te souviens de la table d’opération, frère ?',
      'Le docteur Voss arrive… ne ferme pas les yeux…',
    ],
    mimicLinesEn: [
      'Do you remember the operating table, brother?',
      'Dr. Voss is coming… don’t close your eyes…',
    ],
  },
  ch4: {
    id: 'ch4',
    order: 4,
    labelFr: 'CHAPITRE 4',
    labelEn: 'CHAPTER 4',
    titleFr: 'Le Laboratoire Souterrain',
    titleEn: 'The Underground Laboratory',
    locationFr: 'Sous-sol -3 · Complexe NOCTURNE',
    locationEn: 'Basement -3 · NOCTURNE Complex',
    summaryFr:
      'Retrouvez Maya dans la cellule d’observation, découvrez l’existence du Dr Voss et prenez une décision morale capitale concernant les patients toujours enfermés.',
    summaryEn:
      'Reach Maya in the observation bay, confront the truth about Dr. Voss, and make a critical moral choice about the trapped patients.',
    introQuoteFr:
      '« Noah ! Je suis derrière la vitre blindée du labo central ! Voss a verrouillé les cuves de confinement. Dépêche-toi, ils vont tous suffoquer ! »',
    introQuoteEn:
      '"Noah! I’m behind the reinforced glass in the central lab! Voss locked the containment pods. Hurry, they’re going to suffocate!"',
    introSpeaker: 'Maya Kanza · Interphone Labo',
    fogColor: [0.014, 0.028, 0.044],
    fogDensity: 0.042,
    ambientTint: [0.34, 0.58, 0.78],
    totalClues: 4,
    nextChapter: 'ch5',
    monsterBehaviorNoteFr: 'Chasse coordonnée · Patrouille autour des cuves et inspecte les casiers suspects.',
    monsterBehaviorNoteEn: 'Coordinated hunt · Patrols around pods and checks suspicious lockers.',
    mimicLinesFr: [
      'Sauve Maya… ou sauve-toi… tu ne peux pas tout sauver…',
      'Ils respirent encore dans les cuves, Noah… écoute-les…',
    ],
    mimicLinesEn: [
      'Save Maya… or save yourself… you cannot save everyone…',
      'They are still breathing inside the pods, Noah… listen to them…',
    ],
  },
  ch5: {
    id: 'ch5',
    order: 5,
    labelFr: 'CHAPITRE 5',
    labelEn: 'CHAPTER 5',
    titleFr: 'La Vérité du Patient 04',
    titleEn: 'The Truth of Patient 04',
    locationFr: 'Sous-sol -4 · Zone de Confinement Zéro',
    locationEn: 'Basement -4 · Containment Zone Zero',
    summaryFr:
      'Pénétrez dans la cellule du Patient 04, découvrez son véritable nom et son passé lié à Noah, et rassemblez les dossiers secrets dissimulés avant l’assaut final.',
    summaryEn:
      'Enter Patient 04’s containment cell, uncover his real name and shared past with Noah, and recover hidden classified files before the final showdown.',
    introQuoteFr:
      '« Il y a onze ans, tu as survécu à l’incendie parce que quelqu’un est resté dans la chambre 04 pour retenir la porte. Tu viens enfin le regarder en face. »',
    introQuoteEn:
      '"Eleven years ago you survived the fire because someone stayed inside Room 04 to hold the door. Now you’re finally facing him."',
    introSpeaker: 'Dr. Henrik Voss · Terminal Zéro',
    fogColor: [0.028, 0.018, 0.024],
    fogDensity: 0.049,
    ambientTint: [0.58, 0.36, 0.42],
    totalClues: 4,
    nextChapter: 'ch6',
    monsterBehaviorNoteFr: 'Mimétisme vocal avancé et pannes d’éclairage localisées à proximité.',
    monsterBehaviorNoteEn: 'Advanced voice mimicry and localized flashlight interference nearby.',
    mimicLinesFr: [
      'Tu m’as laissé brûler, Noah… tu te souviens de ma voix ?',
      'Je suis ton double d’ombre… le sujet parfait…',
    ],
    mimicLinesEn: [
      'You left me to burn, Noah… do you remember my voice?',
      'I am your shadow double… the perfect subject…',
    ],
  },
  ch6: {
    id: 'ch6',
    order: 6,
    labelFr: 'CHAPITRE 6',
    labelEn: 'CHAPTER 6',
    titleFr: 'La Dernière Nuit',
    titleEn: 'The Last Night',
    locationFr: 'Complexe NOCTURNE · Noyau d’Autodestruction',
    locationEn: 'NOCTURNE Complex · Self-Destruct Core',
    summaryFr:
      'Déclenchez l’autodestruction, affrontez le Dr Voss, survivez à la dernière poursuite du Patient 04 et décidez du destin de Maya, des patients et du programme NOCTURNE.',
    summaryEn:
      'Trigger self-destruct, confront Dr. Voss, survive Patient 04’s final pursuit, and decide the fate of Maya, the patients, and the NOCTURNE program.',
    introQuoteFr:
      '« Alarme critique : purge thermique amorcée. Toutes les portes de confinement s’ouvrent dans 180 secondes. Fuis avec Maya… ou termine ce que nous avons commencé. »',
    introQuoteEn:
      '"Critical alarm: thermal purge armed. All containment doors open in 180 seconds. Escape with Maya… or finish what we began."',
    introSpeaker: 'Système NOCTURNE · Alerte Rouge',
    fogColor: [0.045, 0.012, 0.014],
    fogDensity: 0.046,
    ambientTint: [0.78, 0.24, 0.22],
    totalClues: 4,
    nextChapter: null,
    monsterBehaviorNoteFr: 'Poursuite finale sans répit sous alarme d’autodestruction.',
    monsterBehaviorNoteEn: 'Relentless final pursuit under self-destruct alarm.',
    mimicLinesFr: [
      'PERSONNE NE SORT DU PAVILLON KAMBALA !',
      'Noah… reste avec moi dans les flammes…',
    ],
    mimicLinesEn: [
      'NO ONE LEAVES KAMBALA PAVILION!',
      'Noah… stay with me in the flames…',
    ],
  },
  dlc1: {
    id: 'dlc1',
    order: 7,
    labelFr: 'DLC · LES DOSSIERS OUBLIÉS',
    labelEn: 'DLC · THE FORGOTTEN FILES',
    titleFr: 'La Première Nuit (11 ans plus tôt)',
    titleEn: 'The First Night (11 Years Ago)',
    locationFr: 'Bloc Zéro · Nuit de l’Incendie',
    locationEn: 'Block Zero · Night of the Fire',
    summaryFr:
      'Contenu exclusif : incarnez l’inspectrice Claire Vance lors de la nuit de l’incendie, il y a onze ans, pour récupérer les preuves originelles du protocole NOCTURNE.',
    summaryEn:
      'Exclusive story: play as Investigator Claire Vance on the night of the fire eleven years ago to recover the original NOCTURNE evidence.',
    introQuoteFr:
      '« Nuit du 14 novembre. Les sirènes hurlent dans le Bloc Zéro. Le Dr Voss brûle ses archives avant l’arrivée de la police. Il me faut ces bandes magnétiques. »',
    introQuoteEn:
      '"November 14th. Sirens are wailing in Block Zero. Dr. Voss is burning his records before police arrive. I need those tapes."',
    introSpeaker: 'Claire Vance · Archives 2015',
    fogColor: [0.055, 0.024, 0.012],
    fogDensity: 0.052,
    ambientTint: [0.85, 0.44, 0.22],
    totalClues: 4,
    nextChapter: null,
    isDlc: true,
    monsterBehaviorNoteFr: 'Premier éveil du Patient 04 dans la fumée de l’incendie.',
    monsterBehaviorNoteEn: 'Patient 04’s first awakening inside the fire smoke.',
    mimicLinesFr: [
      'Au secours… quelqu’un… le feu bloque la porte…',
      'Docteur Voss… ne me laissez pas…',
    ],
    mimicLinesEn: [
      'Help… someone… the fire is blocking the door…',
      'Dr. Voss… don’t leave me…',
    ],
  },
};

export const MAIN_CHAPTER_ORDER: ChapterId[] = ['ch1', 'ch2', 'ch3', 'ch4', 'ch5', 'ch6'];

export const STORY_DOCUMENTS: StoryDocument[] = [
  {
    id: 'doc_ch1_intake',
    chapterId: 'ch1',
    title: 'Note d’Évacuation — Poste de Soins',
    titleEn: 'Evacuation Memo — Nursing Station',
    category: 'memo',
    date: '14/11 · 23h50',
    author: 'Chef de garde A. Moreau',
    body: 'Le Sujet 04 a brisé les sangles du bloc chirurgical. Nous avons barricadé les issues Sud et Est. Le générateur Ouest-Sud a été coupé pour le maintenir dans le noir, mais il se déplace désormais au son et imite les voix du personnel. Ne lui répondez jamais.',
    bodyEn:
      'Subject 04 tore through the surgical restraints. We barricaded the South and East exits. The West-South generator was shut down to keep him in the dark, yet he now hunts by sound and mimics staff voices. Never answer him.',
  },
  {
    id: 'doc_ch1_maya_log',
    chapterId: 'ch1',
    title: 'Journal de Maya — Quart de Nuit',
    titleEn: 'Maya’s Log — Night Shift',
    category: 'dossier',
    date: 'Il y a 3 jours',
    author: 'Maya Kanza, Infirmière',
    body: 'Ils ont rouvert le Pavillon Kambala en secret sous prétexte d’inventaire. Ce matin j’ai vu le Dr Voss descendre vers les archives souterraines avec des caisses scellées. Si je ne rentre pas ce soir, Noah saura où chercher.',
    bodyEn:
      'They secretly reopened Kambala Pavilion under the cover of an equipment audit. This morning I saw Dr. Voss heading down to the basement archives with sealed crates. If I don’t come home tonight, Noah will know where to look.',
  },
  {
    id: 'doc_ch2_nocturne',
    chapterId: 'ch2',
    title: 'Directive NOCTURNE — Protocole Sommeil Paradoxal',
    titleEn: 'NOCTURNE Directive — REM Trauma Protocol',
    category: 'dossier',
    date: 'Archives 2015',
    author: 'Dr. Henrik Voss',
    body: 'Le programme NOCTURNE vise à isoler l’empreinte mémorielle de la peur pure pendant la privation de sommeil. Le Sujet 04 montre une plasticité acoustique inédite : il mémorise et reproduit avec exactitude la voix des personnes liées à son traumatisme. Code d’accès du dépôt Est : 0217.',
    bodyEn:
      'Project NOCTURNE isolates the memory imprint of pure fear under sleep deprivation. Subject 04 exhibits unprecedented acoustic plasticity: he memorizes and reproduces the exact voices of people tied to his trauma. East vault code: 0217.',
  },
  {
    id: 'doc_ch2_security',
    chapterId: 'ch2',
    title: 'Rapport CCTV — Couloir des Archives',
    titleEn: 'CCTV Report — Archives Corridor',
    category: 'memo',
    date: 'Hier · 01h42',
    author: 'Sécurité Kambala',
    body: 'Caméra 02 a capté une silhouette devant la porte blindée appelant « Noah » avec la voix de l’infirmière Kanza alors que celle-ci était déjà retenue au niveau -3. Vérifiez toujours les moniteurs avant de quitter un rayonnage.',
    bodyEn:
      'Camera 02 captured a figure outside the blast door calling "Noah" in Nurse Kanza’s voice while she was already detained on Level -3. Always check the CCTV monitors before leaving cover.',
  },
  {
    id: 'doc_ch3_surgery',
    chapterId: 'ch3',
    title: 'Protocole Chirurgical 04-A / 04-B',
    titleEn: 'Surgical Protocol 04-A / 04-B',
    category: 'dossier',
    date: '11/11/2015',
    author: 'Dr. Henrik Voss',
    body: 'Transfert synaptique effectué entre le Sujet 04 (Elias Kanza) et le Sujet témoin 04-B (Noah Kanza, 14 ans, admis après l’accident de la route). Noah a reçu l’amnésie induite et a été évacué avant l’incendie ; Elias est resté en salle de confinement pour stabiliser la résonance.',
    bodyEn:
      'Synaptic transfer completed between Subject 04 (Elias Kanza) and control Subject 04-B (Noah Kanza, age 14, admitted after the road crash). Noah received induced amnesia and was evacuated prior to the fire; Elias remained in containment to stabilize resonance.',
  },
  {
    id: 'doc_ch3_freq',
    chapterId: 'ch3',
    title: 'Calibrage Électro-Encéphalogramme',
    titleEn: 'EEG Frequency Calibration',
    category: 'memo',
    date: 'Archives Chirurgie',
    author: 'Labo Neurologie',
    body: 'Pour ouvrir le sas de la salle d’opération Nord, aligner la fréquence du stimulateur sur 408 Hz (ondes Gamma de terreur aiguë). Les munitions de 9mm peuvent provoquer une sidération motrice temporaire de 3 secondes sur le Sujet 04.',
    bodyEn:
      'To unlock the North operating airlock, set the stimulator frequency to 408 Hz (acute terror Gamma band). Standard 9mm rounds induce a 3-second motor stagger on Subject 04.',
  },
  {
    id: 'doc_ch4_voss',
    chapterId: 'ch4',
    title: 'Manifeste du Dr Voss — Pourquoi nous continuons',
    titleEn: 'Dr. Voss Manifesto — Why We Continue',
    category: 'dossier',
    date: 'Aujourd’hui · 00h05',
    author: 'Dr. Henrik Voss',
    body: 'La peur est le seul langage universel du cortex. Les patients des cuves 01 à 03 maintiennent la fréquence qui empêche Patient 04 de détruire tout le sous-sol. Libérez-les, et vous déclencherez l’effondrement total. Laissez-les enfermés, et ils mourront avec le complexe.',
    bodyEn:
      'Fear is the cortex’s only universal language. Patients in Pods 01–03 sustain the resonance keeping Patient 04 from tearing the basement apart. Free them, and you trigger total collapse. Leave them sealed, and they die with the facility.',
  },
  {
    id: 'doc_ch5_secret_1',
    chapterId: 'ch5',
    title: '[CLASSIFIÉ] Origine du Sujet 04 — Elias Kanza',
    titleEn: '[CLASSIFIED] Subject 04 Origin — Elias Kanza',
    category: 'secret',
    date: '14/11/2015',
    author: 'Comité d’Éthique Fantôme',
    body: 'DOCUMENT SECRET 1/3 : Elias Kanza s’est volontairement enfermé dans la chambre 04 pendant l’incendie pour permettre aux secours d’évacuer son frère Noah et sa petite sœur Maya. Voss a maquillé son décès et poursuivi les injections expérimentales pendant onze ans.',
    bodyEn:
      'SECRET FILE 1/3: Elias Kanza locked himself inside Room 04 during the fire so paramedics could evacuate his brother Noah and little sister Maya. Voss faked his death certificate and continued experimental injections for eleven years.',
    isSecretForEndingC: true,
  },
  {
    id: 'doc_ch5_secret_2',
    chapterId: 'ch5',
    title: '[CLASSIFIÉ] Clef Maîtresse du Programme NOCTURNE',
    titleEn: '[CLASSIFIED] NOCTURNE Master Override Key',
    category: 'secret',
    date: 'Révision 2026',
    author: 'Direction Kambala',
    body: 'DOCUMENT SECRET 2/3 : Le terminal du noyau central reconnaît la signature génétique Kanza (04-B). Quiconque possède les trois dossiers secrets peut réassigner l’autorité administrative du complexe au lieu de déclencher la purge finale. Code chambre 04 : 0411.',
    bodyEn:
      'SECRET FILE 2/3: The central core terminal recognizes the Kanza genetic signature (04-B). Anyone holding all three secret files can reassign administrative authority instead of running the thermal purge. Room 04 code: 0411.',
    isSecretForEndingC: true,
  },
  {
    id: 'doc_ch5_secret_3',
    chapterId: 'ch5',
    title: '[CLASSIFIÉ] Protocole Patient 05',
    titleEn: '[CLASSIFIED] Patient 05 Protocol',
    category: 'secret',
    date: 'Confidentiel',
    author: 'Dr. Henrik Voss',
    body: 'DOCUMENT SECRET 3/3 : Noah Kanza porte toujours l’implant résonant posé onze ans plus tôt. S’il survit à la nuit et accède à la console centrale avec les données de l’aile Zéro, il est biologiquement désigné comme successeur — ou futur Sujet 05.',
    bodyEn:
      'SECRET FILE 3/3: Noah Kanza still carries the resonant implant placed eleven years ago. Should he survive the night and access the main console with Zero-Wing data, he is biologically designated as successor—or future Subject 05.',
    isSecretForEndingC: true,
  },
  {
    id: 'doc_premium_1',
    chapterId: 'ch1',
    title: '[PREMIUM] Rapport d’Autopsie Falsifié',
    titleEn: '[PREMIUM] Falsified Autopsy Report',
    category: 'premium',
    date: 'Archives Bonus',
    author: 'Service Médico-Légal Kambala',
    body: 'Contenu exclusif Premium Pass : L’acte de décès d’Elias Kanza porte la signature contrefaite du directeur adjoint. Les cendres retrouvées dans l’aile de quarantaine provenaient d’animaux de laboratoire.',
    bodyEn:
      'Premium Pass Exclusive: Elias Kanza’s death certificate bears a forged deputy director signature. The ashes recovered from the quarantine wing came from lab specimens.',
    isPremiumBonus: true,
  },
  {
    id: 'doc_premium_2',
    chapterId: 'ch4',
    title: '[PREMIUM] Note du Concepteur — L’Écho de Maya',
    titleEn: '[PREMIUM] Director’s Lore — Maya’s Echo',
    category: 'premium',
    date: 'Dossier Bonus',
    author: 'Archives NOCTURNE',
    body: 'Contenu exclusif Premium Pass : Patient 04 n’imite jamais un inconnu. Il ne reproduit que les voix enregistrées dans la mémoire de Noah — c’est pourquoi l’appel téléphonique à 02h17 déclenche sa résonance jusque dans la rue.',
    bodyEn:
      'Premium Pass Exclusive: Patient 04 never mimics a stranger. He only reproduces voices stored inside Noah’s own memory—which is why the 02:17 AM phone call triggers his resonance out to the street.',
    isPremiumBonus: true,
  },
  {
    id: 'doc_dlc_1',
    chapterId: 'dlc1',
    title: 'Dossier Oublié #01 — La Première Nuit',
    titleEn: 'Forgotten File #01 — The First Night',
    category: 'dossier',
    date: '14/11/2015 · 01h10',
    author: 'Inspectrice Claire Vance',
    body: 'L’incendie n’était pas un accident électrique. Voss a déclenché la vanne de gaz du Bloc Zéro dès qu’il a su que la commission d’inspection arrivait à l’aube.',
    bodyEn:
      'The fire was no electrical fault. Voss opened the Block Zero gas valve the moment he learned the inspection board was arriving at dawn.',
  },
];

export const AUDIO_TAPES: AudioTape[] = [
  {
    id: 'tape_ch1_call',
    chapterId: 'ch1',
    title: 'Appel de Maya (02h17)',
    titleEn: 'Maya’s Phone Call (02:17 AM)',
    speaker: 'Maya Kanza',
    durationSec: 18,
    transcript:
      '« Noah… si tu entends ma voix, ne viens pas seul. Ils ont rallumé les lumières. Le Patient 04 est encore là. Et surtout… ne lui réponds pas quand il prononce ton nom. »',
    transcriptEn:
      '"Noah… if you hear my voice, don’t come alone. They turned the lights back on. Patient 04 is still here. And above all… don’t answer when he speaks your name."',
  },
  {
    id: 'tape_ch2_voss',
    chapterId: 'ch2',
    title: 'Bande #04 — Essai Vocal',
    titleEn: 'Tape #04 — Vocal Mimicry Test',
    speaker: 'Dr. Voss & Sujet 04',
    durationSec: 22,
    transcript:
      'Dr Voss : « Sujet 04, répétez la séquence de référence. » — Voix déformée : « Noah… la grille est ouverte… viens me chercher… » — Dr Voss : « Remarquable. La résonance fraternelle est intacte. »',
    transcriptEn:
      'Dr. Voss: "Subject 04, repeat the reference sequence." — Distorted voice: "Noah… the gate is open… come find me…" — Dr. Voss: "Remarkable. Fraternal resonance is intact."',
  },
  {
    id: 'tape_ch4_maya',
    chapterId: 'ch4',
    title: 'Bande #09 — Enregistrement de Maya',
    titleEn: 'Tape #09 — Maya’s Hidden Tape',
    speaker: 'Maya Kanza',
    durationSec: 20,
    transcript:
      '« Si quelqu’un trouve cette cassette dans le labo : Elias est vivant. Ce qu’ils appellent le Patient 04, c’est mon frère… le frère que Noah a oublié après l’accident. »',
    transcriptEn:
      '"If anyone finds this tape in the lab: Elias is alive. What they call Patient 04 is my brother… the brother Noah forgot after the crash."',
  },
  {
    id: 'tape_dlc_fire',
    chapterId: 'dlc1',
    title: 'Bande Oubliée — Boîte Noire 2015',
    titleEn: 'Forgotten Tape — 2015 Black Box',
    speaker: 'Claire Vance & Elias',
    durationSec: 20,
    transcript:
      'Claire : « Tenez bon ! Je cherche la clé du sas ! » — Elias derrière la vitre : « Sortez Noah et Maya d’abord ! Ne dites jamais à Noah ce qu’on nous a fait ici ! »',
    transcriptEn:
      'Claire: "Hold on! I’m finding the airlock key!" — Elias behind the glass: "Get Noah and Maya out first! Never tell Noah what they did to us here!"',
  },
];

export const CCTV_FEEDS: CctvFeed[] = [
  {
    id: 'cctv_arch_north',
    camCode: 'CAM-01 · ARCHIVES NORD',
    location: 'Couloir des Rayonnages',
    locationEn: 'Shelving Corridor',
    chapterId: 'ch2',
    monsterVisible: true,
    statusText: 'MOUVEMENT DÉTECTÉ · PATIENT 04',
    statusTextEn: 'MOTION DETECTED · PATIENT 04',
    hint: 'Code du sas Est inscrit sur le pilier : 0217',
    hintEn: 'East blast door code painted on pillar: 0217',
  },
  {
    id: 'cctv_arch_vault',
    camCode: 'CAM-02 · SALLE DES BANDES',
    location: 'Poste de Surveillance',
    locationEn: 'Security Desk',
    chapterId: 'ch2',
    monsterVisible: false,
    statusText: 'SIGNAL CLAIR · CASIERS DISPONIBLES',
    statusTextEn: 'CLEAR SIGNAL · LOCKERS AVAILABLE',
    hint: 'Pistolet de service dans l’armoire Sud-Est.',
    hintEn: 'Service pistol stored in South-East security locker.',
  },
  {
    id: 'cctv_lab_pods',
    camCode: 'CAM-03 · CUVES DE CONFINEMENT',
    location: 'Laboratoire Central',
    locationEn: 'Central Laboratory',
    chapterId: 'ch4',
    monsterVisible: true,
    statusText: '3 PATIENTS EN STASE · OXYGÈNE 18%',
    statusTextEn: '3 PATIENTS IN STASIS · OXYGEN 18%',
    hint: 'Maya attend devant la console de contrôle Ouest.',
    hintEn: 'Maya is waiting by the West control console.',
  },
];

export const PUZZLES: Record<string, PuzzleDefinition> = {
  puzzle_ch1_gen: {
    id: 'puzzle_ch1_gen',
    chapterId: 'ch1',
    kind: 'circuit',
    title: 'Séquence d’Amorçage du Générateur',
    titleEn: 'Generator Ignition Sequence',
    prompt: 'Activez les disjoncteurs dans l’ordre de montée en charge : 1 → 3 → 2 → 4.',
    promptEn: 'Flip the breakers in load order: 1 → 3 → 2 → 4.',
    solutionCode: '1324',
    clueHint: 'Plaque rivetée sur le groupe électrogène : 1-3-2-4.',
    clueHintEn: 'Riveted plate on generator housing: 1-3-2-4.',
  },
  puzzle_ch2_keypad: {
    id: 'puzzle_ch2_keypad',
    chapterId: 'ch2',
    kind: 'keypad',
    title: 'Digicode du Dépôt des Archives',
    titleEn: 'Archives Vault Keypad',
    prompt: 'Saisissez le code à 4 chiffres du programme NOCTURNE (l’heure de l’appel de Maya).',
    promptEn: 'Enter the 4-digit NOCTURNE vault code (the timestamp of Maya’s call).',
    solutionCode: '0217',
    clueHint: 'Consultez la note du Dr Voss ou l’heure d’appel : 02h17.',
    clueHintEn: 'Check Dr. Voss’s note or Maya’s call timestamp: 0217.',
  },
  puzzle_ch3_freq: {
    id: 'puzzle_ch3_freq',
    chapterId: 'ch3',
    kind: 'frequency',
    title: 'Résonateur du Bloc Opératoire',
    titleEn: 'Surgical Block Resonator',
    prompt: 'Calibrez le stimulateur neuronal sur la fréquence de terreur aiguë (408 Hz).',
    promptEn: 'Tune the neural stimulator to the acute terror frequency (408 Hz).',
    solutionCode: '408',
    clueHint: 'Document EEG en salle de traumatologie : 408 Hz.',
    clueHintEn: 'EEG report in trauma room: 408 Hz.',
  },
  puzzle_ch4_lab: {
    id: 'puzzle_ch4_lab',
    chapterId: 'ch4',
    kind: 'circuit',
    title: 'Déverrouillage des Cuves Biologiques',
    titleEn: 'Bio-Pod Override Sequence',
    prompt: 'Stabilisez la pression des 4 valves avant d’ouvrir le confinement : 2 → 4 → 1 → 3.',
    promptEn: 'Stabilize the 4 pressure valves in sequence: 2 → 4 → 1 → 3.',
    solutionCode: '2413',
    clueHint: 'Schéma gravé sur la vitre de Maya : 2-4-1-3.',
    clueHintEn: 'Schematic etched on Maya’s glass: 2-4-1-3.',
  },
  puzzle_ch5_cell04: {
    id: 'puzzle_ch5_cell04',
    chapterId: 'ch5',
    title: 'Sas de la Chambre 04',
    titleEn: 'Room 04 Containment Lock',
    kind: 'keypad',
    prompt: 'Code d’isolement du Sujet 04 (numéro du sujet + mois de l’incendie).',
    promptEn: 'Subject 04 isolation code (subject number + fire month).',
    solutionCode: '0411',
    clueHint: 'Dossier secret 2/3 : 0411.',
    clueHintEn: 'Secret File 2/3: 0411.',
  },
  puzzle_ch6_core: {
    id: 'puzzle_ch6_core',
    chapterId: 'ch6',
    kind: 'keypad',
    title: 'Console du Noyau d’Autodestruction',
    titleEn: 'Self-Destruct Core Console',
    prompt: 'Confirmez la séquence d’urgence du Pavillon Kambala : 0404.',
    promptEn: 'Confirm Kambala Pavilion emergency purge code: 0404.',
    solutionCode: '0404',
    clueHint: 'Code de purge affiché sur l’écran rouge du noyau : 0404.',
    clueHintEn: 'Purge code displayed on core red monitor: 0404.',
  },
  puzzle_dlc_fire: {
    id: 'puzzle_dlc_fire',
    chapterId: 'dlc1',
    kind: 'circuit',
    title: 'Vanne Anti-Incendie du Bloc Zéro',
    titleEn: 'Block Zero Fire Suppression Valve',
    prompt: 'Activez les 4 vannes pour ouvrir la trappe d’évacuation : 4 → 2 → 3 → 1.',
    promptEn: 'Engage the 4 valves to open the escape hatch: 4 → 2 → 3 → 1.',
    solutionCode: '4231',
    clueHint: 'Manuel d’urgence mural : 4-2-3-1.',
    clueHintEn: 'Wall emergency manual: 4-2-3-1.',
  },
};

export interface EndingScript {
  id: EndingId;
  code: string;
  titleFr: string;
  titleEn: string;
  subtitleFr: string;
  subtitleEn: string;
  scenesFr: { speaker: string; line: string }[];
  scenesEn: { speaker: string; line: string }[];
  finalBannerFr?: string;
  finalBannerEn?: string;
}

export const ENDINGS: Record<EndingId, EndingScript> = {
  ending_a: {
    id: 'ending_a',
    code: 'FIN A',
    titleFr: 'LE SURVIVANT',
    titleEn: 'THE SURVIVOR',
    subtitleFr: 'Noah sauve Maya et quitte l’hôpital en flammes.',
    subtitleEn: 'Noah rescues Maya and escapes the burning hospital.',
    scenesFr: [
      {
        speaker: 'Narrateur',
        line: 'Les sirènes s’étouffent derrière les grilles du Pavillon Kambala tandis qu’une déflagration soulève le toit de l’aile de quarantaine.',
      },
      {
        speaker: 'Maya Kanza',
        line: '« Noah… on a réussi. On est dehors. Ne regarde pas en arrière… »',
      },
      {
        speaker: 'Narrateur',
        line: 'Sur la route mouillée de pluie, le téléphone de Noah vibre sur le tableau de bord. L’écran affiche : APPEL ENTRANT — INCONNU.',
      },
      {
        speaker: 'Voix au téléphone',
        line: '« Noah… je suis déjà dehors. »',
      },
    ],
    scenesEn: [
      {
        speaker: 'Narrator',
        line: 'Sirens fade behind the gates of Kambala Pavilion as an explosion lifts the roof of the quarantine wing.',
      },
      {
        speaker: 'Maya Kanza',
        line: '"Noah… we made it. We’re out. Don’t look back…"',
      },
      {
        speaker: 'Narrator',
        line: 'On the rain-slicked road, Noah’s phone vibrates on the dashboard. The screen reads: INCOMING CALL — UNKNOWN.',
      },
      {
        speaker: 'Voice on the Phone',
        line: '"Noah… I’m already outside."',
      },
    ],
  },
  ending_b: {
    id: 'ending_b',
    code: 'FIN B',
    titleFr: 'LE SACRIFICE',
    titleEn: 'THE SACRIFICE',
    subtitleFr: 'Noah libère les patients, sauve Maya et attire Patient 04 dans la chambre de confinement.',
    subtitleEn: 'Noah frees the patients, lets Maya escape, and lures Patient 04 into containment.',
    scenesFr: [
      {
        speaker: 'Noah Kanza',
        line: '« Emmène les autres patients jusqu’à la sortie, Maya ! Si je ne le retiens pas ici, il vous retrouvera toutes les nuits ! »',
      },
      {
        speaker: 'Maya Kanza',
        line: '« Non, Noah ! La porte blindée va se verrouiller de l’extérieur ! »',
      },
      {
        speaker: 'Narrateur',
        line: 'Noah frappe la vitre de la chambre 04 avec sa lampe. Elias — le Patient 04 — s’avance lentement dans la lueur rouge, reconnaissant enfin son frère.',
      },
      {
        speaker: 'Noah Kanza',
        line: '« Je suis là, Elias. On ne fuira plus jamais. »',
      },
    ],
    scenesEn: [
      {
        speaker: 'Noah Kanza',
        line: '"Get the other patients out, Maya! If I don’t hold him here, he’ll hunt you every night!"',
      },
      {
        speaker: 'Maya Kanza',
        line: '"No, Noah! The blast door will seal from the outside!"',
      },
      {
        speaker: 'Narrator',
        line: 'Noah strikes the glass of Chamber 04 with his flashlight. Elias—Patient 04—steps into the red glow, finally recognizing his brother.',
      },
      {
        speaker: 'Noah Kanza',
        line: '"I’m right here, Elias. We’re never running again."',
      },
    ],
  },
  ending_c: {
    id: 'ending_c',
    code: 'FIN C · SECRÈTE',
    titleFr: 'NOCTURNE',
    titleEn: 'NOCTURNE',
    subtitleFr: 'Avec tous les dossiers secrets en main, Noah reprend le contrôle du laboratoire.',
    subtitleEn: 'With all secret files recovered, Noah assumes control of the laboratory.',
    scenesFr: [
      {
        speaker: 'Console Centrale NOCTURNE',
        line: '« Dossiers 04-A, 04-B et Zéro validés. Purge thermique annulée. Nouvelle autorité administrative assignée à : KANZA, NOAH. »',
      },
      {
        speaker: 'Dr. Henrik Voss',
        line: '« Tu as fini par comprendre… La peur ne se détruit pas. Elle se dirige. »',
      },
      {
        speaker: 'Narrateur',
        line: 'Les écrans bleus du laboratoire s’illuminent un à un. Patient 04 s’agenouille devant la vitre, silencieux. Une nouvelle fiche clignote au centre de l’écran.',
      },
    ],
    scenesEn: [
      {
        speaker: 'NOCTURNE Core Console',
        line: '"Files 04-A, 04-B, and Zero validated. Thermal purge aborted. New administrative authority assigned to: KANZA, NOAH."',
      },
      {
        speaker: 'Dr. Henrik Voss',
        line: '"You finally understand… Fear cannot be destroyed. It must be directed."',
      },
      {
        speaker: 'Narrator',
        line: 'Blue monitors flicker to life across the underground bay. Patient 04 kneels silently beyond the glass. A new intake dossier flashes across the screen.',
      },
    ],
    finalBannerFr: 'PATIENT 05 — ADMISSION CONFIRMÉE',
    finalBannerEn: 'PATIENT 05 — ADMISSION CONFIRMED',
  },
};

export const SHOP_CATALOG: ShopProduct[] = [
  {
    id: 'premium_pass',
    sku: 'NOCTURNE04_PREMIUM_PASS',
    name: 'NOCTURNE 04 PREMIUM PASS',
    nameEn: 'NOCTURNE 04 PREMIUM PASS',
    priceUsd: 4.99,
    priceDisplay: '4,99 $',
    tagline: 'Tenue tactique de Noah, lampe torche spéciale, Mode Photo, filtres visuels et dossiers bonus.',
    taglineEn: 'Exclusive Noah tactical outfit, custom flashlight skin, Photo Mode, visual filters, and bonus files.',
    imageUrl: '/src/assets/images/premium_pass_showcase_1794998102538.jpg',
    features: [
      'Tenue exclusive d’ambulancier tactique de Noah (vue 3e personne)',
      'Lampe torche spéciale UV / Ambre avec faisceau amélioré',
      'Mode Photo complet avec caméra libre et capture PNG',
      'Filtres exclusifs Caméra VHS & Vision Nocturne',
      'Documents classifiés bonus et notes narratives inédites',
    ],
    featuresEn: [
      'Exclusive Noah tactical paramedic outfit (3rd person view)',
      'Custom UV / Amber tactical flashlight skin & beam',
      'Full Photo Mode with free-roam camera & PNG capture',
      'Exclusive VHS Bodycam & Night-Vision visual filters',
      'Bonus classified documents & director lore notes',
    ],
  },
  {
    id: 'dlc_dossiers',
    sku: 'NOCTURNE04_DLC_DOSSIERS',
    name: 'DLC — LES DOSSIERS OUBLIÉS',
    nameEn: 'DLC — THE FORGOTTEN FILES',
    priceUsd: 2.99,
    priceDisplay: '2,99 $',
    tagline: 'Nouvelle histoire indépendante (30–45 min) dans le Bloc Zéro lors de l’incendie d’il y a 11 ans.',
    taglineEn: 'Standalone prequel story (30–45 min) inside Block Zero during the fire 11 years ago.',
    imageUrl: '/src/assets/images/dlc_dossiers_art_1794998103686.jpg',
    features: [
      'Chapitre inédit jouable : La Première Nuit du Programme NOCTURNE',
      'Nouvelle zone secrète en flammes : Bloc Zéro',
      'Documents inédits et bande boîte noire de 2015',
      'Révélations sur l’origine de l’incendie et d’Elias Kanza',
    ],
    featuresEn: [
      'New playable chapter: First Night of Project NOCTURNE',
      'New burning secret zone: Block Zero',
      'Unreleased documents & 2015 black-box audio tape',
      'Deep revelations on the fire and Elias Kanza’s origin',
    ],
  },
];

export const MAIN_KEYART_URL = '/src/assets/images/nocturne_hospital_keyart_1794998100326.jpg';
