/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { CctvModal } from './components/CctvModal';
import { CinematicOverlay } from './components/CinematicOverlay';
import { CodexModal } from './components/CodexModal';
import { GameHud } from './components/GameHud';
import { HospitalViewport, type HospitalEngineHandle } from './components/HospitalViewport';
import { InventoryModal } from './components/InventoryModal';
import { MainMenu } from './components/MainMenu';
import { PhotoModeOverlay } from './components/PhotoModeOverlay';
import { PuzzleModal } from './components/PuzzleModal';
import { SaveManager } from './save/saveManager';
import { ShopClient } from './shop/shopClient';
import { ShopModal } from './shop/ShopModal';
import type { EntitlementState, GameSettings, HudSnapshot } from './types/game';

const INITIAL_SETTINGS: GameSettings = SaveManager.loadSettings();
const INITIAL_ENTITLEMENTS: EntitlementState = ShopClient.loadLocalEntitlements();

const INITIAL_HUD: HudSnapshot = {
  phase: 'title',
  chapterId: 'ch1',
  chapterLabel: 'CHAPITRE 1',
  chapterTitle: 'L’Aile de Quarantaine',
  objectiveText: 'Fouillez le Poste de Soins (Est) pour la clé et le pistolet 9mm.',
  difficulty: 'normal',
  perspective: 'first_person',
  health: 100,
  maxHealth: 100,
  battery: 1,
  flashlightOn: true,
  flashlightFlickering: false,
  flashlightOutage: false,
  hasPistol: false,
  pistolMag: 8,
  pistolMagSize: 8,
  pistolReserve: 8,
  isReloading: false,
  medkits: 1,
  batteriesCount: 1,
  bottlesCount: 1,
  maxBottles: 3,
  flaresCount: 1,
  cluesCollected: 0,
  totalClues: 4,
  collectedIds: [],
  keys: [],
  discoveredDocIds: [],
  discoveredTapeIds: [],
  solvedPuzzleIds: [],
  moralDecision: null,
  generatorRestored: false,
  powerRestored: false,
  selfDestructActive: false,
  selfDestructTimer: 180,
  activePuzzle: null,
  activeCctvChapter: null,
  activeEnding: null,
  promptText: null,
  activeNote: null,
  subtitleText: null,
  subtitleSpeaker: null,
  sprinting: false,
  crouching: false,
  isHidden: false,
  isHiding: false,
  hideoutKind: null,
  hidingSpotLabel: null,
  dangerLevel: 0,
  monsterState: 'patrol',
  monsterChasing: false,
  gaussianScanEnabled: true,
  stamina: 1,
  muted: false,
  elapsedSeconds: 0,
  profileMode: INITIAL_SETTINGS.profileMode,
  activeTier: 'high',
  fps: 60,
  frameMs: 16.6,
  isTouchDevice: false,
  isSoftwareGl: false,
  entitlements: INITIAL_ENTITLEMENTS,
  visualFilter: INITIAL_SETTINGS.visualFilter,
};

export default function App() {
  const engineRef = useRef<HospitalEngineHandle | null>(null);
  const [settings, setSettings] = useState<GameSettings>(INITIAL_SETTINGS);
  const [entitlements, setEntitlements] = useState<EntitlementState>(INITIAL_ENTITLEMENTS);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [codexOpenFromMenu, setCodexOpenFromMenu] = useState(false);
  const [shopNotice, setShopNotice] = useState<string | null>(null);
  const [showStudioIntro, setShowStudioIntro] = useState(true);

  useEffect(() => {
    const introTimer = window.setTimeout(() => setShowStudioIntro(false), 3000);
    return () => window.clearTimeout(introTimer);
  }, []);

  const handleHudChange = useCallback((snapshot: HudSnapshot) => {
    setHud(snapshot);
  }, []);

  const handleUpdateSettings = useCallback((next: GameSettings) => {
    setSettings(next);
    SaveManager.saveSettings(next);
    engineRef.current?.applySettings(next);
  }, []);

  const handleEntitlementsUpdated = useCallback((next: EntitlementState) => {
    setEntitlements(next);
    ShopClient.saveLocalEntitlements(next);
    engineRef.current?.setEntitlements(next);
  }, []);

  // On startup: validate stored entitlement token & verify Stripe checkout redirect if present
  useEffect(() => {
    void ShopClient.validateStoredToken().then((validated) => {
      setEntitlements(validated);
      engineRef.current?.setEntitlements(validated);
    });

    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get('checkout_session_id');
    const canceled = params.get('checkout_canceled');

    if (sessionId) {
      void ShopClient.verifyCheckoutSession(sessionId).then((res) => {
        if (res.ok && res.entitlements) {
          handleEntitlementsUpdated(res.entitlements);
          setShopNotice(
            settings.language === 'fr'
              ? 'Paiement Stripe confirmé ! Vos contenus sont débloqués.'
              : 'Stripe payment confirmed! Your content is now unlocked.',
          );
        } else {
          setShopNotice(res.error || 'Vérification Stripe échouée.');
        }
        engineRef.current?.setPhase('shop');
        window.history.replaceState({}, document.title, window.location.pathname);
      });
    } else if (canceled) {
      setShopNotice(
        settings.language === 'fr'
          ? 'Paiement annulé. Aucun débit effectué.'
          : 'Checkout canceled. No charge was made.',
      );
      engineRef.current?.setPhase('shop');
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#030509] text-[#e7eef5]">
      {showStudioIntro && (
        <div className="studio-intro fixed inset-0 z-[100] flex items-center justify-center bg-[#030509]" role="status" aria-label="DblackStudio3D">
          <img src="/dblackstudio3-splash.webp" alt="DblackStudio3D — Immersive Game Experience" className="studio-intro-image h-full w-full object-cover" />
          <div className="studio-intro-vignette absolute inset-0" />
        </div>
      )}
      <HospitalViewport
        ref={engineRef}
        initialSettings={settings}
        initialEntitlements={entitlements}
        onHudChange={handleHudChange}
      />

      {hud.phase === 'title' && (
        <MainMenu
          hud={hud}
          settings={settings}
          entitlements={entitlements}
          engineRef={engineRef}
          onUpdateSettings={handleUpdateSettings}
          onOpenCodex={() => setCodexOpenFromMenu(true)}
          onOpenShop={() => engineRef.current?.setPhase('shop')}
          onOpenCredits={() => engineRef.current?.setPhase('credits')}
        />
      )}

      <GameHud
        hud={hud}
        language={settings.language}
        engineRef={engineRef}
        onOpenCodex={() => {
          if (hud.phase === 'paused' || hud.phase === 'playing') {
            engineRef.current?.setPhase('codex');
          } else {
            setCodexOpenFromMenu(true);
          }
        }}
      />

      <CinematicOverlay hud={hud} language={settings.language} engineRef={engineRef} />

      {hud.phase === 'inventory' && (
        <InventoryModal hud={hud} language={settings.language} engineRef={engineRef} />
      )}

      {(hud.phase === 'codex' || codexOpenFromMenu) && (
        <CodexModal
          language={settings.language}
          discoveredDocIds={hud.discoveredDocIds}
          discoveredTapeIds={hud.discoveredTapeIds}
          entitlements={entitlements}
          onPlayTape={(tapeId) => engineRef.current?.playAudioTape(tapeId)}
          onClose={() => {
            if (codexOpenFromMenu) {
              setCodexOpenFromMenu(false);
            } else {
              engineRef.current?.resumeGame();
            }
          }}
        />
      )}

      {hud.phase === 'puzzle' && hud.activePuzzle && (
        <PuzzleModal
          puzzle={hud.activePuzzle}
          language={settings.language}
          onSolve={(code) => engineRef.current?.solveActivePuzzle(code) ?? false}
          onCancel={() => engineRef.current?.cancelPuzzleOrCctv()}
        />
      )}

      {hud.phase === 'cctv' && hud.activeCctvChapter && (
        <CctvModal
          chapterId={hud.activeCctvChapter}
          language={settings.language}
          onClose={() => engineRef.current?.cancelPuzzleOrCctv()}
        />
      )}

      {hud.phase === 'photo_mode' && entitlements.premiumPass && (
        <PhotoModeOverlay
          language={settings.language}
          visualFilter={hud.visualFilter}
          engineRef={engineRef}
        />
      )}

      {hud.phase === 'shop' && (
        <ShopModal
          language={settings.language}
          entitlements={entitlements}
          verificationNotice={shopNotice}
          onEntitlementsUpdated={handleEntitlementsUpdated}
          onClose={() => {
            setShopNotice(null);
            engineRef.current?.setPhase('title');
          }}
        />
      )}
    </main>
  );
}
