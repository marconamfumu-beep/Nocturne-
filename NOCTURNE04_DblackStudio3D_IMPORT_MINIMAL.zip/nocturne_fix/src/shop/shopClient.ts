import type { EntitlementState, ShopProduct, TransactionRecord } from '../types/game';
import { SHOP_CATALOG } from '../story/chaptersData';

const ENTITLEMENT_KEY = 'nocturne04_entitlements_v1';

export const DEFAULT_ENTITLEMENTS: EntitlementState = {
  premiumPass: false,
  dlcForgottenFiles: false,
  token: null,
  customerEmail: null,
  verifiedAt: null,
};

export interface ShopCatalogResponse {
  products: ShopProduct[];
  stripeConfigured: boolean;
  currency: string;
}

export interface CheckoutSessionResult {
  ok: boolean;
  checkoutUrl?: string;
  sessionId?: string;
  error?: string;
  code?: string;
}

export interface VerifyEntitlementResult {
  ok: boolean;
  entitlements?: EntitlementState;
  transactions?: TransactionRecord[];
  error?: string;
}

export const ShopClient = {
  loadLocalEntitlements(): EntitlementState {
    try {
      const raw = localStorage.getItem(ENTITLEMENT_KEY);
      if (!raw) return { ...DEFAULT_ENTITLEMENTS };
      return { ...DEFAULT_ENTITLEMENTS, ...JSON.parse(raw) };
    } catch {
      return { ...DEFAULT_ENTITLEMENTS };
    }
  },

  saveLocalEntitlements(state: EntitlementState): void {
    try {
      localStorage.setItem(ENTITLEMENT_KEY, JSON.stringify(state));
    } catch {
      // Ignore
    }
  },

  async fetchCatalog(): Promise<ShopCatalogResponse> {
    try {
      const res = await fetch('/api/shop/catalog');
      if (!res.ok) throw new Error('Catalog unreachable');
      return (await res.json()) as ShopCatalogResponse;
    } catch {
      return {
        products: SHOP_CATALOG,
        stripeConfigured: false,
        currency: 'USD',
      };
    }
  },

  async validateStoredToken(): Promise<EntitlementState> {
    const local = this.loadLocalEntitlements();
    if (!local.token) return local;
    try {
      const res = await fetch('/api/shop/validate-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: local.token }),
      });
      if (!res.ok) {
        this.saveLocalEntitlements(DEFAULT_ENTITLEMENTS);
        return { ...DEFAULT_ENTITLEMENTS };
      }
      const data = (await res.json()) as VerifyEntitlementResult;
      if (data.ok && data.entitlements) {
        this.saveLocalEntitlements(data.entitlements);
        return data.entitlements;
      }
      return local;
    } catch {
      return local;
    }
  },

  async createCheckoutSession(
    productId: 'premium_pass' | 'dlc_dossiers',
    customerEmail: string,
  ): Promise<CheckoutSessionResult> {
    try {
      const res = await fetch('/api/shop/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, customerEmail }),
      });
      const data = (await res.json()) as CheckoutSessionResult;
      if (!res.ok) {
        return {
          ok: false,
          error: data.error || 'Paiement indisponible.',
          code: data.code,
        };
      }
      return data;
    } catch {
      return {
        ok: false,
        error: 'Serveur de paiement injoignable.',
        code: 'NETWORK_ERROR',
      };
    }
  },

  async verifyCheckoutSession(sessionId: string): Promise<VerifyEntitlementResult> {
    try {
      const res = await fetch('/api/shop/verify-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          existingToken: this.loadLocalEntitlements().token,
        }),
      });
      const data = (await res.json()) as VerifyEntitlementResult;
      if (data.ok && data.entitlements) {
        this.saveLocalEntitlements(data.entitlements);
      }
      return data;
    } catch {
      return { ok: false, error: 'Impossible de vérifier la session de paiement.' };
    }
  },

  async restorePurchases(customerEmail: string, token?: string): Promise<VerifyEntitlementResult> {
    try {
      const res = await fetch('/api/shop/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerEmail, token }),
      });
      const data = (await res.json()) as VerifyEntitlementResult;
      if (data.ok && data.entitlements) {
        this.saveLocalEntitlements(data.entitlements);
      }
      return data;
    } catch {
      return { ok: false, error: 'Erreur réseau lors de la restauration.' };
    }
  },

  async fetchTransactions(email?: string | null): Promise<TransactionRecord[]> {
    const local = this.loadLocalEntitlements();
    const targetEmail = email ?? local.customerEmail;
    if (!local.token && !targetEmail) return [];
    try {
      const params = new URLSearchParams();
      if (local.token) params.set('token', local.token);
      if (targetEmail) params.set('email', targetEmail);
      const res = await fetch(`/api/shop/transactions?${params.toString()}`);
      if (!res.ok) return [];
      const data = (await res.json()) as { transactions: TransactionRecord[] };
      return data.transactions ?? [];
    } catch {
      return [];
    }
  },
};
