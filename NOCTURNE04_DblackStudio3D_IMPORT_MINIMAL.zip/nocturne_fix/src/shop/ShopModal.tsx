import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  CreditCard,
  History,
  KeyRound,
  RefreshCw,
  ShoppingBag,
  Sparkles,
  X,
} from 'lucide-react';
import { ShopClient } from '../shop/shopClient';
import { SHOP_CATALOG } from '../story/chaptersData';
import type { EntitlementState, Language, ShopProduct, TransactionRecord } from '../types/game';

interface ShopModalProps {
  language: Language;
  entitlements: EntitlementState;
  verificationNotice?: string | null;
  onEntitlementsUpdated: (next: EntitlementState) => void;
  onClose: () => void;
}

export function ShopModal({
  language,
  entitlements,
  verificationNotice,
  onEntitlementsUpdated,
  onClose,
}: ShopModalProps) {
  const [products, setProducts] = useState<ShopProduct[]>(SHOP_CATALOG);
  const [stripeConfigured, setStripeConfigured] = useState(false);
  const [email, setEmail] = useState(entitlements.customerEmail ?? '');
  const [restoreToken, setRestoreToken] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(verificationNotice ?? null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);

  const fr = language === 'fr';

  useEffect(() => {
    void ShopClient.fetchCatalog().then((res) => {
      if (res.products?.length) setProducts(res.products);
      setStripeConfigured(Boolean(res.stripeConfigured));
    });
    void ShopClient.fetchTransactions(entitlements.customerEmail).then(setTransactions);
  }, [entitlements.customerEmail]);

  const handleBuy = async (productId: 'premium_pass' | 'dlc_dossiers') => {
    setErrorMessage(null);
    setStatusMessage(null);
    const trimmed = email.trim();
    if (!trimmed || !trimmed.includes('@')) {
      setErrorMessage(
        fr
          ? 'Veuillez saisir une adresse e-mail valide pour recevoir votre reçu et vos droits.'
          : 'Please enter a valid email address for your receipt and entitlement.',
      );
      return;
    }

    setLoadingId(productId);
    const res = await ShopClient.createCheckoutSession(productId, trimmed);
    setLoadingId(null);

    if (!res.ok || !res.checkoutUrl) {
      setErrorMessage(
        res.error ||
          (fr
            ? 'Paiement Stripe non disponible sur ce serveur.'
            : 'Stripe checkout is not configured on this server.'),
      );
      return;
    }

    // Navigate in same window cleanly (avoid window.open blocked by iframes/popups)
    window.location.assign(res.checkoutUrl);
  };

  const handleRestore = async () => {
    setErrorMessage(null);
    setStatusMessage(null);
    setLoadingId('restore');
    const res = await ShopClient.restorePurchases(email.trim(), restoreToken.trim() || undefined);
    setLoadingId(null);
    if (!res.ok || !res.entitlements) {
      setErrorMessage(
        res.error ||
          (fr ? 'Aucun achat vérifié trouvé pour cet e-mail.' : 'No verified purchases found.'),
      );
      return;
    }
    onEntitlementsUpdated(res.entitlements);
    if (res.transactions) setTransactions(res.transactions);
    setStatusMessage(
      fr
        ? 'Achats restaurés et vérifiés cryptographiquement.'
        : 'Purchases restored and cryptographically verified.',
    );
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#030509]/90 p-4 backdrop-blur-sm">
      <div className="flex max-h-[92vh] w-full max-w-4xl flex-col border border-[#d4a24e]/40 bg-[#070c14]/98 shadow-[0_24px_70px_rgba(0,0,0,0.95)]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div className="flex items-center gap-3">
            <ShoppingBag className="h-5 w-5 text-[#f2cb79]" />
            <div>
              <div className="font-mono text-[10px] tracking-[0.22em] text-[#f2cb79] uppercase">
                {fr ? 'JEU PRINCIPAL 100% GRATUIT · EXTENSIONS OPTIONNELLES' : 'MAIN GAME 100% FREE · OPTIONAL ADD-ONS'}
              </div>
              <h2 className="font-display text-xl font-bold tracking-wider text-white uppercase">
                {fr ? 'Boutique Officielle NOCTURNE 04' : 'NOCTURNE 04 Official Store'}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex min-h-[40px] items-center gap-1.5 border border-white/15 bg-[#0d1622] px-3 py-1.5 text-xs font-semibold text-[#cfe0ee] hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
            <span>{fr ? 'Fermer' : 'Close'}</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {!stripeConfigured && (
            <div className="flex items-start gap-3 border border-[#d4a24e]/45 bg-[#1b1407] p-4 text-xs text-[#ecd299]">
              <AlertTriangle className="h-4 w-4 shrink-0 text-[#f2cb79] mt-0.5" />
              <div>
                <div className="font-bold text-white uppercase">
                  {fr
                    ? 'Passerelle Stripe prête (clé marchand non renseignée sur cette instance)'
                    : 'Stripe Gateway Ready (Merchant key not configured on this instance)'}
                </div>
                <p className="mt-1 leading-relaxed">
                  {fr
                    ? 'Conformément à la sécurité e-commerce, aucun achat n’est simulé ni débloqué sans paiement Stripe réel vérifié côté serveur. Pour activer les paiements réels, renseignez STRIPE_SECRET_KEY dans le fichier .env du serveur.'
                    : 'For strict payment security, no purchase is ever simulated or unlocked without real server-verified Stripe payment. Configure STRIPE_SECRET_KEY in the server .env to enable live checkout.'}
                </p>
              </div>
            </div>
          )}

          {statusMessage && (
            <div className="flex items-center gap-2 border border-[#4fe09b]/50 bg-[#0c271c] px-4 py-3 text-xs font-semibold text-[#8ff5c4]">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="flex items-center gap-2 border border-[#e14b56]/55 bg-[#290a0d] px-4 py-3 text-xs font-semibold text-[#ffb0b7]">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Customer Email Input */}
          <div className="border border-white/12 bg-[#0a121c] p-4">
            <label className="block text-xs font-semibold text-[#cfe0ee]">
              {fr ? 'Adresse e-mail de facturation et de sauvegarde des achats' : 'Billing & Entitlement Email'}
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="noah.kanza@exemple.com"
                className="mt-2 w-full border border-white/20 bg-[#050910] px-3.5 py-2.5 text-sm text-white placeholder-[#566b7d] focus:border-[#7bc0f2] focus:outline-none"
              />
            </label>
          </div>

          {/* Product Cards */}
          <div className="grid gap-5 md:grid-cols-2">
            {products.map((prod) => {
              const owned =
                prod.id === 'premium_pass'
                  ? entitlements.premiumPass
                  : entitlements.dlcForgottenFiles;
              return (
                <div
                  key={prod.id}
                  className="flex flex-col justify-between border border-white/15 bg-[#0a111a]"
                >
                  <div>
                    <div className="relative h-44 overflow-hidden border-b border-white/10 bg-[#04070c]">
                      <img
                        src={prod.imageUrl}
                        alt={fr ? prod.name : prod.nameEn}
                        className="h-full w-full object-cover opacity-90"
                      />
                      <div className="absolute right-3 top-3 border border-[#d4a24e] bg-[#080d14]/95 px-2.5 py-1 font-mono text-sm font-bold text-[#f2cb79]">
                        {prod.priceDisplay}
                      </div>
                    </div>

                    <div className="p-5">
                      <div className="flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-[#7bc0f2] uppercase">
                        <Sparkles className="h-3.5 w-3.5" />
                        <span>{prod.sku}</span>
                      </div>
                      <h3 className="mt-1 font-display text-lg font-bold text-white">
                        {fr ? prod.name : prod.nameEn}
                      </h3>
                      <p className="mt-1.5 text-xs text-[#a8bfd1]">
                        {fr ? prod.tagline : prod.taglineEn}
                      </p>

                      <ul className="mt-4 space-y-1.5 border-t border-white/10 pt-3 text-xs text-[#c7d9e8]">
                        {(fr ? prod.features : prod.featuresEn).map((feat) => (
                          <li key={feat} className="flex items-start gap-2">
                            <span className="text-[#7bc0f2]">•</span>
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="p-5 pt-0">
                    {owned ? (
                      <div className="flex min-h-[44px] items-center justify-center gap-2 border border-[#4fe09b]/50 bg-[#0d281c] py-2.5 text-xs font-bold tracking-wider text-[#8ff5c4] uppercase">
                        <CheckCircle2 className="h-4 w-4" />
                        <span>{fr ? 'Débloqué sur ce compte' : 'Unlocked on Account'}</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        disabled={loadingId === prod.id}
                        onClick={() => handleBuy(prod.id)}
                        className="flex min-h-[44px] w-full items-center justify-center gap-2 border border-[#d4a24e] bg-[#d4a24e] py-2.5 text-xs font-bold tracking-[0.16em] text-[#05080d] uppercase hover:bg-[#eab864] disabled:opacity-50 cursor-pointer"
                      >
                        <CreditCard className="h-4 w-4" />
                        <span>
                          {loadingId === prod.id
                            ? fr
                              ? 'Redirection Stripe...'
                              : 'Opening Stripe...'
                            : fr
                              ? `Acheter · ${prod.priceDisplay}`
                              : `Purchase · $${prod.priceUsd.toFixed(2)}`}
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Restore Purchases & Transaction History */}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="border border-white/12 bg-[#0a111a] p-4">
              <div className="flex items-center gap-2 font-mono text-xs font-bold text-[#7bc0f2] uppercase">
                <KeyRound className="h-3.5 w-3.5" />
                <span>{fr ? 'Restaurer mes achats' : 'Restore Purchases'}</span>
              </div>
              <p className="mt-1 text-xs text-[#9cb4c7]">
                {fr
                  ? 'Saisissez votre e-mail d’achat (ou jeton signé) pour vérifier vos droits auprès du serveur.'
                  : 'Enter your purchase email (or signed token) to re-verify your server entitlements.'}
              </p>
              <input
                type="text"
                value={restoreToken}
                onChange={(e) => setRestoreToken(e.target.value)}
                placeholder={fr ? 'Jeton optionnel (nk_ent_...)' : 'Optional signed token'}
                className="mt-2.5 w-full border border-white/15 bg-[#050910] px-3 py-2 font-mono text-xs text-white placeholder-[#566b7d]"
              />
              <button
                type="button"
                onClick={handleRestore}
                disabled={loadingId === 'restore'}
                className="mt-3 flex min-h-[40px] w-full items-center justify-center gap-2 border border-[#7bc0f2]/50 bg-[#102235] py-2 text-xs font-bold tracking-wider text-white uppercase hover:bg-[#193450] cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>{fr ? 'Vérifier et restaurer' : 'Verify & Restore'}</span>
              </button>
            </div>

            <div className="border border-white/12 bg-[#0a111a] p-4">
              <div className="flex items-center gap-2 font-mono text-xs font-bold text-[#7bc0f2] uppercase">
                <History className="h-3.5 w-3.5" />
                <span>{fr ? 'Historique des transactions' : 'Transaction History'}</span>
              </div>
              {transactions.length === 0 ? (
                <div className="mt-4 text-xs text-[#6f8699]">
                  {fr ? 'Aucune transaction vérifiée enregistrée.' : 'No verified transactions recorded.'}
                </div>
              ) : (
                <div className="mt-3 max-h-36 space-y-2 overflow-y-auto pr-1">
                  {transactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="flex items-center justify-between border border-white/10 bg-[#060a10] px-3 py-2 text-xs"
                    >
                      <div>
                        <div className="font-semibold text-white">{tx.productName}</div>
                        <div className="font-mono text-[10px] text-[#7f96a8]">
                          {new Date(tx.createdAt).toLocaleDateString()} · {tx.status.toUpperCase()}
                        </div>
                      </div>
                      <span className="font-mono font-bold text-[#5ee6a8]">
                        ${(tx.amountCents / 100).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
