import { Engine } from '@babylonjs/core/Engines/engine';
import { Scene } from '@babylonjs/core/scene';
import { ArcRotateCamera } from '@babylonjs/core/Cameras/arcRotateCamera';
import { Vector3 } from '@babylonjs/core/Maths/math.vector';
import { Color3, Color4 } from '@babylonjs/core/Maths/math.color';
import { HemisphericLight } from '@babylonjs/core/Lights/hemisphericLight';
import { DirectionalLight } from '@babylonjs/core/Lights/directionalLight';
import { PointLight } from '@babylonjs/core/Lights/pointLight';
import { ShadowGenerator } from '@babylonjs/core/Lights/Shadows/shadowGenerator';
import '@babylonjs/core/Lights/Shadows/shadowGeneratorSceneComponent';
import { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder';
import { PBRMaterial } from '@babylonjs/core/Materials/PBR/pbrMaterial';
import { GaussianSplattingMesh } from '@babylonjs/core/Meshes/GaussianSplatting/gaussianSplattingMesh';
import '@babylonjs/loaders/SPLAT';

const canvas = document.getElementById('renderCanvas') as HTMLCanvasElement;
const status = document.getElementById('status')!;

const isTouch =
  'ontouchstart' in window ||
  navigator.maxTouchPoints > 0 ||
  window.matchMedia('(pointer: coarse)').matches;

const engine = new Engine(canvas, false, {
  preserveDrawingBuffer: false,
  stencil: false,
  antialias: false,
  powerPreference: 'high-performance',
});

// Cap DPR to 1.0 on mobile (iPhone X 3x Retina would otherwise render at 2436x1125)
const dpr = Math.min(window.devicePixelRatio || 1, isTouch ? 1.0 : 1.5);
engine.setHardwareScalingLevel(1 / dpr);

const scene = new Scene(engine);
scene.clearColor = new Color4(0.01, 0.016, 0.026, 1);

const camera = new ArcRotateCamera(
  'camera',
  -Math.PI / 2,
  Math.PI / 2.25,
  16.0,
  new Vector3(0, 2.2, -5.0),
  scene,
);
camera.lowerRadiusLimit = 2.4;
camera.upperRadiusLimit = 46;
camera.wheelPrecision = 40;
camera.panningSensibility = 0;
camera.attachControl(canvas, true);

const hemi = new HemisphericLight('softFill', new Vector3(0, 1, 0), scene);
hemi.diffuse = new Color3(0.42, 0.56, 0.74);
hemi.groundColor = new Color3(0.04, 0.06, 0.09);
hemi.intensity = 0.45;

const moon = new DirectionalLight('moonDir', new Vector3(0.36, -0.82, 0.44), scene);
moon.position = new Vector3(-12, 24, -18);
moon.diffuse = new Color3(0.42, 0.62, 0.92);
moon.intensity = 1.1;

const beaconPt = new PointLight('beaconPt', new Vector3(0, 3.1, -15.6), scene);
beaconPt.diffuse = new Color3(1.0, 0.45, 0.18);
beaconPt.intensity = 2.2;
beaconPt.range = 10;

// Subtle PBR courtyard ground receiving Babylon.js shadows underneath the Gaussian Splat scan
const groundMat = new PBRMaterial('previewGroundMat', scene);
groundMat.albedoColor = new Color3(0.09, 0.12, 0.16);
groundMat.metallic = 0.15;
groundMat.roughness = 0.72;
const ground = MeshBuilder.CreateGround('previewGround', { width: 56, height: 64 }, scene);
ground.position.set(0, -0.04, -8);
ground.material = groundMat;
ground.receiveShadows = true;
ground.freezeWorldMatrix();

if (!isTouch) {
  const sg = new ShadowGenerator(1024, moon);
  sg.usePercentageCloserFiltering = true;
}

status.textContent = 'Chargement du scan Gaussian Splatting (Hôpital & Bâtiments)…';

const gs = new GaussianSplattingMesh('hospitalCampusScan', null, scene);
gs.minPixelSize = isTouch ? 1.8 : 1.0;
gs.loadFileAsync('/assets/gaussian/hospital_corridor_demo.splat', scene)
  .then(() => {
    gs.freezeWorldMatrix();
    status.textContent = `Scan Gaussian Splatting chargé · ${gs.getTotalVertices().toLocaleString('fr-FR')} splats`;
  })
  .catch((error) => {
    console.error(error);
    status.textContent =
      'Échec du chargement Gaussian. Vérifie que public/assets/gaussian/hospital_corridor_demo.splat est présent.';
  });

engine.runRenderLoop(() => scene.render());

const onResize = () => engine.resize();
const onPageHide = () => {
  engine.stopRenderLoop();
  gs.dispose();
  scene.dispose();
  engine.dispose();
};

window.addEventListener('resize', onResize);
window.addEventListener('pagehide', onPageHide);

document.getElementById('reset')!.addEventListener('click', () => {
  camera.alpha = -Math.PI / 2;
  camera.beta = Math.PI / 2.25;
  camera.radius = 16.0;
  camera.setTarget(new Vector3(0, 2.2, -5.0));
});

document.getElementById('back')!.addEventListener('click', () => {
  window.location.href = '/';
});
