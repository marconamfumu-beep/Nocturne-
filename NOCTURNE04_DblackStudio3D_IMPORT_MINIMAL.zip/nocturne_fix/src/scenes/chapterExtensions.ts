import {
  Color3,
  Color4,
  DynamicTexture,
  Mesh,
  MeshBuilder,
  Node,
  ParticleSystem,
  PBRMaterial,
  PointLight,
  Scene,
  ShadowGenerator,
  StandardMaterial,
  TransformNode,
  Vector3,
} from '@babylonjs/core';
import type { ChapterId, ClueNote } from '../types/game';
import { CHAPTERS } from '../story/chaptersData';
import type { Aabb2D, DoorTarget, InteractableTarget } from '../engine/hospitalScene';

export interface NoahRig {
  root: TransformNode;
  head: TransformNode;
  leftArm: TransformNode;
  rightArm: TransformNode;
  leftLeg: TransformNode;
  rightLeg: TransformNode;
  jacketMat: PBRMaterial;
  flashlightBodyMat: PBRMaterial;
  pistolMesh: TransformNode;
}

export interface FpGearRig {
  root: TransformNode;
  flashlightNode: TransformNode;
  pistolNode: TransformNode;
  muzzleFlashLight: PointLight;
  muzzleFlashMesh: Mesh;
  flashlightBodyMat: PBRMaterial;
}

export interface DrawerTarget {
  id: string;
  label: string;
  drawerMesh: TransformNode;
  isOpen: boolean;
  openProgress: number;
  lootType: 'ammo' | 'battery' | 'medkit' | 'secret_doc';
  lootId?: string;
}

export interface NpcCharacterRig {
  root: TransformNode;
  head: TransformNode;
  role: 'maya' | 'voss';
}

export function createNoahThirdPersonRig(
  scene: Scene,
  shadowGen: ShadowGenerator | null,
  hasPremiumPass: boolean,
): NoahRig {
  const root = new TransformNode('noahPlayerRig', scene);
  root.setEnabled(false);

  const skinMat = new PBRMaterial('noahSkin', scene);
  skinMat.albedoColor = new Color3(0.45, 0.31, 0.24);
  skinMat.metallic = 0.02;
  skinMat.roughness = 0.72;

  const jacketMat = new PBRMaterial('noahJacket', scene);
  jacketMat.albedoColor = hasPremiumPass
    ? new Color3(0.06, 0.13, 0.24) // Tactical Navy Paramedic Jacket (Premium Pass)
    : new Color3(0.18, 0.22, 0.26); // Standard Grey/Slate Coat
  jacketMat.metallic = hasPremiumPass ? 0.18 : 0.05;
  jacketMat.roughness = hasPremiumPass ? 0.52 : 0.82;

  const stripeMat = new StandardMaterial('noahStripe', scene);
  stripeMat.diffuseColor = hasPremiumPass ? new Color3(0.35, 0.82, 1.0) : new Color3(0.65, 0.68, 0.72);
  stripeMat.emissiveColor = hasPremiumPass ? new Color3(0.08, 0.25, 0.35) : new Color3(0, 0, 0);

  const pantsMat = new PBRMaterial('noahPants', scene);
  pantsMat.albedoColor = new Color3(0.08, 0.09, 0.12);
  pantsMat.metallic = 0.05;
  pantsMat.roughness = 0.85;

  const flashlightBodyMat = new PBRMaterial('noahFlashMat', scene);
  flashlightBodyMat.albedoColor = hasPremiumPass
    ? new Color3(0.85, 0.62, 0.22)
    : new Color3(0.22, 0.25, 0.28);
  flashlightBodyMat.metallic = 0.85;
  flashlightBodyMat.roughness = 0.28;

  const torso = MeshBuilder.CreateBox('noahTorso', { width: 0.42, height: 0.62, depth: 0.24 }, scene);
  torso.position.set(0, 1.18, 0);
  torso.material = jacketMat;
  torso.parent = root;
  shadowGen?.addShadowCaster(torso);

  // Reflective paramedic strip across chest/back
  const strip = MeshBuilder.CreateBox('noahStrip', { width: 0.43, height: 0.045, depth: 0.25 }, scene);
  strip.position.set(0, 1.24, 0);
  strip.material = stripeMat;
  strip.parent = root;

  const head = new TransformNode('noahHead', scene);
  head.position.set(0, 1.56, 0);
  head.parent = root;

  const skull = MeshBuilder.CreateSphere('noahSkull', { diameter: 0.24, segments: 10 }, scene);
  skull.position.y = 0.08;
  skull.material = skinMat;
  skull.parent = head;
  shadowGen?.addShadowCaster(skull);

  const hair = MeshBuilder.CreateSphere('noahHair', { diameter: 0.25, segments: 10 }, scene);
  hair.position.set(0, 0.11, -0.02);
  hair.scaling.set(1, 0.85, 1.02);
  hair.material = pantsMat;
  hair.parent = head;

  const makeArm = (side: -1 | 1): TransformNode => {
    const p = new TransformNode(`noahArm_${side}`, scene);
    p.position.set(side * 0.26, 1.42, 0);
    p.parent = root;
    const arm = MeshBuilder.CreateBox(`noahArmB_${side}`, { width: 0.11, height: 0.56, depth: 0.11 }, scene);
    arm.position.y = -0.24;
    arm.material = jacketMat;
    arm.parent = p;
    shadowGen?.addShadowCaster(arm);
    return p;
  };

  const makeLeg = (side: -1 | 1): TransformNode => {
    const p = new TransformNode(`noahLeg_${side}`, scene);
    p.position.set(side * 0.11, 0.86, 0);
    p.parent = root;
    const leg = MeshBuilder.CreateBox(`noahLegB_${side}`, { width: 0.14, height: 0.82, depth: 0.15 }, scene);
    leg.position.y = -0.41;
    leg.material = pantsMat;
    leg.parent = p;
    shadowGen?.addShadowCaster(leg);
    return p;
  };

  const leftArm = makeArm(-1);
  const rightArm = makeArm(1);
  const leftLeg = makeLeg(-1);
  const rightLeg = makeLeg(1);

  const flashMesh = MeshBuilder.CreateCylinder('noahTpsFlash', { diameter: 0.045, height: 0.18, tessellation: 10 }, scene);
  flashMesh.rotation.x = Math.PI / 2;
  flashMesh.position.set(0, -0.5, 0.08);
  flashMesh.material = flashlightBodyMat;
  flashMesh.parent = leftArm;

  const pistolMesh = new TransformNode('noahTpsPistol', scene);
  pistolMesh.position.set(0, -0.5, 0.09);
  pistolMesh.parent = rightArm;
  const slide = MeshBuilder.CreateBox('tpsPstSlide', { width: 0.032, height: 0.042, depth: 0.17 }, scene);
  slide.material = flashlightBodyMat;
  slide.parent = pistolMesh;
  const grip = MeshBuilder.CreateBox('tpsPstGrip', { width: 0.028, height: 0.09, depth: 0.042 }, scene);
  grip.position.set(0, -0.055, -0.05);
  grip.rotation.x = 0.2;
  grip.material = pantsMat;
  grip.parent = pistolMesh;
  pistolMesh.setEnabled(false);

  return {
    root,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    jacketMat,
    flashlightBodyMat,
    pistolMesh,
  };
}

export function createFirstPersonGearRig(
  scene: Scene,
  camera: Node,
  hasPremiumPass: boolean,
): FpGearRig {
  const root = new TransformNode('fpGearRoot', scene);
  root.parent = camera;

  const flashlightBodyMat = new PBRMaterial('fpFlashBody', scene);
  flashlightBodyMat.albedoColor = hasPremiumPass
    ? new Color3(0.86, 0.62, 0.2)
    : new Color3(0.18, 0.21, 0.25);
  flashlightBodyMat.metallic = 0.88;
  flashlightBodyMat.roughness = 0.24;

  const gunSteelMat = new PBRMaterial('fpGunSteel', scene);
  gunSteelMat.albedoColor = new Color3(0.14, 0.16, 0.19);
  gunSteelMat.metallic = 0.88;
  gunSteelMat.roughness = 0.32;

  const gripMat = new PBRMaterial('fpGunGrip', scene);
  gripMat.albedoColor = new Color3(0.06, 0.07, 0.08);
  gripMat.metallic = 0.1;
  gripMat.roughness = 0.82;

  const flashlightNode = new TransformNode('fpFlashlight', scene);
  flashlightNode.position.set(-0.22, -0.2, 0.36);
  flashlightNode.parent = root;

  const fTube = MeshBuilder.CreateCylinder('fpFTube', { diameter: 0.036, height: 0.16, tessellation: 12 }, scene);
  fTube.rotation.x = Math.PI / 2;
  fTube.material = flashlightBodyMat;
  fTube.parent = flashlightNode;

  const fHead = MeshBuilder.CreateCylinder('fpFHead', { diameterTop: 0.052, diameterBottom: 0.038, height: 0.045, tessellation: 12 }, scene);
  fHead.rotation.x = Math.PI / 2;
  fHead.position.z = 0.095;
  fHead.material = flashlightBodyMat;
  fHead.parent = flashlightNode;

  const pistolNode = new TransformNode('fpPistol', scene);
  pistolNode.position.set(0.21, -0.19, 0.38);
  pistolNode.parent = root;
  pistolNode.setEnabled(false);

  const pSlide = MeshBuilder.CreateBox('fpPSlide', { width: 0.032, height: 0.038, depth: 0.19 }, scene);
  pSlide.material = gunSteelMat;
  pSlide.parent = pistolNode;

  const pFrame = MeshBuilder.CreateBox('fpPFrame', { width: 0.028, height: 0.022, depth: 0.16 }, scene);
  pFrame.position.set(0, -0.024, -0.008);
  pFrame.material = gripMat;
  pFrame.parent = pistolNode;

  const pGrip = MeshBuilder.CreateBox('fpPGrip', { width: 0.028, height: 0.095, depth: 0.044 }, scene);
  pGrip.position.set(0, -0.072, -0.062);
  pGrip.rotation.x = 0.22;
  pGrip.material = gripMat;
  pGrip.parent = pistolNode;

  const muzzleMat = new StandardMaterial('muzzleFlashMat', scene);
  muzzleMat.diffuseColor = new Color3(1.0, 0.78, 0.3);
  muzzleMat.emissiveColor = new Color3(1.0, 0.72, 0.24);
  muzzleMat.disableLighting = true;

  const muzzleFlashMesh = MeshBuilder.CreateSphere('muzzleFlashMesh', { diameter: 0.11, segments: 6 }, scene);
  muzzleFlashMesh.position.set(0, 0.005, 0.13);
  muzzleFlashMesh.scaling.set(0.8, 0.8, 1.8);
  muzzleFlashMesh.material = muzzleMat;
  muzzleFlashMesh.parent = pistolNode;
  muzzleFlashMesh.isVisible = false;

  const muzzleFlashLight = new PointLight('muzzleFlashLight', new Vector3(0.21, -0.18, 0.56), scene);
  muzzleFlashLight.diffuse = new Color3(1.0, 0.72, 0.3);
  muzzleFlashLight.intensity = 0;
  muzzleFlashLight.range = 8.5;
  muzzleFlashLight.parent = root;

  return {
    root,
    flashlightNode,
    pistolNode,
    muzzleFlashLight,
    muzzleFlashMesh,
    flashlightBodyMat,
  };
}

export function createNpcCharacter(
  name: string,
  role: 'maya' | 'voss',
  scene: Scene,
  pos: Vector3,
  yaw: number,
  shadowGen: ShadowGenerator | null,
): NpcCharacterRig {
  const root = new TransformNode(name, scene);
  root.position.copyFrom(pos);
  root.rotation.y = yaw;

  const coatMat = new PBRMaterial(`${name}_coat`, scene);
  coatMat.albedoColor = role === 'maya' ? new Color3(0.18, 0.42, 0.52) : new Color3(0.84, 0.86, 0.88);
  coatMat.metallic = 0.04;
  coatMat.roughness = 0.78;

  const skinMat = new PBRMaterial(`${name}_skin`, scene);
  skinMat.albedoColor = role === 'maya' ? new Color3(0.48, 0.33, 0.25) : new Color3(0.76, 0.64, 0.56);
  skinMat.metallic = 0.02;
  skinMat.roughness = 0.7;

  const darkMat = new PBRMaterial(`${name}_dark`, scene);
  darkMat.albedoColor = new Color3(0.08, 0.1, 0.12);
  darkMat.roughness = 0.85;

  const torso = MeshBuilder.CreateBox(`${name}_torso`, { width: 0.38, height: 0.62, depth: 0.22 }, scene);
  torso.position.y = 1.16;
  torso.material = coatMat;
  torso.parent = root;
  shadowGen?.addShadowCaster(torso);

  const legs = MeshBuilder.CreateBox(`${name}_legs`, { width: 0.32, height: 0.84, depth: 0.18 }, scene);
  legs.position.y = 0.42;
  legs.material = darkMat;
  legs.parent = root;

  const head = new TransformNode(`${name}_head`, scene);
  head.position.set(0, 1.56, 0);
  head.parent = root;

  const skull = MeshBuilder.CreateSphere(`${name}_skull`, { diameter: 0.23, segments: 10 }, scene);
  skull.position.y = 0.08;
  skull.material = skinMat;
  skull.parent = head;

  return { root, head, role };
}

export function createBloodAndRainAtmosphere(
  scene: Scene,
  chapterId: ChapterId,
  isMobileTier: boolean,
): { dispose: () => void } {
  const createdSystems: ParticleSystem[] = [];
  const createdMeshes: Mesh[] = [];

  // Blood decals along floor & walls
  const bloodTex = new DynamicTexture('bloodDecalTex', { width: 128, height: 128 }, scene, true);
  const ctx = bloodTex.getContext() as unknown as CanvasRenderingContext2D;
  ctx.clearRect(0, 0, 128, 128);
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 58);
  grad.addColorStop(0, 'rgba(92, 6, 8, 0.88)');
  grad.addColorStop(0.55, 'rgba(62, 4, 6, 0.65)');
  grad.addColorStop(1, 'rgba(30, 0, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  bloodTex.hasAlpha = true;
  bloodTex.update(false);

  const bloodMat = new StandardMaterial('bloodDecalMat', scene);
  bloodMat.diffuseTexture = bloodTex;
  bloodMat.opacityTexture = bloodTex;
  bloodMat.useAlphaFromDiffuseTexture = true;
  bloodMat.roughness = 0.25;
  bloodMat.zOffset = -3;

  const bloodSpots: [number, number, number][] = [
    [-0.95, -12.6, 1.15],
    [0.65, -8.8, 0.85],
    [4.45, -9.8, 1.3],
    [-1.4, -1.8, 0.72],
  ];
  bloodSpots.forEach(([bx, bz, sc], idx) => {
    const decal = MeshBuilder.CreateGround(`blood_${idx}`, { width: sc, height: sc * 0.85 }, scene);
    decal.position.set(bx, 0.008, bz);
    decal.rotation.y = idx * 1.1;
    decal.material = bloodMat;
    decal.isPickable = false;
    createdMeshes.push(decal);
  });

  // Rain particle system outside courtyard windows & skylight
  const rainTex = new DynamicTexture('rainDropTex', { width: 16, height: 64 }, scene, true);
  const rCtx = rainTex.getContext() as unknown as CanvasRenderingContext2D;
  rCtx.clearRect(0, 0, 16, 64);
  const rGrad = rCtx.createLinearGradient(0, 0, 0, 64);
  rGrad.addColorStop(0, 'rgba(170,210,245,0)');
  rGrad.addColorStop(0.5, 'rgba(180,220,255,0.65)');
  rGrad.addColorStop(1, 'rgba(170,210,245,0)');
  rCtx.fillStyle = rGrad;
  rCtx.fillRect(6, 0, 4, 64);
  rainTex.hasAlpha = true;
  rainTex.update(false);

  const rainSys = new ParticleSystem('exteriorRain', isMobileTier ? 90 : 240, scene);
  rainSys.particleTexture = rainTex;
  rainSys.emitter = new Vector3(-9.5, 8.5, -5.0);
  rainSys.minEmitBox = new Vector3(-4, 0, -14);
  rainSys.maxEmitBox = new Vector3(4, 2, 14);
  rainSys.color1 = new Color4(0.65, 0.82, 1.0, 0.48);
  rainSys.color2 = new Color4(0.5, 0.7, 0.95, 0.32);
  rainSys.minSize = 0.14;
  rainSys.maxSize = 0.28;
  rainSys.minLifeTime = 0.6;
  rainSys.maxLifeTime = 1.0;
  rainSys.emitRate = isMobileTier ? 65 : 180;
  rainSys.direction1 = new Vector3(-0.3, -11, 0.2);
  rainSys.direction2 = new Vector3(0.3, -13, -0.2);
  rainSys.minEmitPower = 1.0;
  rainSys.maxEmitPower = 1.4;
  rainSys.start();
  createdSystems.push(rainSys);

  // Fire / Embers in Chapter 6 (Self-Destruct) or DLC (11 Years Ago Fire)
  if (chapterId === 'ch6' || chapterId === 'dlc1') {
    const emberSys = new ParticleSystem('fireEmbers', isMobileTier ? 70 : 180, scene);
    emberSys.particleTexture = rainTex;
    emberSys.emitter = new Vector3(0, 0.4, -2);
    emberSys.minEmitBox = new Vector3(-2.1, 0, -14);
    emberSys.maxEmitBox = new Vector3(2.1, 0.4, 14);
    emberSys.color1 = new Color4(1.0, 0.48, 0.12, 0.85);
    emberSys.color2 = new Color4(1.0, 0.22, 0.06, 0.65);
    emberSys.colorDead = new Color4(0.4, 0.05, 0.02, 0);
    emberSys.minSize = 0.03;
    emberSys.maxSize = 0.08;
    emberSys.minLifeTime = 1.5;
    emberSys.maxLifeTime = 3.2;
    emberSys.emitRate = isMobileTier ? 28 : 75;
    emberSys.blendMode = ParticleSystem.BLENDMODE_ADD;
    emberSys.direction1 = new Vector3(-0.3, 1.1, -0.3);
    emberSys.direction2 = new Vector3(0.3, 2.2, 0.3);
    emberSys.start();
    createdSystems.push(emberSys);
  }

  return {
    dispose: () => {
      createdSystems.forEach((s) => s.dispose());
      createdMeshes.forEach((m) => m.dispose());
      bloodTex.dispose();
      rainTex.dispose();
    },
  };
}

export interface ChapterExtensionResult {
  drawers: DrawerTarget[];
  npcs: NpcCharacterRig[];
  extraInteractables: InteractableTarget[];
  cleanup: () => void;
}

export function populateChapterExtensions(
  scene: Scene,
  chapterId: ChapterId,
  steelMat: PBRMaterial,
  darkMetalMat: PBRMaterial,
  glassMat: PBRMaterial,
  colliders: Aabb2D[],
  shadowGen: ShadowGenerator | null,
): ChapterExtensionResult {
  const drawers: DrawerTarget[] = [];
  const npcs: NpcCharacterRig[] = [];
  const extraInteractables: InteractableTarget[] = [];
  const disposableNodes: TransformNode[] = [];

  const chapterCfg = CHAPTERS[chapterId];
  scene.fogColor.set(chapterCfg.fogColor[0], chapterCfg.fogColor[1], chapterCfg.fogColor[2]);
  scene.fogDensity = chapterCfg.fogDensity;

  // Helper to create an interactive glowing pickup / terminal / drawer
  const makeAccentRing = (id: string, color: Color3, parent: TransformNode, y = 0.03): Mesh => {
    const ringMat = new StandardMaterial(`${id}_ringM`, scene);
    ringMat.diffuseColor = color;
    ringMat.emissiveColor = color;
    ringMat.disableLighting = true;
    ringMat.alpha = 0.72;
    const ring = MeshBuilder.CreateTorus(`${id}_rng`, { diameter: 0.28, thickness: 0.02, tessellation: 16 }, scene);
    ring.position.y = y;
    ring.material = ringMat;
    ring.parent = parent;
    return ring;
  };

  // Searchable Medical Filing Cabinets with Animated Drawers
  const addCabinetDrawer = (
    id: string,
    label: string,
    x: number,
    z: number,
    rotY: number,
    lootType: DrawerTarget['lootType'],
    lootId?: string,
  ) => {
    const cabRoot = new TransformNode(id, scene);
    cabRoot.position.set(x, 0, z);
    cabRoot.rotation.y = rotY;
    disposableNodes.push(cabRoot);

    const body = MeshBuilder.CreateBox(`${id}_body`, { width: 0.62, height: 1.15, depth: 0.56 }, scene);
    body.position.y = 0.575;
    body.material = darkMetalMat;
    body.parent = cabRoot;
    shadowGen?.addShadowCaster(body);

    const drawerPivot = new TransformNode(`${id}_drw`, scene);
    drawerPivot.position.set(0, 0.88, 0.02);
    drawerPivot.parent = cabRoot;

    const face = MeshBuilder.CreateBox(`${id}_face`, { width: 0.54, height: 0.24, depth: 0.48 }, scene);
    face.material = steelMat;
    face.parent = drawerPivot;

    const hdl = MeshBuilder.CreateBox(`${id}_hdl`, { width: 0.2, height: 0.03, depth: 0.04 }, scene);
    hdl.position.set(0, 0, 0.26);
    hdl.material = darkMetalMat;
    hdl.parent = drawerPivot;

    colliders.push({ minX: x - 0.36, maxX: x + 0.36, minZ: z - 0.36, maxZ: z + 0.36 });

    const ring = makeAccentRing(id, new Color3(0.95, 0.78, 0.35), cabRoot, 1.17);
    const dtTarget: DrawerTarget = {
      id,
      label,
      drawerMesh: drawerPivot,
      isOpen: false,
      openProgress: 0,
      lootType,
      lootId,
    };
    drawers.push(dtTarget);

    extraInteractables.push({
      id,
      label,
      position: new Vector3(x, 0.92, z),
      root: cabRoot,
      ringMesh: ring,
      collected: false,
      note: {
        id: `${id}_drawer`,
        title: label,
        subtitle: 'Tiroir fouillé',
        body: 'Fouille du tiroir…',
      },
      // Custom metadata attached via id prefix 'drawer_'
    });
  };

  addCabinetDrawer('drawer_rec', 'Tiroir médical (Piles & Munitions)', 5.1, 2.7, -Math.PI / 2, 'ammo');
  addCabinetDrawer('drawer_obs', 'Armoire d’Observation (Soin)', -5.3, -6.1, Math.PI / 2, 'medkit');
  addCabinetDrawer('drawer_surg', 'Tiroir chirurgical (Batterie)', 5.7, -11.9, -Math.PI / 2, 'battery');

  // Pistol Pickup (Chapter 1 & all chapters if not yet owned — placed on Reception Counter / Security Crate)
  const addCrateItem = (
    id: string,
    label: string,
    pos: Vector3,
    color: Color3,
    kind: 'pistol' | 'ammo' | 'battery' | 'medkit' | 'flare' | 'tape' | 'cctv' | 'puzzle' | 'secret_doc' | 'bonus_doc',
    note?: ClueNote,
  ) => {
    const root = new TransformNode(id, scene);
    root.position.copyFrom(pos);
    disposableNodes.push(root);

    if (kind === 'pistol') {
      const gunMat = new PBRMaterial(`${id}_gm`, scene);
      gunMat.albedoColor = new Color3(0.22, 0.25, 0.29);
      gunMat.metallic = 0.88;
      gunMat.roughness = 0.25;
      const slide = MeshBuilder.CreateBox(`${id}_sl`, { width: 0.04, height: 0.045, depth: 0.22 }, scene);
      slide.position.y = 0.05;
      slide.material = gunMat;
      slide.parent = root;
      const grip = MeshBuilder.CreateBox(`${id}_gr`, { width: 0.036, height: 0.1, depth: 0.05 }, scene);
      grip.position.set(0, 0.01, -0.07);
      grip.rotation.x = 0.25;
      grip.material = darkMetalMat;
      grip.parent = root;
    } else if (kind === 'medkit') {
      const kitMat = new StandardMaterial(`${id}_mk`, scene);
      kitMat.diffuseColor = new Color3(0.92, 0.94, 0.96);
      kitMat.emissiveColor = new Color3(0.12, 0.25, 0.18);
      const box = MeshBuilder.CreateBox(`${id}_bx`, { width: 0.24, height: 0.09, depth: 0.18 }, scene);
      box.position.y = 0.045;
      box.material = kitMat;
      box.parent = root;
      const crossMat = new StandardMaterial(`${id}_cr`, scene);
      crossMat.diffuseColor = new Color3(0.88, 0.18, 0.18);
      crossMat.emissiveColor = new Color3(0.5, 0.08, 0.08);
      const c1 = MeshBuilder.CreateBox(`${id}_c1`, { width: 0.1, height: 0.01, depth: 0.03 }, scene);
      c1.position.y = 0.095;
      c1.material = crossMat;
      c1.parent = root;
      const c2 = MeshBuilder.CreateBox(`${id}_c2`, { width: 0.03, height: 0.01, depth: 0.1 }, scene);
      c2.position.y = 0.095;
      c2.material = crossMat;
      c2.parent = root;
    } else if (kind === 'battery' || kind === 'ammo' || kind === 'flare') {
      const mat = new StandardMaterial(`${id}_bm`, scene);
      mat.diffuseColor = color;
      mat.emissiveColor = color.scale(0.35);
      const cyl = MeshBuilder.CreateBox(`${id}_cy`, { width: 0.12, height: 0.07, depth: 0.15 }, scene);
      cyl.position.y = 0.035;
      cyl.material = mat;
      cyl.parent = root;
    } else if (kind === 'cctv' || kind === 'puzzle') {
      const termMat = new StandardMaterial(`${id}_tm`, scene);
      termMat.diffuseColor = new Color3(0.08, 0.14, 0.18);
      termMat.emissiveColor = color.scale(0.6);
      const scr = MeshBuilder.CreateBox(`${id}_sc`, { width: 0.42, height: 0.32, depth: 0.08 }, scene);
      scr.position.y = 0.2;
      scr.material = termMat;
      scr.parent = root;
    } else {
      // Tape or Doc
      const docMat = new StandardMaterial(`${id}_dm`, scene);
      docMat.diffuseColor = color;
      docMat.emissiveColor = color.scale(0.3);
      const sheet = MeshBuilder.CreateBox(`${id}_sh`, { width: 0.2, height: 0.025, depth: 0.26 }, scene);
      sheet.position.y = 0.015;
      sheet.material = docMat;
      sheet.parent = root;
    }

    const ring = makeAccentRing(id, color, root, 0.02);
    extraInteractables.push({
      id,
      label,
      position: pos.clone(),
      root,
      ringMesh: ring,
      collected: false,
      note,
    });
  };

  // Universal Tactical Items placed in wings
  addCrateItem(
    'pickup_pistol_9mm',
    'Pistolet de service 9mm',
    new Vector3(3.85, 1.1, 3.8),
    new Color3(0.95, 0.82, 0.35),
    'pistol',
    {
      id: 'pickup_pistol_9mm',
      title: 'PISTOLET DE SERVICE 9MM',
      subtitle: 'Arme de défense · Munitions limitées',
      body: 'Utilisez [Clic Gauche] pour tirer et [R] pour recharger. Le 9mm ralentit et désoriente le Patient 04 pendant quelques secondes sans le tuer.',
    },
  );
  addCrateItem('pickup_ammo_1', 'Chargeur 9mm (+6 balles)', new Vector3(-1.6, 0.02, 2.2), new Color3(0.95, 0.72, 0.28), 'ammo');
  addCrateItem('pickup_ammo_2', 'Chargeur 9mm (+6 balles)', new Vector3(4.9, 0.02, -11.4), new Color3(0.95, 0.72, 0.28), 'ammo');
  addCrateItem('pickup_battery_1', 'Pile Lithium (Lampe +50%)', new Vector3(1.5, 0.02, 7.6), new Color3(0.4, 0.85, 1.0), 'battery');
  addCrateItem('pickup_battery_2', 'Pile Lithium (Lampe +50%)', new Vector3(-4.8, 0.02, -3.1), new Color3(0.4, 0.85, 1.0), 'battery');
  addCrateItem('pickup_medkit_1', 'Trousse de Premiers Soins', new Vector3(3.45, 1.1, 5.6), new Color3(0.35, 0.95, 0.62), 'medkit');
  addCrateItem('pickup_flare_1', 'Fusée Éclairante de Défense', new Vector3(-3.3, 0.02, 6.9), new Color3(1.0, 0.38, 0.25), 'flare');

  // Chapter-specific terminals, tapes, documents, CCTV & NPCs
  if (chapterId === 'ch1') {
    addCrateItem('doc_ch1_intake', 'Note d’Évacuation (Document)', new Vector3(3.6, 1.1, 4.35), new Color3(0.75, 0.88, 1.0), 'secret_doc');
    addCrateItem('doc_ch1_maya_log', 'Journal de Maya (Document)', new Vector3(-3.55, 0.02, -5.8), new Color3(0.75, 0.88, 1.0), 'secret_doc');
    addCrateItem('doc_premium_1', '[BONUS] Rapport d’Autopsie', new Vector3(5.2, 0.02, -8.1), new Color3(1.0, 0.75, 0.25), 'bonus_doc');
    addCrateItem('puzzle_ch1_gen', 'Console d’Amorçage (Énigme)', new Vector3(-3.85, 0.95, 4.55), new Color3(1.0, 0.65, 0.25), 'puzzle');
  }

  if (chapterId === 'ch2') {
    addCrateItem('cctv_terminal_ch2', 'Terminal Vidéosurveillance CCTV', new Vector3(3.85, 1.12, 4.95), new Color3(0.32, 0.92, 0.78), 'cctv');
    addCrateItem('tape_ch2_voss', 'Bande Audio #04 (Dr. Voss)', new Vector3(-3.95, 0.55, -4.45), new Color3(0.68, 0.86, 1.0), 'tape');
    addCrateItem('doc_ch2_nocturne', 'Directive NOCTURNE (Document)', new Vector3(4.45, 0.9, -9.45), new Color3(0.75, 0.88, 1.0), 'secret_doc');
    addCrateItem('doc_ch2_security', 'Rapport CCTV Archives (Document)', new Vector3(-1.32, 1.02, 8.45), new Color3(0.75, 0.88, 1.0), 'secret_doc');
    addCrateItem('puzzle_ch2_keypad', 'Digicode du Dépôt Est (0217)', new Vector3(1.52, 1.15, -14.8), new Color3(1.0, 0.58, 0.24), 'puzzle');
  }

  if (chapterId === 'ch3') {
    addCrateItem('doc_ch3_surgery', 'Protocole 04-A / 04-B (Document)', new Vector3(4.35, 0.9, -10.25), new Color3(0.75, 0.88, 1.0), 'secret_doc');
    addCrateItem('doc_ch3_freq', 'Calibrage EEG 408 Hz (Document)', new Vector3(-3.95, 0.55, -4.45), new Color3(0.75, 0.88, 1.0), 'secret_doc');
    addCrateItem('puzzle_ch3_freq', 'Stimulateur Neuronal (408 Hz)', new Vector3(1.52, 1.15, -14.8), new Color3(0.35, 0.95, 0.78), 'puzzle');
  }

  if (chapterId === 'ch4' || chapterId === 'ch5' || chapterId === 'ch6') {
    // Bio-Containment Glass Pods in the corridor/observation bay with glowing fluid
    const podPositions: [number, number][] = [
      [-1.55, -1.5],
      [1.55, -1.5],
      [-1.55, 1.5],
    ];
    const podMat = new StandardMaterial('bioPodFluid', scene);
    podMat.diffuseColor = new Color3(0.18, 0.75, 0.68);
    podMat.emissiveColor = new Color3(0.08, 0.36, 0.34);
    podMat.alpha = 0.48;

    podPositions.forEach(([px, pz], idx) => {
      const pod = new TransformNode(`bioPod_${idx}`, scene);
      pod.position.set(px, 0, pz);
      disposableNodes.push(pod);

      const capB = MeshBuilder.CreateCylinder(`podBase_${idx}`, { diameter: 0.88, height: 0.16, tessellation: 14 }, scene);
      capB.position.y = 0.08;
      capB.material = darkMetalMat;
      capB.parent = pod;

      const capT = capB.clone(`podTop_${idx}`);
      capT.position.y = 2.45;
      capT.parent = pod;

      const cyl = MeshBuilder.CreateCylinder(`podGlass_${idx}`, { diameter: 0.78, height: 2.24, tessellation: 14 }, scene);
      cyl.position.y = 1.28;
      cyl.material = podMat;
      cyl.parent = pod;

      const silhouette = MeshBuilder.CreateCylinder(`podSubj_${idx}`, { diameterTop: 0.28, diameterBottom: 0.22, height: 1.55, tessellation: 8 }, scene);
      silhouette.position.y = 1.18;
      silhouette.material = darkMetalMat;
      silhouette.parent = pod;

      colliders.push({ minX: px - 0.45, maxX: px + 0.45, minZ: pz - 0.45, maxZ: pz + 0.45 });
    });

    if (chapterId === 'ch4') {
      const maya = createNpcCharacter('mayaNpc', 'maya', scene, new Vector3(-4.1, 0, -4.8), Math.PI / 2, shadowGen);
      disposableNodes.push(maya.root);
      npcs.push(maya);

      const voss = createNpcCharacter('vossNpc', 'voss', scene, new Vector3(4.5, 0, -10.0), -Math.PI / 2, shadowGen);
      disposableNodes.push(voss.root);
      npcs.push(voss);

      addCrateItem('cctv_terminal_ch4', 'Moniteur Cuves de Stase', new Vector3(3.85, 1.12, 4.95), new Color3(0.32, 0.92, 0.78), 'cctv');
      addCrateItem('tape_ch4_maya', 'Bande #09 de Maya', new Vector3(-3.95, 0.55, -4.45), new Color3(0.68, 0.86, 1.0), 'tape');
      addCrateItem('doc_ch4_voss', 'Manifeste du Dr Voss', new Vector3(4.35, 0.9, -10.25), new Color3(0.75, 0.88, 1.0), 'secret_doc');
      addCrateItem('doc_premium_2', '[BONUS] L’Écho de Maya', new Vector3(-4.8, 0.02, 6.4), new Color3(1.0, 0.75, 0.25), 'bonus_doc');
      addCrateItem('puzzle_ch4_lab', 'Console des Cuves (Choix Moral)', new Vector3(1.52, 1.15, -14.8), new Color3(0.35, 0.85, 1.0), 'puzzle');
    }

    if (chapterId === 'ch5') {
      addCrateItem('doc_ch5_secret_1', '[SECRET 1/3] Origine Elias Kanza', new Vector3(-3.95, 0.55, -4.45), new Color3(1.0, 0.32, 0.32), 'secret_doc');
      addCrateItem('doc_ch5_secret_2', '[SECRET 2/3] Clef Maîtresse NOCTURNE', new Vector3(4.45, 0.9, -9.45), new Color3(1.0, 0.32, 0.32), 'secret_doc');
      addCrateItem('doc_ch5_secret_3', '[SECRET 3/3] Protocole Patient 05', new Vector3(-4.65, 1.52, 3.85), new Color3(1.0, 0.32, 0.32), 'secret_doc');
      addCrateItem('puzzle_ch5_cell04', 'Sas Chambre 04 (Code 0411)', new Vector3(1.52, 1.15, -14.8), new Color3(1.0, 0.45, 0.35), 'puzzle');
    }

    if (chapterId === 'ch6') {
      const mayaFinal = createNpcCharacter('mayaFinalNpc', 'maya', scene, new Vector3(-1.4, 0, -14.8), 0, shadowGen);
      disposableNodes.push(mayaFinal.root);
      npcs.push(mayaFinal);

      const vossFinal = createNpcCharacter('vossFinalNpc', 'voss', scene, new Vector3(1.2, 0, -13.4), Math.PI, shadowGen);
      disposableNodes.push(vossFinal.root);
      npcs.push(vossFinal);

      addCrateItem('puzzle_ch6_core', 'Noyau d’Autodestruction (0404)', new Vector3(-4.65, 1.52, 3.85), new Color3(1.0, 0.22, 0.22), 'puzzle');
      // Extra defensive ammo/flares for final chase
      addCrateItem('pickup_ammo_final', 'Boîte de Munitions 9mm', new Vector3(0.4, 0.02, 7.2), new Color3(0.95, 0.72, 0.28), 'ammo');
      addCrateItem('pickup_flare_final', 'Fusée Éclairante', new Vector3(-0.6, 0.02, 4.1), new Color3(1.0, 0.38, 0.25), 'flare');
    }
  }

  if (chapterId === 'dlc1') {
    addCrateItem('doc_dlc_1', 'Dossier Oublié #01 (Bloc Zéro)', new Vector3(3.62, 1.12, 4.95), new Color3(1.0, 0.62, 0.28), 'secret_doc');
    addCrateItem('tape_dlc_fire', 'Bande Boîte Noire 2015', new Vector3(-3.95, 0.55, -4.45), new Color3(1.0, 0.62, 0.28), 'tape');
    addCrateItem('puzzle_dlc_fire', 'Vanne Anti-Incendie (4231)', new Vector3(1.52, 1.15, -14.8), new Color3(1.0, 0.42, 0.18), 'puzzle');
  }

  // Keep reference to glassMat used by pod visual framing if needed
  void glassMat;

  return {
    drawers,
    npcs,
    extraInteractables,
    cleanup: () => {
      disposableNodes.forEach((n) => n.dispose());
    },
  };
}
