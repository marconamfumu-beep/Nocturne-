import { Scalar } from '@babylonjs/core';
import type { DifficultyConfig } from '../gameplay/difficulty';
import type { ChapterId, MonsterAIState } from '../types/game';
import type { Aabb2D, DoorTarget, HideoutTarget } from '../engine/hospitalScene';

export interface MonsterUpdateInput {
  dt: number;
  elapsed: number;
  chapterId: ChapterId;
  diff: DifficultyConfig;
  playerX: number;
  playerZ: number;
  playerCrouching: boolean;
  playerSprinting: boolean;
  flashlightOn: boolean;
  activeHideout: HideoutTarget | null;
  hideoutSeenByMonster: boolean;
  generatorRestored: boolean;
  cluesCollected: number;
  colliders: Aabb2D[];
  doors: DoorTarget[];
  hideouts: HideoutTarget[];
  hasLineOfSight: (ax: number, az: number, bx: number, bz: number) => boolean;
  resolveCircle: (px: number, pz: number, radius: number) => [number, number];
  getZone: (x: number, z: number) => string;
  getZoneThreshold: (zone: string) => [number, number];
  onAlert: () => void;
  onStep: (mx: number, mz: number) => void;
  onDoorBang: () => void;
  onDoorBreak: (door: DoorTarget) => void;
  onFlushHideout: () => void;
  onAttackPlayer: (damage: number) => void;
  onMimicVoice: () => void;
}

export interface MonsterSnapshot {
  state: MonsterAIState;
  x: number;
  z: number;
  yaw: number;
  walkPhase: number;
  dangerLevel: number;
  staggered: boolean;
}

export class Patient04AI {
  public state: MonsterAIState = 'dormant';
  public x = 0;
  public z = -14.2;
  public yaw = 0;
  public walkPhase = 0;
  public dangerLevel = 0;

  private lastStepHalf = 0;
  private lastSeenX = 0;
  private lastSeenZ = -10;
  private rememberedPos: { x: number; z: number } | null = null;
  private searchTimer = 0;
  private suspicionTimer = 0;
  private ambushTimer = 0;
  private attackCooldownTimer = 0;
  private staggerTimer = 0;
  private doorBreakTimer = 0;
  private doorBangCooldown = 0;
  private mimicCooldown = 14;
  private patrolIndex = 1;
  private patrolPoints: [number, number][] = [
    [0, -13.0],
    [0, -4.5],
    [-3.8, -4.5],
    [0, 4.5],
    [3.6, 4.5],
    [0, 11.2],
    [0, -9.8],
  ];

  public reset(startX = 0, startZ = -14.2, startDormant = true): void {
    this.state = startDormant ? 'dormant' : 'patrol';
    this.x = startX;
    this.z = startZ;
    this.yaw = 0;
    this.walkPhase = 0;
    this.lastStepHalf = 0;
    this.dangerLevel = 0;
    this.lastSeenX = startX;
    this.lastSeenZ = startZ + 4;
    this.rememberedPos = null;
    this.searchTimer = 0;
    this.suspicionTimer = 0;
    this.ambushTimer = 0;
    this.attackCooldownTimer = 0;
    this.staggerTimer = 0;
    this.doorBreakTimer = 0;
    this.doorBangCooldown = 0;
    this.mimicCooldown = 11;
    this.patrolIndex = 1;
  }

  public setPatrolPoints(points: [number, number][]): void {
    if (points.length > 0) {
      this.patrolPoints = points;
      this.patrolIndex = 0;
    }
  }

  public wakeUp(): void {
    if (this.state === 'dormant') {
      this.state = 'patrol';
    }
  }

  public notifySound(sx: number, sz: number, radius: number, urgent = false): void {
    if (this.state === 'dormant') {
      this.state = 'patrol';
    }
    if (this.state === 'staggered') return;
    const d = Math.hypot(sx - this.x, sz - this.z);
    if (d > radius) return;

    this.lastSeenX = sx;
    this.lastSeenZ = sz;
    this.rememberedPos = { x: sx, z: sz };
    if (urgent || this.state === 'patrol' || this.state === 'return') {
      this.state = urgent ? 'investigate' : 'suspicion';
      this.suspicionTimer = urgent ? 6.5 : 3.2;
      this.searchTimer = 5.5;
    } else if (this.state === 'suspicion' || this.state === 'investigate' || this.state === 'search') {
      this.state = 'investigate';
      this.searchTimer = 6.0;
    }
  }

  public applyHitStagger(durationSec: number, knockbackX: number, knockbackZ: number): void {
    this.staggerTimer = durationSec;
    this.state = 'staggered';
    this.x += knockbackX;
    this.z += knockbackZ;
  }

  public update(input: MonsterUpdateInput): MonsterSnapshot {
    const {
      dt,
      chapterId,
      diff,
      playerX,
      playerZ,
      playerCrouching,
      playerSprinting,
      flashlightOn,
      activeHideout,
      hideoutSeenByMonster,
      generatorRestored,
      cluesCollected,
      doors,
      hideouts,
      hasLineOfSight,
      resolveCircle,
      getZone,
      getZoneThreshold,
      onAlert,
      onStep,
      onDoorBang,
      onDoorBreak,
      onFlushHideout,
      onAttackPlayer,
      onMimicVoice,
    } = input;

    const dxP = playerX - this.x;
    const dzP = playerZ - this.z;
    const distToPlayer = Math.hypot(dxP, dzP);

    // Chapter progression multiplier (AI evolves across the 6 chapters)
    const chapterAggro =
      chapterId === 'ch1'
        ? 1.0
        : chapterId === 'ch2'
          ? 1.05
          : chapterId === 'ch3'
            ? 1.1
            : chapterId === 'ch4'
              ? 1.14
              : chapterId === 'ch5'
                ? 1.18
                : chapterId === 'ch6'
                  ? 1.25
                  : 1.08;

    if (this.attackCooldownTimer > 0) {
      this.attackCooldownTimer = Math.max(0, this.attackCooldownTimer - dt);
    }

    if (this.state === 'dormant') {
      if (input.elapsed > 10 || cluesCollected >= 1 || chapterId === 'ch6') {
        this.state = 'patrol';
        onAlert();
      }
      this.dangerLevel = Math.max(0, this.dangerLevel - dt * 1.5);
      return this.snapshot();
    }

    if (this.state === 'staggered') {
      this.staggerTimer -= dt;
      this.dangerLevel = Scalar.Lerp(this.dangerLevel, 0.35, 1 - Math.exp(-4 * dt));
      if (this.staggerTimer <= 0) {
        this.state = 'search';
        this.searchTimer = diff.chaseGiveUpSec;
        this.lastSeenX = playerX;
        this.lastSeenZ = playerZ;
      }
      return this.snapshot();
    }

    // Voice mimicry deception (especially chapters 2..6)
    this.mimicCooldown -= dt;
    if (this.mimicCooldown <= 0 && distToPlayer < 19 && this.state !== 'chase') {
      this.mimicCooldown = chapterId === 'ch1' ? 24 : 15 + Math.random() * 10;
      onMimicVoice();
    }

    // Perception: vision cone + flashlight reactivity + noise
    let canSeePlayer = hasLineOfSight(this.x, this.z, playerX, playerZ);
    const baseVision = diff.monsterVisionRange * chapterAggro;
    const detectRange =
      playerCrouching && !flashlightOn
        ? 4.4
        : flashlightOn || playerSprinting
          ? baseVision
          : baseVision * 0.66;
    const noiseRange = (playerSprinting ? 8.2 : 0) * diff.monsterHearingMultiplier;

    if (activeHideout) {
      if (hideoutSeenByMonster && distToPlayer < 2.3) {
        onDoorBang();
        onFlushHideout();
        canSeePlayer = true;
        this.state = 'chase';
        onAlert();
        this.lastSeenX = playerX;
        this.lastSeenZ = playerZ;
        this.searchTimer = diff.chaseGiveUpSec;
      } else if (flashlightOn && distToPlayer < 9.5) {
        if (this.state !== 'chase') {
          this.state = 'chase';
          onAlert();
        }
        this.lastSeenX = playerX;
        this.lastSeenZ = playerZ;
        this.searchTimer = diff.chaseGiveUpSec;
      } else {
        canSeePlayer = false;
        if (this.state === 'chase') {
          this.state = 'search';
          this.searchTimer = 4.5;
        }
      }
    } else if ((canSeePlayer && distToPlayer < detectRange) || distToPlayer < noiseRange) {
      if (this.state !== 'chase' && this.state !== 'attack') {
        if (this.state === 'patrol' && distToPlayer > detectRange * 0.72 && !playerSprinting) {
          // Brief suspicion before full chase at edge of vision
          this.state = 'suspicion';
          this.suspicionTimer = 1.1;
          this.lastSeenX = playerX;
          this.lastSeenZ = playerZ;
        } else {
          this.state = 'chase';
          onAlert();
        }
      }
      this.lastSeenX = playerX;
      this.lastSeenZ = playerZ;
      this.rememberedPos = { x: playerX, z: playerZ };
      this.searchTimer = diff.chaseGiveUpSec;
    } else if (this.state === 'chase' || this.state === 'attack') {
      this.state = 'search';
      this.searchTimer = diff.chaseGiveUpSec;
    }

    // Danger meter
    const proximityDanger = Math.max(0, Math.min(1, 1 - (distToPlayer - 1.5) / 12.0));
    const targetDanger =
      this.state === 'chase' || this.state === 'attack'
        ? Math.max(0.58, proximityDanger)
        : this.state === 'suspicion' || this.state === 'investigate'
          ? Math.max(0.28, proximityDanger * 0.8)
          : proximityDanger * 0.65;
    this.dangerLevel = Scalar.Lerp(this.dangerLevel, targetDanger, 1 - Math.exp(-5 * dt));

    // Attack check
    if (distToPlayer < 1.18 && canSeePlayer && !activeHideout) {
      this.state = 'attack';
      if (this.attackCooldownTimer <= 0) {
        this.attackCooldownTimer = diff.attackCooldown;
        onAttackPlayer(diff.monsterDamage);
      }
      // Face player while attacking
      this.yaw = Math.atan2(dxP, dzP);
      return this.snapshot();
    }

    // Choose navigation goal & speed
    let goalX = this.x;
    let goalZ = this.z;
    let moveSpeed = diff.monsterPatrolSpeed * chapterAggro;

    if (this.state === 'chase') {
      goalX = playerX;
      goalZ = playerZ;
      moveSpeed = diff.monsterChaseSpeed * chapterAggro * (generatorRestored ? 1.06 : 1.0);
    } else if (this.state === 'suspicion') {
      goalX = this.lastSeenX;
      goalZ = this.lastSeenZ;
      moveSpeed = diff.monsterInvestigateSpeed * 0.85;
      this.suspicionTimer -= dt;
      if (this.suspicionTimer <= 0) {
        this.state = 'investigate';
        this.searchTimer = 5.0;
      }
    } else if (this.state === 'investigate' || this.state === 'search') {
      goalX = this.lastSeenX;
      goalZ = this.lastSeenZ;
      moveSpeed = diff.monsterInvestigateSpeed;
      this.searchTimer -= dt;
      if (Math.hypot(goalX - this.x, goalZ - this.z) < 0.85) {
        // Inspect nearby hideout if player disappeared near one!
        const nearbyHideout = hideouts.find(
          (h) => Math.hypot(h.position.x - this.x, h.position.z - this.z) < 2.2,
        );
        if (nearbyHideout && Math.random() < 0.02) {
          onDoorBang();
        }
        if (this.rememberedPos && Math.hypot(this.rememberedPos.x - this.x, this.rememberedPos.z - this.z) > 1.5) {
          this.lastSeenX = this.rememberedPos.x;
          this.lastSeenZ = this.rememberedPos.z;
          this.rememberedPos = null;
        }
      }
      if (this.searchTimer <= 0) {
        this.state = 'return';
      }
    } else if (this.state === 'return') {
      const wp = this.patrolPoints[this.patrolIndex];
      goalX = wp[0];
      goalZ = wp[1];
      moveSpeed = diff.monsterPatrolSpeed;
      if (Math.hypot(goalX - this.x, goalZ - this.z) < 0.9) {
        this.state = 'patrol';
      }
    } else {
      // Patrol (with occasional corridor ambush pauses in Ch3+)
      if (this.ambushTimer > 0) {
        this.ambushTimer -= dt;
        moveSpeed = 0;
      } else {
        const wp = this.patrolPoints[this.patrolIndex];
        goalX = wp[0];
        goalZ = wp[1];
        if (Math.hypot(goalX - this.x, goalZ - this.z) < 0.85) {
          this.patrolIndex = (this.patrolIndex + 1) % this.patrolPoints.length;
          if (chapterId !== 'ch1' && Math.random() < 0.25) {
            this.ambushTimer = 2.2 + Math.random() * 1.8;
          }
        }
      }
    }

    // Zone-threshold navigation so Patient 04 walks cleanly through doorways
    const mZone = getZone(this.x, this.z);
    const gZone = getZone(goalX, goalZ);
    let steerX = goalX;
    let steerZ = goalZ;

    if (mZone !== gZone) {
      if (mZone !== 'corridor') {
        const [tx, tz] = getZoneThreshold(mZone);
        steerX = tx;
        steerZ = tz;
      } else {
        const [tx, tz] = getZoneThreshold(gZone);
        if (Math.abs(this.z - tz) > 1.2) {
          steerX = 0;
          steerZ = tz;
        } else {
          steerX = tx < 0 ? -2.9 : 2.9;
          steerZ = tz;
        }
      }
    }

    // Door interaction / breaking unlocked doors
    let blockedByDoor = false;
    for (const d of doors) {
      if (!d.isOpen && d.isUnlocked && !d.collider.disabled) {
        const distDoor = Math.hypot(this.x - d.position.x, this.z - d.position.z);
        if (distDoor < 1.35) {
          blockedByDoor = true;
          this.doorBreakTimer += dt;
          this.doorBangCooldown -= dt;
          if (this.doorBangCooldown <= 0) {
            this.doorBangCooldown = 0.85;
            onDoorBang();
          }
          if (this.doorBreakTimer >= 1.8) {
            this.doorBreakTimer = 0;
            onDoorBreak(d);
          }
          break;
        }
      }
    }
    if (!blockedByDoor) this.doorBreakTimer = 0;

    if (!blockedByDoor && moveSpeed > 0.01) {
      const sdx = steerX - this.x;
      const sdz = steerZ - this.z;
      const sLen = Math.hypot(sdx, sdz);
      if (sLen > 0.08) {
        const nx = this.x + (sdx / sLen) * moveSpeed * dt;
        const nz = this.z + (sdz / sLen) * moveSpeed * dt;
        const [rx, rz] = resolveCircle(nx, nz, 0.36);
        this.x = rx;
        this.z = rz;

        const desiredYaw = Math.atan2(sdx, sdz);
        let diffYaw = desiredYaw - this.yaw;
        while (diffYaw > Math.PI) diffYaw -= Math.PI * 2;
        while (diffYaw < -Math.PI) diffYaw += Math.PI * 2;
        this.yaw += diffYaw * Math.min(1, dt * 8);

        this.walkPhase += dt * moveSpeed * 3.4;
        const halfStep = Math.floor(this.walkPhase / Math.PI);
        if (halfStep !== this.lastStepHalf) {
          this.lastStepHalf = halfStep;
          onStep(this.x, this.z);
        }
      }
    }

    return this.snapshot();
  }

  public snapshot(): MonsterSnapshot {
    return {
      state: this.state,
      x: this.x,
      z: this.z,
      yaw: this.yaw,
      walkPhase: this.walkPhase,
      dangerLevel: this.dangerLevel,
      staggered: this.state === 'staggered',
    };
  }
}
