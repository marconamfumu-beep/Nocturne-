import type { DifficultyId } from '../types/game';

export interface DifficultyConfig {
  id: DifficultyId;
  labelFr: string;
  labelEn: string;
  descFr: string;
  descEn: string;
  monsterPatrolSpeed: number;
  monsterChaseSpeed: number;
  monsterInvestigateSpeed: number;
  monsterVisionRange: number;
  monsterHearingMultiplier: number;
  monsterDamage: number;
  attackCooldown: number;
  chaseGiveUpSec: number;
  staggerDurationSec: number;
  batteryDrainPerSec: number;
  playerMaxHealth: number;
  startingAmmo: number;
  startingMedkits: number;
  startingBatteries: number;
  manualSavesAllowed: number; // -1 unlimited, or cap per chapter
}

export const DIFFICULTY_CONFIGS: Record<DifficultyId, DifficultyConfig> = {
  easy: {
    id: 'easy',
    labelFr: 'FACILE',
    labelEn: 'EASY',
    descFr: 'Patient 04 moins agressif, poursuites plus courtes et ressources abondantes.',
    descEn: 'Less aggressive Patient 04, shorter chases, and abundant supplies.',
    monsterPatrolSpeed: 1.32,
    monsterChaseSpeed: 2.18,
    monsterInvestigateSpeed: 1.65,
    monsterVisionRange: 11.5,
    monsterHearingMultiplier: 0.78,
    monsterDamage: 24,
    attackCooldown: 1.65,
    chaseGiveUpSec: 3.2,
    staggerDurationSec: 4.5,
    batteryDrainPerSec: 0.0055,
    playerMaxHealth: 120,
    startingAmmo: 16,
    startingMedkits: 2,
    startingBatteries: 2,
    manualSavesAllowed: -1,
  },
  normal: {
    id: 'normal',
    labelFr: 'NORMAL',
    labelEn: 'NORMAL',
    descFr: 'Expérience survival horror équilibrée, ressources limitées et IA complète.',
    descEn: 'Balanced survival horror experience, limited supplies, and full adaptive AI.',
    monsterPatrolSpeed: 1.52,
    monsterChaseSpeed: 2.52,
    monsterInvestigateSpeed: 1.95,
    monsterVisionRange: 14.5,
    monsterHearingMultiplier: 1.0,
    monsterDamage: 35,
    attackCooldown: 1.35,
    chaseGiveUpSec: 4.8,
    staggerDurationSec: 3.4,
    batteryDrainPerSec: 0.0085,
    playerMaxHealth: 100,
    startingAmmo: 8,
    startingMedkits: 1,
    startingBatteries: 1,
    manualSavesAllowed: -1,
  },
  nightmare: {
    id: 'nightmare',
    labelFr: 'CAUCHEMAR',
    labelEn: 'NIGHTMARE',
    descFr: 'Patient 04 impitoyable, ressources rares, poursuites intenses et points de sauvegarde limités.',
    descEn: 'Relentless Patient 04, scarce resources, intense chases, and restricted saves.',
    monsterPatrolSpeed: 1.78,
    monsterChaseSpeed: 2.86,
    monsterInvestigateSpeed: 2.28,
    monsterVisionRange: 17.5,
    monsterHearingMultiplier: 1.28,
    monsterDamage: 52,
    attackCooldown: 1.05,
    chaseGiveUpSec: 6.8,
    staggerDurationSec: 2.2,
    batteryDrainPerSec: 0.012,
    playerMaxHealth: 100,
    startingAmmo: 4,
    startingMedkits: 0,
    startingBatteries: 1,
    manualSavesAllowed: 2,
  },
};
