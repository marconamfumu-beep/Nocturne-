import type { DynamicTier, RenderProfileMode, RenderQualityConfig } from '../types/game';

export const TIER_CONFIGS: Record<DynamicTier, RenderQualityConfig> = {
  ultra: {
    tier: 'ultra',
    label: '8K CINEMATIC · GPU',
    pixelRatioCap: 2.0,
    shadowMapSize: 4096,
    shadowsEnabled: true,
    pcfShadows: true,
    hdrEnabled: true,
    bloomEnabled: true,
    bloomScale: 0.65,
    ssaoEnabled: true,
    mirrorReflections: true,
    sharpenEnabled: true,
    gradingEnabled: true,
    lensEffectsEnabled: true,
    volumetricsEnabled: true,
    puddleRipples: true,
    maxActivePointLights: 10,
    dustRatio: 1.0,
    gaussianEnabled: true,
  },
  high: {
    tier: 'high',
    label: '4K AAA · GPU',
    pixelRatioCap: 1.65,
    shadowMapSize: 2048,
    shadowsEnabled: true,
    pcfShadows: true,
    hdrEnabled: true,
    bloomEnabled: true,
    bloomScale: 0.5,
    ssaoEnabled: false,
    mirrorReflections: true,
    sharpenEnabled: true,
    gradingEnabled: true,
    lensEffectsEnabled: true,
    volumetricsEnabled: true,
    puddleRipples: true,
    maxActivePointLights: 10,
    dustRatio: 0.85,
    gaussianEnabled: true,
  },
  balanced: {
    tier: 'balanced',
    label: 'MOBILE OPTIMISÉ',
    // Tuned for iPhone X / Safari iOS 16 WebGL2 (>= 30 FPS without losing atmosphere)
    pixelRatioCap: 1.0,
    shadowMapSize: 512,
    shadowsEnabled: true,
    pcfShadows: false,
    hdrEnabled: false,
    bloomEnabled: true,
    bloomScale: 0.25,
    ssaoEnabled: false,
    mirrorReflections: false,
    sharpenEnabled: false,
    gradingEnabled: true,
    lensEffectsEnabled: false,
    volumetricsEnabled: false,
    puddleRipples: false,
    maxActivePointLights: 3,
    dustRatio: 0.35,
    gaussianEnabled: true,
  },
  performance: {
    tier: 'performance',
    label: 'LATENCE MIN.',
    pixelRatioCap: 1.0,
    shadowMapSize: 512,
    shadowsEnabled: false,
    pcfShadows: false,
    hdrEnabled: false,
    bloomEnabled: false,
    bloomScale: 0.2,
    ssaoEnabled: false,
    mirrorReflections: false,
    sharpenEnabled: false,
    gradingEnabled: false,
    lensEffectsEnabled: false,
    volumetricsEnabled: false,
    puddleRipples: false,
    maxActivePointLights: 2,
    dustRatio: 0.2,
    gaussianEnabled: true,
  },
};

export function detectSoftwareWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return false;
  }
}

export function detectTouchEnvironment(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    'ontouchstart' in window ||
    navigator.maxTouchPoints > 0 ||
    window.matchMedia('(pointer: coarse)').matches
  );
}

const TIER_ORDER: DynamicTier[] = ['performance', 'balanced', 'high', 'ultra'];

export class DynamicRenderProfiler {
  private mode: RenderProfileMode = 'auto';
  private activeTier: DynamicTier;
  private readonly isSoftwareGl: boolean;
  private readonly isTouch: boolean;

  private readonly samples = new Float32Array(45);
  private sampleIndex = 0;
  private sampleCount = 0;
  private evalAccumulator = 0;
  private cooldown = 0;

  public currentFps = 60;
  public currentFrameMs = 16.6;

  constructor(isSoftwareGl: boolean, isTouch: boolean) {
    this.isSoftwareGl = isSoftwareGl;
    this.isTouch = isTouch;
    if (isSoftwareGl || isTouch) {
      this.activeTier = 'balanced';
    } else {
      this.activeTier = 'high';
    }
  }

  public setMode(mode: RenderProfileMode): boolean {
    this.mode = mode;
    const prev = this.activeTier;
    if (this.isTouch && (mode === 'console_ultra' || mode === 'cinematic_8k' || mode === 'cinematic_4k')) {
      // Touch GPUs (especially older iPhones) cannot safely sustain desktop supersampling/shadow budgets.
      // Keep the selected preference, but use the stable mobile render tier.
      this.activeTier = 'balanced';
    } else if (mode === 'console_ultra' || mode === 'cinematic_8k') {
      this.activeTier = 'ultra';
    } else if (mode === 'cinematic_4k') {
      this.activeTier = 'high';
    } else if (mode === 'mobile_landscape') {
      this.activeTier = 'balanced';
    } else if (mode === 'performance') {
      this.activeTier = 'performance';
    } else if (mode === 'auto') {
      this.activeTier = this.isTouch ? 'balanced' : 'high';
      this.cooldown = 1.0;
    }
    return prev !== this.activeTier;
  }

  public getMode(): RenderProfileMode {
    return this.mode;
  }

  public getTier(): DynamicTier {
    return this.activeTier;
  }

  public getConfig(): RenderQualityConfig {
    return TIER_CONFIGS[this.activeTier];
  }

  public recordFrame(rawDtSeconds: number): boolean {
    const clampedMs = Math.min(Math.max(rawDtSeconds * 1000, 1), 250);
    this.samples[this.sampleIndex] = clampedMs;
    this.sampleIndex = (this.sampleIndex + 1) % this.samples.length;
    if (this.sampleCount < this.samples.length) this.sampleCount++;

    this.evalAccumulator += rawDtSeconds;
    if (this.cooldown > 0) this.cooldown = Math.max(0, this.cooldown - rawDtSeconds);

    if (this.evalAccumulator < 0.75) return false;
    this.evalAccumulator = 0;

    let sum = 0;
    for (let i = 0; i < this.sampleCount; i++) {
      sum += this.samples[i];
    }
    const avgMs = sum / Math.max(1, this.sampleCount);
    this.currentFrameMs = Math.round(avgMs * 10) / 10;
    this.currentFps = Math.min(120, Math.max(1, Math.round(1000 / avgMs)));

    if (this.mode !== 'auto' || this.isSoftwareGl || this.cooldown > 0 || this.sampleCount < 20) {
      return false;
    }

    const idx = TIER_ORDER.indexOf(this.activeTier);
    // Keep balanced tier stable down to ~29 FPS on mobile so shadows/bloom don't flicker
    const downgradeThreshold = this.isTouch ? 34.5 : 22.0;
    const upgradeThreshold = this.isTouch ? 18.0 : 12.0;

    if (avgMs > downgradeThreshold && idx > 0) {
      this.activeTier = TIER_ORDER[idx - 1];
      this.cooldown = 3.0;
      return true;
    }

    if (avgMs < upgradeThreshold && idx < TIER_ORDER.length - 1) {
      // Never auto-upgrade touch devices above 'balanced' to protect iPhone X RAM & fillrate
      if (this.isTouch && idx >= TIER_ORDER.indexOf('balanced')) return false;
      this.activeTier = TIER_ORDER[idx + 1];
      this.cooldown = 4.0;
      return true;
    }

    return false;
  }
}
