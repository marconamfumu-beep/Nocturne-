import {
  Camera,
  Color4,
  ColorCurves,
  DefaultRenderingPipeline,
  Effect,
  ImageProcessingConfiguration,
  PostProcess,
  Scalar,
  Scene,
  SSAO2RenderingPipeline,
  Texture,
} from '@babylonjs/core';
import type { RenderQualityConfig } from '../types/game';

let dangerShaderRegistered = false;
function ensureDangerShader(): void {
  if (dangerShaderRegistered) return;
  dangerShaderRegistered = true;

  Effect.ShadersStore['dangerTrackingFragmentShader'] = `
    precision highp float;
    varying vec2 vUV;
    uniform sampler2D textureSampler;
    uniform float uDanger;
    uniform float uPulse;

    void main(void) {
      vec4 baseColor = texture2D(textureSampler, vUV);
      if (uDanger <= 0.004) {
        gl_FragColor = baseColor;
        return;
      }

      // Luminance-preserving desaturation as the monster closes in
      float luma = dot(baseColor.rgb, vec3(0.2126, 0.7152, 0.0722));
      float desatAmount = clamp(uDanger * 0.84, 0.0, 0.86);
      vec3 desaturated = mix(baseColor.rgb, vec3(luma), desatAmount);
      desaturated *= mix(vec3(1.0), vec3(0.95, 0.93, 0.98), uDanger * 0.45);

      // Dynamic pulsing radial vignette tightening peripheral vision
      vec2 centered = (vUV - 0.5) * vec2(1.16, 1.0);
      float dist = length(centered);
      float innerRadius = mix(0.68, 0.27, uDanger) - uPulse * 0.045 * uDanger;
      float outerRadius = mix(0.98, 0.72, uDanger);
      float vignette = smoothstep(innerRadius, outerRadius, dist);

      // Dark claustrophobic edge with arterial crimson tint when hunted
      vec3 edgeTint = mix(
        vec3(0.014, 0.018, 0.026),
        vec3(0.24, 0.012, 0.018),
        clamp(uDanger * (0.62 + 0.38 * uPulse), 0.0, 1.0)
      );
      float vignetteStrength = vignette * (0.26 + uDanger * 0.7);
      vec3 finalColor = mix(desaturated, edgeTint, vignetteStrength);

      gl_FragColor = vec4(finalColor, baseColor.a);
    }
  `;
}

export class BabylonCinematicPipeline {
  private defaultPipeline: DefaultRenderingPipeline | null = null;
  private ssaoPipeline: SSAO2RenderingPipeline | null = null;
  private dangerPost: PostProcess | null = null;
  private currentHdr = false;
  private dangerLevel = 0;
  private dangerPulse = 0;
  private readonly scene: Scene;
  private readonly camera: Camera;
  private readonly isSoftwareGl: boolean;

  constructor(
    scene: Scene,
    camera: Camera,
    isSoftwareGl: boolean,
    initialConfig: RenderQualityConfig,
  ) {
    this.scene = scene;
    this.camera = camera;
    this.isSoftwareGl = isSoftwareGl;

    // Consistent ACES Filmic tone mapping on all devices
    scene.imageProcessingConfiguration.toneMappingEnabled = true;
    scene.imageProcessingConfiguration.toneMappingType =
      ImageProcessingConfiguration.TONEMAPPING_ACES;
    scene.imageProcessingConfiguration.exposure = 1.12;
    scene.imageProcessingConfiguration.contrast = 1.24;

    if (isSoftwareGl) return;

    this.buildDefaultPipeline(initialConfig.hdrEnabled);
    this.applyQuality(initialConfig);
  }

  private buildDangerPostProcess(): void {
    if (this.dangerPost) {
      this.dangerPost.dispose(this.camera);
      this.dangerPost = null;
    }

    ensureDangerShader();
    const pp = new PostProcess(
      'dangerTracking',
      'dangerTracking',
      ['uDanger', 'uPulse'],
      null,
      1.0,
      this.camera,
      Texture.BILINEAR_SAMPLINGMODE,
      this.scene.getEngine(),
    );
    pp.autoClear = false;
    pp.onApply = (effect) => {
      effect.setFloat('uDanger', this.dangerLevel);
      effect.setFloat('uPulse', this.dangerPulse);
    };
    this.dangerPost = pp;
  }

  private buildDefaultPipeline(hdr: boolean): void {
    if (this.dangerPost) {
      this.dangerPost.dispose(this.camera);
      this.dangerPost = null;
    }
    if (this.defaultPipeline) {
      this.defaultPipeline.dispose();
      this.defaultPipeline = null;
    }

    this.currentHdr = hdr;
    const pipeline = new DefaultRenderingPipeline('cinematic', hdr, this.scene, [this.camera]);
    pipeline.fxaaEnabled = true;
    pipeline.samples = 1;

    // Bloom
    pipeline.bloomEnabled = true;
    pipeline.bloomThreshold = hdr ? 0.76 : 0.72;
    pipeline.bloomWeight = hdr ? 0.28 : 0.24;
    pipeline.bloomKernel = hdr ? 48 : 24;
    pipeline.bloomScale = 0.25;

    // Sharpen
    pipeline.sharpenEnabled = false;
    pipeline.sharpen.edgeAmount = 0.28;
    pipeline.sharpen.colorAmount = 1.0;

    // Lens effects (disabled on mobile LDR tier for fillrate)
    pipeline.chromaticAberrationEnabled = false;
    pipeline.chromaticAberration.aberrationAmount = 6;
    pipeline.chromaticAberration.radialIntensity = 0.42;

    pipeline.grainEnabled = false;
    pipeline.grain.intensity = 5.5;
    pipeline.grain.animated = true;

    // Image Processing & Vignette + Split-Tone Color Curves
    pipeline.imageProcessingEnabled = true;
    pipeline.imageProcessing.toneMappingEnabled = true;
    pipeline.imageProcessing.toneMappingType = ImageProcessingConfiguration.TONEMAPPING_ACES;
    pipeline.imageProcessing.exposure = 1.12;
    pipeline.imageProcessing.contrast = 1.24;
    pipeline.imageProcessing.vignetteEnabled = true;
    pipeline.imageProcessing.vignetteWeight = 1.55;
    pipeline.imageProcessing.vignetteStretch = 0.35;
    pipeline.imageProcessing.vignetteColor = new Color4(0.01, 0.02, 0.04, 0);

    const curves = new ColorCurves();
    curves.shadowsHue = 212;
    curves.shadowsDensity = 24;
    curves.shadowsSaturation = 18;
    curves.highlightsHue = 36;
    curves.highlightsDensity = 10;
    curves.highlightsSaturation = 8;
    pipeline.imageProcessing.colorCurvesEnabled = true;
    pipeline.imageProcessing.colorCurves = curves;

    this.defaultPipeline = pipeline;
    this.buildDangerPostProcess();
  }

  public updateDanger(dangerLevel: number, elapsedSeconds: number): void {
    this.dangerLevel = Scalar.Clamp(dangerLevel, 0, 1);
    const pulseFreq = 4.2 + this.dangerLevel * 7.5;
    this.dangerPulse = 0.5 + 0.5 * Math.sin(elapsedSeconds * pulseFreq);
  }

  public applyQuality(config: RenderQualityConfig): void {
    if (this.isSoftwareGl) return;

    if (!this.defaultPipeline || this.currentHdr !== config.hdrEnabled) {
      this.buildDefaultPipeline(config.hdrEnabled);
    }

    const p = this.defaultPipeline;
    if (!p) return;

    p.fxaaEnabled = config.tier !== 'performance';
    p.bloomEnabled = config.bloomEnabled;
    p.bloomScale = config.bloomScale;
    p.bloomKernel = config.hdrEnabled ? 48 : 24;
    p.sharpenEnabled = config.sharpenEnabled;
    p.chromaticAberrationEnabled = config.lensEffectsEnabled;
    p.grainEnabled = config.lensEffectsEnabled;
    p.imageProcessing.vignetteEnabled = config.gradingEnabled;
    p.imageProcessing.colorCurvesEnabled = config.gradingEnabled;

    if (config.ssaoEnabled && !this.ssaoPipeline) {
      try {
        const ssao = new SSAO2RenderingPipeline(
          'ssao2',
          this.scene,
          { ssaoRatio: 0.5, blurRatio: 0.5 },
          [this.camera],
          false,
        );
        ssao.radius = 1.45;
        ssao.totalStrength = 0.92;
        ssao.expensiveBlur = false;
        ssao.samples = 16;
        ssao.maxZ = 36;
        this.ssaoPipeline = ssao;
      } catch {
        this.ssaoPipeline = null;
      }
    } else if (!config.ssaoEnabled && this.ssaoPipeline) {
      this.ssaoPipeline.dispose();
      this.ssaoPipeline = null;
    }
  }

  public dispose(): void {
    if (this.dangerPost) {
      this.dangerPost.dispose(this.camera);
      this.dangerPost = null;
    }
    if (this.ssaoPipeline) {
      this.ssaoPipeline.dispose();
      this.ssaoPipeline = null;
    }
    if (this.defaultPipeline) {
      this.defaultPipeline.dispose();
      this.defaultPipeline = null;
    }
  }
}
