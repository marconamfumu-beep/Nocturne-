export class HospitalAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private ambientStarted = false;
  private muted = false;
  private dripTimer = 0;
  private heartbeatTimer = 0;

  public unlock(): void {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return;
    }

    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;

      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : 0.75;
      this.masterGain.connect(this.ctx.destination);
      this.startAmbience();
    } catch {
      // Audio unavailable
    }
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(muted ? 0 : 0.75, this.ctx.currentTime, 0.04);
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  private startAmbience(): void {
    if (!this.ctx || !this.masterGain || this.ambientStarted) return;
    this.ambientStarted = true;
    const now = this.ctx.currentTime;

    const subOsc = this.ctx.createOscillator();
    const harmOsc = this.ctx.createOscillator();
    const droneGain = this.ctx.createGain();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(47, now);
    harmOsc.type = 'triangle';
    harmOsc.frequency.setValueAtTime(94, now);
    droneGain.gain.setValueAtTime(0.055, now);

    const lowpass = this.ctx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.setValueAtTime(140, now);

    subOsc.connect(lowpass);
    harmOsc.connect(lowpass);
    lowpass.connect(droneGain);
    droneGain.connect(this.masterGain);
    subOsc.start();
    harmOsc.start();

    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    let lastOut = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      data[i] = (lastOut + 0.03 * white) / 1.03;
      lastOut = data[i];
    }

    const noiseSrc = this.ctx.createBufferSource();
    noiseSrc.buffer = noiseBuffer;
    noiseSrc.loop = true;

    const airFilter = this.ctx.createBiquadFilter();
    airFilter.type = 'bandpass';
    airFilter.frequency.setValueAtTime(210, now);
    airFilter.Q.setValueAtTime(0.9, now);

    const airGain = this.ctx.createGain();
    airGain.gain.setValueAtTime(0.11, now);

    noiseSrc.connect(airFilter);
    airFilter.connect(airGain);
    airGain.connect(this.masterGain);
    noiseSrc.start();
  }

  public update(dt: number, dangerLevel = 0): void {
    if (!this.ctx || this.muted || this.ctx.state !== 'running') return;
    this.dripTimer -= dt;
    if (this.dripTimer <= 0) {
      this.dripTimer = 2.6 + Math.random() * 4.2;
      this.playWaterDrip();
    }

    if (dangerLevel > 0.15) {
      this.heartbeatTimer -= dt;
      if (this.heartbeatTimer <= 0) {
        this.heartbeatTimer = Math.max(0.38, 1.05 - dangerLevel * 0.62);
        this.playHeartbeat(dangerLevel);
      }
    } else {
      this.heartbeatTimer = 0;
    }
  }

  private playHeartbeat(intensity: number): void {
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    const vol = Math.min(0.22, 0.05 + intensity * 0.16);

    [0, 0.14].forEach((offset, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(i === 0 ? 58 : 48, t + offset);
      osc.frequency.exponentialRampToValueAtTime(28, t + offset + 0.11);
      g.gain.setValueAtTime(0.001, t + offset);
      g.gain.linearRampToValueAtTime(i === 0 ? vol : vol * 0.72, t + offset + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t + offset + 0.13);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(t + offset);
      osc.stop(t + offset + 0.15);
    });
  }

  private playWaterDrip(): void {
    if (!this.ctx || !this.masterGain) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const panner = this.ctx.createStereoPanner();

    const baseFreq = 780 + Math.random() * 480;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.65, t + 0.065);

    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(0.028, t + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);

    panner.pan.setValueAtTime((Math.random() - 0.5) * 1.4, t);

    osc.connect(gain);
    gain.connect(panner);
    panner.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.16);
  }

  public playFootstep(sprinting: boolean, crouching: boolean, overPuddle: boolean): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const thudGain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(sprinting ? 115 : crouching ? 68 : 88, t);
    osc.frequency.exponentialRampToValueAtTime(36, t + 0.085);

    const vol = crouching ? 0.035 : sprinting ? 0.13 : 0.075;
    thudGain.gain.setValueAtTime(vol, t);
    thudGain.gain.exponentialRampToValueAtTime(0.001, t + 0.095);

    osc.connect(thudGain);
    thudGain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.11);

    if (overPuddle) {
      const len = Math.floor(this.ctx.sampleRate * 0.09);
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const ch = buf.getChannelData(0);
      for (let i = 0; i < len; i++) {
        ch[i] = (Math.random() * 2 - 1) * Math.exp(-i / (len * 0.35));
      }
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(1900, t);
      bp.Q.setValueAtTime(1.4, t);

      const g = this.ctx.createGain();
      g.gain.setValueAtTime(crouching ? 0.03 : sprinting ? 0.11 : 0.06, t);
      src.connect(bp);
      bp.connect(g);
      g.connect(this.masterGain);
      src.start(t);
    }
  }

  public playMonsterStep(proximity: number): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    if (proximity <= 0.02) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(76, t);
    osc.frequency.exponentialRampToValueAtTime(28, t + 0.15);

    const vol = Math.min(0.24, proximity * 0.22);
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(vol, t + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.17);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.18);
  }

  public playMonsterAlert(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc1.type = 'sawtooth';
    osc2.type = 'square';
    osc1.frequency.setValueAtTime(210, t);
    osc1.frequency.exponentialRampToValueAtTime(520, t + 0.18);
    osc1.frequency.exponentialRampToValueAtTime(145, t + 0.72);

    osc2.frequency.setValueAtTime(223, t);
    osc2.frequency.exponentialRampToValueAtTime(542, t + 0.18);
    osc2.frequency.exponentialRampToValueAtTime(138, t + 0.72);

    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(850, t);
    bp.Q.setValueAtTime(1.8, t);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.18, t + 0.04);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.78);

    osc1.connect(bp);
    osc2.connect(bp);
    bp.connect(g);
    g.connect(this.masterGain);
    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 0.8);
    osc2.stop(t + 0.8);
  }

  public playCaughtSting(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    [92, 98, 138, 295].forEach((f) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, t);
      osc.frequency.exponentialRampToValueAtTime(f * 0.45, t + 1.1);
      g.gain.setValueAtTime(0.11, t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.15);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 1.2);
    });
  }

  public playKeyPickup(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    [1320, 1760, 2110].forEach((f, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, t + i * 0.04);
      g.gain.setValueAtTime(0.06, t + i * 0.04);
      g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.04 + 0.22);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(t + i * 0.04);
      osc.stop(t + i * 0.04 + 0.24);
    });
  }

  public playDoorUnlock(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const click = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    click.type = 'square';
    click.frequency.setValueAtTime(620, t);
    click.frequency.exponentialRampToValueAtTime(190, t + 0.08);
    g.gain.setValueAtTime(0.11, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
    click.connect(g);
    g.connect(this.masterGain);
    click.start(t);
    click.stop(t + 0.11);

    const creak = this.ctx.createOscillator();
    const cg = this.ctx.createGain();
    creak.type = 'sawtooth';
    creak.frequency.setValueAtTime(145, t + 0.09);
    creak.frequency.linearRampToValueAtTime(215, t + 0.42);
    cg.gain.setValueAtTime(0.001, t + 0.09);
    cg.gain.linearRampToValueAtTime(0.045, t + 0.16);
    cg.gain.exponentialRampToValueAtTime(0.0001, t + 0.48);
    creak.connect(cg);
    cg.connect(this.masterGain);
    creak.start(t + 0.09);
    creak.stop(t + 0.5);
  }

  public playDoorLocked(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    [0, 0.09].forEach((offset) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(180, t + offset);
      osc.frequency.exponentialRampToValueAtTime(75, t + offset + 0.05);
      g.gain.setValueAtTime(0.09, t + offset);
      g.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.06);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(t + offset);
      osc.stop(t + offset + 0.07);
    });
  }

  public playDoorBang(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(125, t);
    osc.frequency.exponentialRampToValueAtTime(34, t + 0.22);
    g.gain.setValueAtTime(0.24, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.27);
  }

  public playBottleThrow(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.exponentialRampToValueAtTime(140, t + 0.12);
    g.gain.setValueAtTime(0.06, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.15);
  }

  public playBottleBreak(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;

    // Glass shatter noise burst
    const len = Math.floor(this.ctx.sampleRate * 0.28);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      ch[i] = (Math.random() * 2 - 1) * Math.exp(-i / (len * 0.24));
    }
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const hp = this.ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(2200, t);
    const ng = this.ctx.createGain();
    ng.gain.setValueAtTime(0.24, t);
    src.connect(hp);
    hp.connect(ng);
    ng.connect(this.masterGain);
    src.start(t);

    // Crystalline glass shard pings
    [2450, 3180, 4120, 2890, 3650].forEach((freq, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      const delay = i * 0.028;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + delay);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.72, t + delay + 0.11);
      g.gain.setValueAtTime(0.055, t + delay);
      g.gain.exponentialRampToValueAtTime(0.0001, t + delay + 0.12);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(t + delay);
      osc.stop(t + delay + 0.13);
    });
  }

  public playHideoutToggle(kind: 'locker' | 'bed', entering: boolean): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    if (kind === 'locker') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(entering ? 240 : 310, t);
      osc.frequency.exponentialRampToValueAtTime(entering ? 95 : 140, t + 0.14);
      g.gain.setValueAtTime(0.11, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(110, t);
      osc.frequency.exponentialRampToValueAtTime(52, t + 0.12);
      g.gain.setValueAtTime(0.08, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
    }
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.18);
  }

  public playFlashlightClick(on: boolean): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(on ? 1450 : 980, t);
    osc.frequency.exponentialRampToValueAtTime(on ? 2400 : 520, t + 0.025);
    gain.gain.setValueAtTime(0.065, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.032);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.04);
  }

  public playCluePickup(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const notes = [440, 554.37, 659.25];
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + idx * 0.055);
      gain.gain.setValueAtTime(0.0001, t + idx * 0.055);
      gain.gain.linearRampToValueAtTime(0.075, t + idx * 0.055 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + idx * 0.055 + 0.42);
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + idx * 0.055);
      osc.stop(t + idx * 0.055 + 0.45);
    });
  }

  public playAnomalySting(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc1.type = 'sawtooth';
    osc2.type = 'sine';
    osc1.frequency.setValueAtTime(62, t);
    osc1.frequency.exponentialRampToValueAtTime(38, t + 1.4);
    osc2.frequency.setValueAtTime(65.5, t);
    osc2.frequency.exponentialRampToValueAtTime(41, t + 1.4);

    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(320, t);
    lp.frequency.exponentialRampToValueAtTime(90, t + 1.4);

    g.gain.setValueAtTime(0.001, t);
    g.gain.linearRampToValueAtTime(0.14, t + 0.08);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.45);

    osc1.connect(lp);
    osc2.connect(lp);
    lp.connect(g);
    g.connect(this.masterGain);
    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 1.5);
    osc2.stop(t + 1.5);
  }

  public playFlickerBuzz(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, t);
    gain.gain.setValueAtTime(0.018, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.08);
  }

  public playPowerRestore(): void {
    if (!this.ctx || !this.masterGain || this.muted || this.ctx.state !== 'running') return;
    const t = this.ctx.currentTime;

    const clunk = this.ctx.createOscillator();
    const clunkGain = this.ctx.createGain();
    clunk.type = 'triangle';
    clunk.frequency.setValueAtTime(160, t);
    clunk.frequency.exponentialRampToValueAtTime(42, t + 0.14);
    clunkGain.gain.setValueAtTime(0.18, t);
    clunkGain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    clunk.connect(clunkGain);
    clunkGain.connect(this.masterGain);
    clunk.start(t);
    clunk.stop(t + 0.2);

    const rise = this.ctx.createOscillator();
    const riseGain = this.ctx.createGain();
    rise.type = 'sine';
    rise.frequency.setValueAtTime(110, t + 0.08);
    rise.frequency.exponentialRampToValueAtTime(330, t + 0.85);
    riseGain.gain.setValueAtTime(0.001, t + 0.08);
    riseGain.gain.linearRampToValueAtTime(0.09, t + 0.35);
    riseGain.gain.exponentialRampToValueAtTime(0.001, t + 1.15);
    rise.connect(riseGain);
    riseGain.connect(this.masterGain);
    rise.start(t + 0.08);
    rise.stop(t + 1.2);
  }

  public dispose(): void {
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
      this.masterGain = null;
    }
  }
}
