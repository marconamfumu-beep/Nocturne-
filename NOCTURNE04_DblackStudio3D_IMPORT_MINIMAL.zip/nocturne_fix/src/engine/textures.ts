import {
  DynamicTexture,
  Engine,
  RawCubeTexture,
  Scene,
  Texture,
} from '@babylonjs/core';

export interface BabylonPbrTextureSet {
  albedo: DynamicTexture;
  bump: DynamicTexture;
  metallic: DynamicTexture; // R=AO, G=Roughness, B=Metalness
}

export interface HospitalTextureLibrary {
  envCube: RawCubeTexture;
  floor: BabylonPbrTextureSet;
  wall: BabylonPbrTextureSet;
  ceiling: BabylonPbrTextureSet;
  brushedMetal: BabylonPbrTextureSet;
  concrete: BabylonPbrTextureSet;
  wood: BabylonPbrTextureSet;
  doorLaminate: BabylonPbrTextureSet;
  buildingFacade: BabylonPbrTextureSet;
  exitSign: DynamicTexture;
  sectorSign: DynamicTexture;
  directionalSign: DynamicTexture;
  plaqueReception: DynamicTexture;
  plaqueObservation: DynamicTexture;
  plaqueSurgery: DynamicTexture;
  plaqueGenerator: DynamicTexture;
  xrayScreen: DynamicTexture;
  monitorScreen: DynamicTexture;
  updateMonitorScreen: (elapsed: number, powerRestored: boolean, cluesCollected: number) => void;
  contactShadow: DynamicTexture;
  dustParticle: DynamicTexture;
  dispose: () => void;
}

function hash2(x: number, y: number): number {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
  return s - Math.floor(s);
}

function valueNoise(x: number, y: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const a = hash2(ix, iy);
  const b = hash2(ix + 1, iy);
  const c = hash2(ix, iy + 1);
  const d = hash2(ix + 1, iy + 1);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}

function fbm(x: number, y: number, octaves = 4): number {
  let v = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < octaves; i++) {
    v += amp * valueNoise(x * freq, y * freq);
    freq *= 2.03;
    amp *= 0.5;
  }
  return v;
}

function configureTexture(
  tex: DynamicTexture,
  uScale: number,
  vScale: number,
  aniso: number,
  isColor: boolean,
): DynamicTexture {
  tex.wrapU = Texture.WRAP_ADDRESSMODE;
  tex.wrapV = Texture.WRAP_ADDRESSMODE;
  tex.uScale = uScale;
  tex.vScale = vScale;
  tex.anisotropicFilteringLevel = aniso;
  tex.gammaSpace = isColor;
  tex.update(false);
  return tex;
}

function buildNormalTextureFromHeight(
  name: string,
  scene: Scene,
  height: Float32Array,
  size: number,
  strength: number,
  uScale: number,
  vScale: number,
  aniso: number,
): DynamicTexture {
  const tex = new DynamicTexture(name, { width: size, height: size }, scene, true);
  const ctx = tex.getContext() as unknown as CanvasRenderingContext2D;
  const img = ctx.createImageData(size, size);
  const data = img.data;

  for (let y = 0; y < size; y++) {
    const ym = (y - 1 + size) % size;
    const yp = (y + 1) % size;
    for (let x = 0; x < size; x++) {
      const xm = (x - 1 + size) % size;
      const xp = (x + 1) % size;

      const tl = height[ym * size + xm];
      const t = height[ym * size + x];
      const tr = height[ym * size + xp];
      const l = height[y * size + xm];
      const r = height[y * size + xp];
      const bl = height[yp * size + xm];
      const b = height[yp * size + x];
      const br = height[yp * size + xp];

      const dx = (tr + 2 * r + br - (tl + 2 * l + bl)) * strength;
      const dy = (bl + 2 * b + br - (tl + 2 * t + tr)) * strength;
      const dz = 1.0;
      const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

      const idx = (y * size + x) * 4;
      data[idx] = Math.round(((-dx / len) * 0.5 + 0.5) * 255);
      data[idx + 1] = Math.round(((-dy / len) * 0.5 + 0.5) * 255);
      data[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);
  return configureTexture(tex, uScale, vScale, aniso, false);
}

function createFloorSet(scene: Scene, size: number, aniso: number, octaves: number): BabylonPbrTextureSet {
  const albedo = new DynamicTexture('floorAlbedo', { width: size, height: size }, scene, true);
  const metallic = new DynamicTexture('floorMetallic', { width: size, height: size }, scene, true);
  const aCtx = albedo.getContext() as unknown as CanvasRenderingContext2D;
  const mCtx = metallic.getContext() as unknown as CanvasRenderingContext2D;
  const aImg = aCtx.createImageData(size, size);
  const mImg = mCtx.createImageData(size, size);
  const height = new Float32Array(size * size);

  const tiles = 4;
  const tilePx = size / tiles;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const tx = Math.floor(x / tilePx);
      const ty = Math.floor(y / tilePx);
      const lx = x % tilePx;
      const ly = y % tilePx;
      const groutDist = Math.min(lx, tilePx - 1 - lx, ly, tilePx - 1 - ly);
      const isGrout = groutDist < Math.max(2.0, size * 0.006);
      const bevel = Math.min(1, groutDist / Math.max(4.0, size * 0.015));

      const tileSeed = hash2(tx * 13.7, ty * 29.3);
      const nMacro = fbm((x / size) * 8.0, (y / size) * 8.0, octaves);
      const nMicro = fbm((x / size) * 52.0, (y / size) * 52.0, Math.max(2, octaves - 1));
      const speck = hash2(x * 0.73, y * 0.91);
      const darkChip = hash2(x * 1.41, y * 0.67);
      const damp = Math.max(0, (fbm((x / size) * 3.5 + 5.1, (y / size) * 3.5 + 1.9, 3) - 0.5) * 2.25);

      let r = 56 + tileSeed * 12 + nMacro * 18 + (speck > 0.945 ? 28 : 0) - (darkChip > 0.94 ? 14 : 0) - damp * 18;
      let g = 66 + tileSeed * 12 + nMacro * 19 + (speck > 0.945 ? 28 : 0) - (darkChip > 0.94 ? 14 : 0) - damp * 14;
      let b = 74 + tileSeed * 13 + nMacro * 20 + (speck > 0.945 ? 30 : 0) - (darkChip > 0.94 ? 14 : 0) - damp * 10;

      let rough = 0.36 + nMicro * 0.24 - damp * 0.28;
      let ao = (0.96 - damp * 0.08) * (0.82 + 0.18 * bevel);
      let h = 0.54 + nMicro * 0.14 + (tileSeed - 0.5) * 0.05 + bevel * 0.08;

      if (isGrout) {
        r *= 0.42;
        g *= 0.44;
        b *= 0.46;
        rough = 0.92;
        ao = 0.4;
        h = 0.14;
      }

      const scuff = Math.sin((x + y * 0.35) * 0.09 + nMacro * 7.0);
      if (!isGrout && scuff > 0.962) {
        r -= 10;
        g -= 10;
        b -= 10;
        rough = Math.min(0.88, rough + 0.22);
      }

      const idx = (y * size + x) * 4;
      aImg.data[idx] = Math.max(0, Math.min(255, r));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, g));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, b));
      aImg.data[idx + 3] = 255;

      mImg.data[idx] = Math.round(ao * 255);
      mImg.data[idx + 1] = Math.max(18, Math.min(248, Math.round(rough * 255)));
      mImg.data[idx + 2] = 16;
      mImg.data[idx + 3] = 255;

      height[y * size + x] = h;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return {
    albedo: configureTexture(albedo, 4, 16, aniso, true),
    metallic: configureTexture(metallic, 4, 16, aniso, false),
    bump: buildNormalTextureFromHeight('floorBump', scene, height, size, 3.1, 4, 16, aniso),
  };
}

function createWallSet(scene: Scene, size: number, aniso: number, octaves: number): BabylonPbrTextureSet {
  const albedo = new DynamicTexture('wallAlbedo', { width: size, height: size }, scene, true);
  const metallic = new DynamicTexture('wallMetallic', { width: size, height: size }, scene, true);
  const aCtx = albedo.getContext() as unknown as CanvasRenderingContext2D;
  const mCtx = metallic.getContext() as unknown as CanvasRenderingContext2D;
  const aImg = aCtx.createImageData(size, size);
  const mImg = mCtx.createImageData(size, size);
  const height = new Float32Array(size * size);
  const dadoSplit = Math.floor(size * 0.56);

  for (let y = 0; y < size; y++) {
    const isLowerTile = y >= dadoSplit;
    const isChairRail = Math.abs(y - dadoSplit) < Math.max(3, size * 0.011);

    for (let x = 0; x < size; x++) {
      const nMacro = fbm((x / size) * 5.8, (y / size) * 5.8, octaves);
      const nFine = fbm((x / size) * 38.0, (y / size) * 38.0, Math.max(2, octaves - 1));
      const streak = fbm((x / size) * 20.0, (y / size) * 2.4, 3);

      let r = 92;
      let g = 104;
      let b = 106;
      let rough = 0.78;
      let ao = 0.94;
      let metal = 0.04;
      let h = 0.5;

      if (isChairRail) {
        r = 48;
        g = 55;
        b = 62;
        rough = 0.36;
        ao = 0.78;
        metal = 0.38;
        h = 0.95;
      } else if (isLowerTile) {
        const tileW = size / 8;
        const tileH = size / 14;
        const row = Math.floor(y / tileH);
        const offset = (row % 2) * (tileW * 0.5);
        const lx = (x + offset) % tileW;
        const ly = y % tileH;
        const groutDist = Math.min(lx, tileW - lx, ly, tileH - ly);
        const grout = groutDist < Math.max(1.5, size * 0.0045);
        const grime = Math.max(0, streak - 0.52) * 1.45;
        const crack = nFine > 0.79 ? 0.16 : 0;

        r = 68 + nMacro * 15 - grime * 28 - crack * 24;
        g = 88 + nMacro * 17 - grime * 26 - crack * 22;
        b = 90 + nMacro * 16 - grime * 24 - crack * 20;
        rough = 0.2 + nFine * 0.16 + grime * 0.48 + crack;
        h = 0.7 + nFine * 0.04 - crack * 0.25;

        if (grout) {
          r *= 0.42;
          g *= 0.44;
          b *= 0.46;
          rough = 0.94;
          ao = 0.48;
          h = 0.22;
        }
      } else {
        const peelMask = fbm((x / size) * 9.5 + 3.1, (y / size) * 9.5 + 7.4, octaves);
        const isPeeled = peelMask > 0.66;
        const isPeelLip = Math.abs(peelMask - 0.66) < 0.025;
        const waterStain = Math.max(0, (streak - 0.49) * 1.65) * (1 - y / dadoSplit);

        if (isPeeled) {
          r = 56 + nFine * 20;
          g = 60 + nFine * 18;
          b = 64 + nFine * 18;
          rough = 0.94;
          ao = 0.68;
          h = 0.32 + nFine * 0.14;
        } else {
          r = 98 + nMacro * 22 - waterStain * 36 + (isPeelLip ? 16 : 0);
          g = 106 + nMacro * 22 - waterStain * 33 + (isPeelLip ? 16 : 0);
          b = 110 + nMacro * 20 - waterStain * 29 + (isPeelLip ? 16 : 0);
          rough = 0.7 + nFine * 0.18;
          ao = 0.95 - waterStain * 0.16;
          h = (isPeelLip ? 0.74 : 0.63) + nFine * 0.08;
        }
      }

      const idx = (y * size + x) * 4;
      aImg.data[idx] = Math.max(0, Math.min(255, r));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, g));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, b));
      aImg.data[idx + 3] = 255;

      mImg.data[idx] = Math.round(ao * 255);
      mImg.data[idx + 1] = Math.max(18, Math.min(248, Math.round(rough * 255)));
      mImg.data[idx + 2] = Math.round(metal * 255);
      mImg.data[idx + 3] = 255;

      height[y * size + x] = h;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return {
    albedo: configureTexture(albedo, 10, 1, aniso, true),
    metallic: configureTexture(metallic, 10, 1, aniso, false),
    bump: buildNormalTextureFromHeight('wallBump', scene, height, size, 2.8, 10, 1, aniso),
  };
}

function createCeilingSet(scene: Scene, size: number, aniso: number): BabylonPbrTextureSet {
  const half = Math.max(256, Math.floor(size * 0.5));
  const albedo = new DynamicTexture('ceilAlbedo', { width: half, height: half }, scene, true);
  const metallic = new DynamicTexture('ceilMetallic', { width: half, height: half }, scene, true);
  const aCtx = albedo.getContext() as unknown as CanvasRenderingContext2D;
  const mCtx = metallic.getContext() as unknown as CanvasRenderingContext2D;
  const aImg = aCtx.createImageData(half, half);
  const mImg = mCtx.createImageData(half, half);
  const height = new Float32Array(half * half);
  const grid = half / 4;

  for (let y = 0; y < half; y++) {
    for (let x = 0; x < half; x++) {
      const lx = x % grid;
      const ly = y % grid;
      const isFrame = Math.min(lx, grid - lx, ly, grid - ly) < Math.max(2.0, half * 0.01);
      const n = fbm((x / half) * 14, (y / half) * 14, 3);
      const stain = Math.max(0, fbm((x / half) * 4 + 2.1, (y / half) * 4 + 6.7, 3) - 0.58) * 2.1;
      const speckle = hash2(x * 1.1, y * 1.3);

      let r = 48 + n * 16 - (speckle > 0.72 ? 9 : 0) - stain * 18;
      let g = 53 + n * 17 - (speckle > 0.72 ? 9 : 0) - stain * 18;
      let b = 59 + n * 18 - (speckle > 0.72 ? 9 : 0) - stain * 20;
      let rough = 0.88;
      let ao = 0.92 - stain * 0.14;
      let metal = 0.05;
      let h = 0.5 + (speckle > 0.72 ? -0.12 : 0.04);

      if (isFrame) {
        r = 72;
        g = 78;
        b = 85;
        rough = 0.36;
        ao = 0.82;
        metal = 0.55;
        h = 0.88;
      }

      const idx = (y * half + x) * 4;
      aImg.data[idx] = Math.max(0, Math.min(255, r));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, g));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, b));
      aImg.data[idx + 3] = 255;

      mImg.data[idx] = Math.round(ao * 255);
      mImg.data[idx + 1] = Math.round(rough * 255);
      mImg.data[idx + 2] = Math.round(metal * 255);
      mImg.data[idx + 3] = 255;

      height[y * half + x] = h;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return {
    albedo: configureTexture(albedo, 3, 14, aniso, true),
    metallic: configureTexture(metallic, 3, 14, aniso, false),
    bump: buildNormalTextureFromHeight('ceilBump', scene, height, half, 2.2, 3, 14, aniso),
  };
}

function createBrushedMetalSet(scene: Scene, size: number, aniso: number): BabylonPbrTextureSet {
  const half = Math.max(256, Math.floor(size / 2));
  const albedo = new DynamicTexture('metalAlbedo', { width: half, height: half }, scene, true);
  const metallic = new DynamicTexture('metalMetallic', { width: half, height: half }, scene, true);
  const aCtx = albedo.getContext() as unknown as CanvasRenderingContext2D;
  const mCtx = metallic.getContext() as unknown as CanvasRenderingContext2D;
  const aImg = aCtx.createImageData(half, half);
  const mImg = mCtx.createImageData(half, half);
  const height = new Float32Array(half * half);

  for (let y = 0; y < half; y++) {
    const rowNoise = hash2(y * 0.43, 17.3);
    for (let x = 0; x < half; x++) {
      const fine = fbm((x / half) * 6, (y / half) * 96, 2);
      const smudge = fbm((x / half) * 7, (y / half) * 7, 2);
      const v = 148 + rowNoise * 22 + fine * 20 - smudge * 14;
      const rough = 0.2 + rowNoise * 0.14 + fine * 0.1 + smudge * 0.12;
      const idx = (y * half + x) * 4;
      aImg.data[idx] = Math.max(0, Math.min(255, v));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, v + 4));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, v + 10));
      aImg.data[idx + 3] = 255;

      mImg.data[idx] = 245;
      mImg.data[idx + 1] = Math.round(rough * 255);
      mImg.data[idx + 2] = 235;
      mImg.data[idx + 3] = 255;

      height[y * half + x] = 0.5 + rowNoise * 0.12 + fine * 0.08;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return {
    albedo: configureTexture(albedo, 2, 2, aniso, true),
    metallic: configureTexture(metallic, 2, 2, aniso, false),
    bump: buildNormalTextureFromHeight('metalBump', scene, height, half, 1.6, 2, 2, aniso),
  };
}

function createConcreteSet(scene: Scene, size: number, aniso: number, octaves: number): BabylonPbrTextureSet {
  const half = Math.max(256, Math.floor(size / 2));
  const albedo = new DynamicTexture('concAlbedo', { width: half, height: half }, scene, true);
  const metallic = new DynamicTexture('concMetallic', { width: half, height: half }, scene, true);
  const aCtx = albedo.getContext() as unknown as CanvasRenderingContext2D;
  const mCtx = metallic.getContext() as unknown as CanvasRenderingContext2D;
  const aImg = aCtx.createImageData(half, half);
  const mImg = mCtx.createImageData(half, half);
  const height = new Float32Array(half * half);

  const panelW = half / 2;
  const panelH = half / 2;

  for (let y = 0; y < half; y++) {
    for (let x = 0; x < half; x++) {
      const lx = x % panelW;
      const ly = y % panelH;
      const isSeam = Math.min(lx, panelW - lx, ly, panelH - ly) < Math.max(1.5, half * 0.005);
      const tieDist = Math.hypot(lx - panelW * 0.5, ly - panelH * 0.5);
      const isTieHole = tieDist < half * 0.025;

      const macro = fbm((x / half) * 6, (y / half) * 6, octaves);
      const micro = fbm((x / half) * 34, (y / half) * 34, 2);
      const pit = hash2(x * 0.91, y * 1.17) > 0.965 ? 0.25 : 0;

      let base = 52 + macro * 26 + micro * 12 - pit * 18;
      let rough = 0.84 + micro * 0.1;
      let ao = 0.94 - pit * 0.25;
      let h = 0.58 + micro * 0.14 - pit * 0.35;

      if (isSeam) {
        base *= 0.65;
        ao = 0.55;
        h = 0.28;
      } else if (isTieHole) {
        base *= 0.48;
        ao = 0.35;
        h = 0.15;
      }

      const idx = (y * half + x) * 4;
      aImg.data[idx] = Math.max(0, Math.min(255, base));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, base + 4));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, base + 9));
      aImg.data[idx + 3] = 255;

      mImg.data[idx] = Math.round(ao * 255);
      mImg.data[idx + 1] = Math.round(rough * 255);
      mImg.data[idx + 2] = 10;
      mImg.data[idx + 3] = 255;

      height[y * half + x] = h;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return {
    albedo: configureTexture(albedo, 2, 2, aniso, true),
    metallic: configureTexture(metallic, 2, 2, aniso, false),
    bump: buildNormalTextureFromHeight('concBump', scene, height, half, 2.8, 2, 2, aniso),
  };
}

function createWoodSet(scene: Scene, size: number, aniso: number): BabylonPbrTextureSet {
  const half = Math.max(256, Math.floor(size / 2));
  const albedo = new DynamicTexture('woodAlbedo', { width: half, height: half }, scene, true);
  const metallic = new DynamicTexture('woodMetallic', { width: half, height: half }, scene, true);
  const aCtx = albedo.getContext() as unknown as CanvasRenderingContext2D;
  const mCtx = metallic.getContext() as unknown as CanvasRenderingContext2D;
  const aImg = aCtx.createImageData(half, half);
  const mImg = mCtx.createImageData(half, half);
  const height = new Float32Array(half * half);

  for (let y = 0; y < half; y++) {
    for (let x = 0; x < half; x++) {
      const warp = fbm((x / half) * 4, (y / half) * 14, 3);
      const grain = Math.sin((y / half) * 110 + warp * 12) * 0.5 + 0.5;
      const fine = fbm((x / half) * 28, (y / half) * 8, 2);

      const r = 74 + grain * 26 + fine * 12;
      const g = 52 + grain * 18 + fine * 9;
      const b = 33 + grain * 12 + fine * 6;
      const rough = 0.78 + (1 - grain) * 0.14;

      const idx = (y * half + x) * 4;
      aImg.data[idx] = Math.min(255, r);
      aImg.data[idx + 1] = Math.min(255, g);
      aImg.data[idx + 2] = Math.min(255, b);
      aImg.data[idx + 3] = 255;

      mImg.data[idx] = Math.round((0.82 + grain * 0.16) * 255);
      mImg.data[idx + 1] = Math.round(rough * 255);
      mImg.data[idx + 2] = 6;
      mImg.data[idx + 3] = 255;

      height[y * half + x] = 0.45 + grain * 0.3 + fine * 0.1;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return {
    albedo: configureTexture(albedo, 1, 1, aniso, true),
    metallic: configureTexture(metallic, 1, 1, aniso, false),
    bump: buildNormalTextureFromHeight('woodBump', scene, height, half, 2.9, 1, 1, aniso),
  };
}

function createDoorLaminateSet(scene: Scene, size: number, aniso: number): BabylonPbrTextureSet {
  const half = Math.max(256, Math.floor(size / 2));
  const albedo = new DynamicTexture('doorAlbedo', { width: half, height: half }, scene, true);
  const metallic = new DynamicTexture('doorMetallic', { width: half, height: half }, scene, true);
  const aCtx = albedo.getContext() as unknown as CanvasRenderingContext2D;
  const mCtx = metallic.getContext() as unknown as CanvasRenderingContext2D;
  const aImg = aCtx.createImageData(half, half);
  const mImg = mCtx.createImageData(half, half);
  const height = new Float32Array(half * half);

  for (let y = 0; y < half; y++) {
    const u = y / half;
    for (let x = 0; x < half; x++) {
      const v = x / half;
      const inPanel = v > 0.14 && v < 0.86 && ((u > 0.12 && u < 0.45) || (u > 0.54 && u < 0.88));
      const panelEdge =
        (Math.abs(v - 0.14) < 0.015 || Math.abs(v - 0.86) < 0.015) && u > 0.12 && u < 0.88;
      const n = fbm(v * 14, u * 14, 3);
      const scuff = u > 0.72 ? fbm(v * 22, u * 22, 2) * 0.35 : 0;

      let r = 64 + n * 16 - scuff * 24;
      let g = 84 + n * 18 - scuff * 22;
      let b = 92 + n * 18 - scuff * 18;
      let rough = 0.44 + n * 0.12 + scuff * 0.35;
      let h = inPanel ? 0.46 : 0.62;
      let metal = 0.22;

      if (panelEdge) {
        r *= 0.75;
        g *= 0.75;
        b *= 0.75;
        h = 0.72;
      }

      // Subtle quarantine band at mid-height
      if (u > 0.47 && u < 0.51) {
        r = 128 + n * 12;
        g = 90 + n * 10;
        b = 34;
        rough = 0.55;
        metal = 0.1;
      }

      const idx = (y * half + x) * 4;
      aImg.data[idx] = Math.max(0, Math.min(255, r));
      aImg.data[idx + 1] = Math.max(0, Math.min(255, g));
      aImg.data[idx + 2] = Math.max(0, Math.min(255, b));
      aImg.data[idx + 3] = 255;

      mImg.data[idx] = Math.round((inPanel ? 0.88 : 0.96) * 255);
      mImg.data[idx + 1] = Math.round(rough * 255);
      mImg.data[idx + 2] = Math.round(metal * 255);
      mImg.data[idx + 3] = 255;

      height[y * half + x] = h + n * 0.05;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return {
    albedo: configureTexture(albedo, 1, 1, aniso, true),
    metallic: configureTexture(metallic, 1, 1, aniso, false),
    bump: buildNormalTextureFromHeight('doorBump', scene, height, half, 2.4, 1, 1, aniso),
  };
}

function createBuildingFacadeSet(scene: Scene, size: number, aniso: number): BabylonPbrTextureSet {
  const half = Math.max(256, Math.floor(size / 2));
  const albedo = new DynamicTexture('bldgAlbedo', { width: half, height: half }, scene, true);
  const metallic = new DynamicTexture('bldgMetallic', { width: half, height: half }, scene, true);
  const aCtx = albedo.getContext() as unknown as CanvasRenderingContext2D;
  const mCtx = metallic.getContext() as unknown as CanvasRenderingContext2D;
  const aImg = aCtx.createImageData(half, half);
  const mImg = mCtx.createImageData(half, half);
  const height = new Float32Array(half * half);

  const cols = 4;
  const rows = 4;
  const cellW = half / cols;
  const cellH = half / rows;

  for (let y = 0; y < half; y++) {
    for (let x = 0; x < half; x++) {
      const cx = Math.floor(x / cellW);
      const cy = Math.floor(y / cellH);
      const lx = (x % cellW) / cellW;
      const ly = (y % cellH) / cellH;

      const isWin = lx > 0.2 && lx < 0.8 && ly > 0.22 && ly < 0.74;
      const isMullion = isWin && Math.abs(lx - 0.5) < 0.035;
      const isLedge = ly > 0.14 && ly <= 0.22;
      const seed = hash2(cx * 17.3, cy * 31.1);
      const n = fbm((x / half) * 16, (y / half) * 16, 3);

      let r = 46 + n * 20;
      let g = 55 + n * 22;
      let b = 65 + n * 24;
      let rough = 0.86;
      let metal = 0.08;
      let ao = 0.92;
      let h = 0.72 + n * 0.08;

      if (isLedge) {
        r *= 0.8;
        g *= 0.82;
        b *= 0.85;
        h = 0.88;
      } else if (isWin && !isMullion) {
        const lit = seed > 0.78;
        if (lit) {
          r = seed > 0.9 ? 185 : 74;
          g = seed > 0.9 ? 132 : 126;
          b = seed > 0.9 ? 65 : 158;
        } else {
          r = 10 + n * 10;
          g = 17 + n * 12;
          b = 26 + n * 14;
        }
        rough = 0.12;
        metal = 0.32;
        ao = 0.65;
        h = 0.22;
      } else if (isMullion) {
        r = 32;
        g = 38;
        b = 44;
        rough = 0.42;
        metal = 0.65;
        h = 0.58;
      }

      const idx = (y * half + x) * 4;
      aImg.data[idx] = Math.min(255, r);
      aImg.data[idx + 1] = Math.min(255, g);
      aImg.data[idx + 2] = Math.min(255, b);
      aImg.data[idx + 3] = 255;

      mImg.data[idx] = Math.round(ao * 255);
      mImg.data[idx + 1] = Math.round(rough * 255);
      mImg.data[idx + 2] = Math.round(metal * 255);
      mImg.data[idx + 3] = 255;

      height[y * half + x] = h;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return {
    albedo: configureTexture(albedo, 2, 3, aniso, true),
    metallic: configureTexture(metallic, 2, 3, aniso, false),
    bump: buildNormalTextureFromHeight('bldgBump', scene, height, half, 3.0, 2, 3, aniso),
  };
}

function createSignTexture(
  name: string,
  scene: Scene,
  title: string,
  subtitle: string,
  accent: string,
  bg: string,
  aniso: number,
  compact: boolean,
): DynamicTexture {
  const w = compact ? 256 : 512;
  const h = compact ? 96 : 192;
  const tex = new DynamicTexture(name, { width: w, height: h }, scene, true);
  const ctx = tex.getContext() as unknown as CanvasRenderingContext2D;
  if (compact) ctx.scale(0.5, 0.5);

  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, 512, 192);

  ctx.strokeStyle = accent;
  ctx.lineWidth = 6;
  ctx.strokeRect(10, 10, 492, 172);

  ctx.fillStyle = accent;
  ctx.font = '700 40px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(title, 256, 74);

  ctx.fillStyle = '#d9e7ef';
  ctx.font = '600 20px system-ui, -apple-system, sans-serif';
  ctx.fillText(subtitle, 256, 134);

  tex.gammaSpace = true;
  tex.anisotropicFilteringLevel = aniso;
  tex.update(false);
  return tex;
}

function createXrayTexture(scene: Scene, aniso: number, compact: boolean): DynamicTexture {
  const w = compact ? 256 : 512;
  const h = compact ? 160 : 320;
  const tex = new DynamicTexture('xrayScreen', { width: w, height: h }, scene, true);
  const ctx = tex.getContext() as unknown as CanvasRenderingContext2D;
  if (compact) ctx.scale(0.5, 0.5);

  ctx.fillStyle = '#091821';
  ctx.fillRect(0, 0, 512, 320);

  // Two radiograph film sheets side by side
  [24, 266].forEach((ox, idx) => {
    ctx.fillStyle = '#0e2836';
    ctx.fillRect(ox, 20, 222, 280);
    ctx.strokeStyle = '#6ec2e8';
    ctx.lineWidth = 2;
    ctx.strokeRect(ox, 20, 222, 280);

    // Stylized skull / ribcage silhouette
    ctx.fillStyle = 'rgba(175, 228, 250, 0.42)';
    if (idx === 0) {
      // Thoracic ribs
      for (let r = 0; r < 6; r++) {
        ctx.beginPath();
        ctx.ellipse(ox + 111, 88 + r * 26, 66 - r * 3, 9, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillRect(ox + 104, 64, 14, 180);
    } else {
      // Cranial scan with anomaly marker
      ctx.beginPath();
      ctx.ellipse(ox + 111, 135, 58, 72, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ff6b54';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(ox + 132, 118, 20, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.fillStyle = '#9fe2ff';
    ctx.font = '700 13px monospace';
    ctx.fillText(idx === 0 ? 'PAT-04 · THORAX' : 'PAT-04 · CRÂNE [ANOMALIE]', ox + 12, 286);
  });

  tex.gammaSpace = true;
  tex.anisotropicFilteringLevel = aniso;
  tex.update(false);
  return tex;
}

function createRadialSprite(
  name: string,
  scene: Scene,
  inner: string,
  outer: string,
  size = 64,
): DynamicTexture {
  const tex = new DynamicTexture(name, { width: size, height: size }, scene, true);
  const ctx = tex.getContext();
  const half = size / 2;
  ctx.clearRect(0, 0, size, size);
  const grad = ctx.createRadialGradient(half, half, 1, half, half, half - 1);
  grad.addColorStop(0, inner);
  grad.addColorStop(1, outer);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  tex.hasAlpha = true;
  tex.update(false);
  return tex;
}

function createHospitalEnvCubeTexture(scene: Scene): RawCubeTexture {
  const size = 32;
  const faces: Uint8Array[] = [];
  for (let face = 0; face < 6; face++) {
    const buf = new Uint8Array(size * size * 4);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const u = (x / (size - 1)) * 2 - 1;
        const v = (y / (size - 1)) * 2 - 1;
        let r = 20;
        let g = 30;
        let b = 42;

        if (face === 2) {
          const strip = Math.exp(-u * u * 16) * (0.55 + 0.45 * Math.cos(v * Math.PI * 2));
          r = 26 + strip * 165;
          g = 38 + strip * 195;
          b = 54 + strip * 200;
        } else if (face === 3) {
          r = 12;
          g = 17;
          b = 24;
        } else if (face === 4 || face === 5) {
          const glow = Math.exp(-(u * u + v * v) * 2.5);
          if (face === 5) {
            r = 22 + glow * 135;
            g = 26 + glow * 62;
            b = 34 + glow * 25;
          } else {
            r = 18 + glow * 48;
            g = 26 + glow * 72;
            b = 38 + glow * 95;
          }
        } else {
          const verticalGrad = 1 - Math.abs(v) * 0.5;
          r = 24 * verticalGrad + 10;
          g = 36 * verticalGrad + 14;
          b = 46 * verticalGrad + 18;
        }

        const idx = (y * size + x) * 4;
        buf[idx] = Math.min(255, Math.round(r));
        buf[idx + 1] = Math.min(255, Math.round(g));
        buf[idx + 2] = Math.min(255, Math.round(b));
        buf[idx + 3] = 255;
      }
    }
    faces.push(buf);
  }

  return new RawCubeTexture(
    scene,
    faces,
    size,
    Engine.TEXTUREFORMAT_RGBA,
    Engine.TEXTURETYPE_UNSIGNED_BYTE,
    true,
    false,
    Texture.TRILINEAR_SAMPLINGMODE,
  );
}

export function buildHospitalTextures(
  engine: Engine,
  scene: Scene,
  isMobileOrSoftware: boolean,
): HospitalTextureLibrary {
  const maxAniso = Math.min(isMobileOrSoftware ? 4 : 8, engine.getCaps().maxAnisotropy || 4);
  // Crisp 512px PBR maps on iPhone X (balanced RAM), 1024px high-res on desktop
  const size = isMobileOrSoftware ? 512 : 1024;
  const octaves = isMobileOrSoftware ? 3 : 4;

  const envCube = createHospitalEnvCubeTexture(scene);
  const floor = createFloorSet(scene, size, maxAniso, octaves);
  const wall = createWallSet(scene, size, maxAniso, octaves);
  const ceiling = createCeilingSet(scene, size, maxAniso);
  const brushedMetal = createBrushedMetalSet(scene, size, maxAniso);
  const concrete = createConcreteSet(scene, size, maxAniso, octaves);
  const wood = createWoodSet(scene, size, maxAniso);
  const doorLaminate = createDoorLaminateSet(scene, size, maxAniso);
  const buildingFacade = createBuildingFacadeSet(scene, size, maxAniso);

  const exitSign = createSignTexture(
    'exitSign',
    scene,
    'SORTIE NORD',
    'SAS DE QUARANTAINE · ACCÈS',
    '#ff8b42',
    '#170a05',
    maxAniso,
    isMobileOrSoftware,
  );
  const sectorSign = createSignTexture(
    'sectorSign',
    scene,
    'SECTEUR 04',
    'SOINS INTENSIFS · SILENCE',
    '#78b4e8',
    '#08121c',
    maxAniso,
    isMobileOrSoftware,
  );
  const directionalSign = createSignTexture(
    'dirSign',
    scene,
    '← OBSERVATION | NORD ↑',
    'POSTE DE SOINS · AILE EST →',
    '#8ac4f0',
    '#071019',
    maxAniso,
    isMobileOrSoftware,
  );

  const plaqueReception = createSignTexture(
    'plaqueRec',
    scene,
    'POSTE DE SOINS',
    'ACCUEIL · ARCHIVES EST',
    '#74d6ff',
    '#071219',
    maxAniso,
    true,
  );
  const plaqueObservation = createSignTexture(
    'plaqueObs',
    scene,
    'OBSERVATION',
    'CHAMBRE ISOLÉE · OUEST',
    '#8ac4f0',
    '#071219',
    maxAniso,
    true,
  );
  const plaqueSurgery = createSignTexture(
    'plaqueSurg',
    scene,
    'BLOC CHIRURGICAL',
    'ACCÈS RESTREINT · CLÉ',
    '#52e3b4',
    '#061714',
    maxAniso,
    true,
  );
  const plaqueGenerator = createSignTexture(
    'plaqueGen',
    scene,
    'GÉNÉRATEUR',
    'ZONE TECHNIQUE · CLÉ',
    '#f5a642',
    '#191005',
    maxAniso,
    true,
  );

  const xrayScreen = createXrayTexture(scene, maxAniso, isMobileOrSoftware);

  const monW = isMobileOrSoftware ? 256 : 512;
  const monH = isMobileOrSoftware ? 192 : 384;
  const monitorScreen = new DynamicTexture(
    'monitorScreen',
    { width: monW, height: monH },
    scene,
    false,
  );
  monitorScreen.gammaSpace = true;

  const updateMonitorScreen = (elapsed: number, powerRestored: boolean, cluesCollected: number) => {
    const ctx = monitorScreen.getContext();
    ctx.save();
    if (isMobileOrSoftware) ctx.scale(0.5, 0.5);

    ctx.fillStyle = '#04120f';
    ctx.fillRect(0, 0, 512, 384);

    ctx.strokeStyle = '#0f3d33';
    ctx.lineWidth = 1;
    for (let x = 0; x < 512; x += 32) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 384);
      ctx.stroke();
    }
    for (let y = 0; y < 384; y += 32) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(512, y);
      ctx.stroke();
    }

    ctx.fillStyle = '#3ef2b6';
    ctx.font = '700 20px monospace';
    ctx.fillText('UNITÉ QUARANTAINE · SECTEUR B', 26, 40);
    ctx.fillStyle = powerRestored ? '#4effb2' : '#ff6b4a';
    ctx.fillText(
      powerRestored
        ? 'STATUT : ALIMENTATION SECOURS ACTIVE'
        : 'ALERTE : ALIMENTATION SECOURS REQUISE',
      26,
      74,
    );

    const sweep = (elapsed * 110) % 456;
    ctx.strokeStyle = powerRestored ? '#4effb2' : '#4bffc4';
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let x = 28; x < 484; x += 2) {
      const localX = (x - 28 - sweep + 456) % 120;
      let y = 210;
      if (localX > 42 && localX < 48) y = 195;
      else if (localX >= 48 && localX < 54) y = 235;
      else if (localX >= 54 && localX < 60) y = 118;
      else if (localX >= 60 && localX < 68) y = 252;
      else if (localX >= 68 && localX < 76) y = 204;
      if (x === 28) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    ctx.fillStyle = '#8ad8c4';
    ctx.font = '16px monospace';
    ctx.fillText(
      `COMPOSANTS : ${cluesCollected}/4 · ${powerRestored ? 'SAS OUVERT' : 'SAS VERROUILLÉ'}`,
      26,
      336,
    );

    ctx.restore();
    monitorScreen.update(false);
  };
  updateMonitorScreen(0, false, 0);

  const contactShadow = createRadialSprite(
    'contactShadow',
    scene,
    'rgba(0,0,0,0.72)',
    'rgba(0,0,0,0)',
    isMobileOrSoftware ? 64 : 128,
  );
  const dustParticle = createRadialSprite(
    'dustParticle',
    scene,
    'rgba(210,232,250,0.9)',
    'rgba(210,232,250,0)',
    isMobileOrSoftware ? 64 : 128,
  );

  return {
    envCube,
    floor,
    wall,
    ceiling,
    brushedMetal,
    concrete,
    wood,
    doorLaminate,
    buildingFacade,
    exitSign,
    sectorSign,
    directionalSign,
    plaqueReception,
    plaqueObservation,
    plaqueSurgery,
    plaqueGenerator,
    xrayScreen,
    monitorScreen,
    updateMonitorScreen,
    contactShadow,
    dustParticle,
    dispose: () => {
      envCube.dispose();
      [floor, wall, ceiling, brushedMetal, concrete, wood, doorLaminate, buildingFacade].forEach((s) => {
        s.albedo.dispose();
        s.bump.dispose();
        s.metallic.dispose();
      });
      exitSign.dispose();
      sectorSign.dispose();
      directionalSign.dispose();
      plaqueReception.dispose();
      plaqueObservation.dispose();
      plaqueSurgery.dispose();
      plaqueGenerator.dispose();
      xrayScreen.dispose();
      monitorScreen.dispose();
      contactShadow.dispose();
      dustParticle.dispose();
    },
  };
}
