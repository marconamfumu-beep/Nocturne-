import {
  AbstractMesh,
  Color3,
  Color4,
  DirectionalLight,
  Effect,
  Engine,
  GaussianSplattingMesh,
  HemisphericLight,
  Matrix,
  Mesh,
  MeshBuilder,
  MirrorTexture,
  ParticleSystem,
  PBRMaterial,
  Plane,
  PointLight,
  Ray,
  Scalar,
  Scene,
  ShaderMaterial,
  ShadowGenerator,
  SpotLight,
  StandardMaterial,
  TransformNode,
  UniversalCamera,
  Vector3,
} from '@babylonjs/core';
import '@babylonjs/loaders/SPLAT';
import type { ChapterId, ClueNote, RenderQualityConfig } from '../types/game';
import {
  createBloodAndRainAtmosphere,
  createFirstPersonGearRig,
  createNoahThirdPersonRig,
  populateChapterExtensions,
  type DrawerTarget,
  type FpGearRig,
  type NoahRig,
  type NpcCharacterRig,
} from '../scenes/chapterExtensions';
import { buildHospitalTextures, type HospitalTextureLibrary } from './textures';

export interface Aabb2D {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  disabled?: boolean;
}

export interface PuddleZone {
  x: number;
  z: number;
  radius: number;
}

export interface DoorTarget {
  id: string;
  label: string;
  position: Vector3;
  kind: 'unlocked' | 'locked' | 'barricaded';
  requiredKeyId?: string;
  requiredKeyLabel?: string;
  isOpen: boolean;
  isUnlocked: boolean;
  openAngle: number;
  targetAngle: number;
  leftLeaf: TransformNode;
  rightLeaf: TransformNode | null;
  collider: Aabb2D;
  barricadeMessage?: string;
}

export interface HideoutTarget {
  id: string;
  label: string;
  kind: 'locker' | 'bed';
  position: Vector3;
  cameraPos: Vector3;
  exitPos: Vector3;
  baseYaw: number;
  doorPivot: TransformNode | null;
  doorAngle: number;
  targetDoorAngle: number;
}

export interface InteractableTarget {
  id: string;
  label: string;
  position: Vector3;
  root: TransformNode;
  ringMesh: Mesh;
  collected: boolean;
  isKey?: boolean;
  keyLabel?: string;
  isBottle?: boolean;
  isGeneratorSwitch?: boolean;
  isExitPanel?: boolean;
  doorRef?: DoorTarget;
  hideoutRef?: HideoutTarget;
  note?: ClueNote;
}

export interface PracticalFixture {
  light: PointLight;
  tubeMat: StandardMaterial;
  coneMesh: Mesh;
  baseIntensity: number;
  phase: number;
  flickerCooldown: number;
  isFlickering: boolean;
  isEmergency?: boolean;
  zPos: number;
}

export interface MonsterRig {
  root: TransformNode;
  head: TransformNode;
  leftArm: TransformNode;
  rightArm: TransformNode;
  leftLeg: TransformNode;
  rightLeg: TransformNode;
  eyeMat: StandardMaterial;
}

export interface HospitalWorld {
  scene: Scene;
  camera: UniversalCamera;
  flashlight: SpotLight;
  bounceLight: PointLight;
  colliders: Aabb2D[];
  puddles: PuddleZone[];
  doors: DoorTarget[];
  hideouts: HideoutTarget[];
  interactables: InteractableTarget[];
  fixtures: PracticalFixture[];
  breakerLedMat: StandardMaterial;
  generatorLedMat: StandardMaterial;
  monster: MonsterRig;
  noahRig: NoahRig;
  fpGear: FpGearRig;
  drawers: DrawerTarget[];
  npcs: NpcCharacterRig[];
  raycastMeshes: AbstractMesh[];
  thrownBottleMesh: TransformNode;
  triggerGlassShatter: (pos: Vector3) => void;
  setPremiumSkins: (enabled: boolean) => void;
  applyQuality: (config: RenderQualityConfig) => void;
  setGaussianEnabled: (enabled: boolean) => void;
  isGaussianEnabled: () => boolean;
  updateDynamicElements: (
    elapsed: number,
    dt: number,
    flashlightOn: boolean,
    flashlightFlickerMult: number,
    powerRestored: boolean,
    generatorRestored: boolean,
    cluesCollected: number,
    onFlickerBuzz: () => void,
  ) => void;
  resetObjectives: () => void;
  dispose: () => void;
}

let volumetricShaderRegistered = false;
function ensureVolumetricShader(): void {
  if (volumetricShaderRegistered) return;
  volumetricShaderRegistered = true;

  Effect.ShadersStore['volumetricConeVertexShader'] = `
    precision highp float;
    attribute vec3 position;
    attribute vec3 normal;
    attribute vec2 uv;
    uniform mat4 world;
    uniform mat4 worldViewProjection;
    uniform vec3 cameraPosition;
    varying vec2 vUv;
    varying vec3 vNormalW;
    varying vec3 vViewDirW;
    void main() {
      vUv = uv;
      vec4 worldPos = world * vec4(position, 1.0);
      vNormalW = normalize(mat3(world) * normal);
      vViewDirW = normalize(cameraPosition - worldPos.xyz);
      gl_Position = worldViewProjection * vec4(position, 1.0);
    }
  `;

  Effect.ShadersStore['volumetricConeFragmentShader'] = `
    precision highp float;
    uniform vec3 uColor;
    uniform float uOpacity;
    varying vec2 vUv;
    varying vec3 vNormalW;
    varying vec3 vViewDirW;
    void main() {
      float edge = pow(abs(dot(normalize(vNormalW), normalize(vViewDirW))), 1.65);
      float fadeY = smoothstep(0.0, 0.72, vUv.y) * smoothstep(1.0, 0.84, vUv.y);
      float alpha = edge * fadeY * uOpacity;
      gl_FragColor = vec4(uColor, alpha);
    }
  `;
}

function createVolumetricCone(
  name: string,
  scene: Scene,
  color: Color3,
  height: number,
  diameterBottom: number,
  opacity: number,
): Mesh {
  ensureVolumetricShader();
  const cone = MeshBuilder.CreateCylinder(
    name,
    { height, diameterTop: 0.08, diameterBottom, tessellation: 16, updatable: false },
    scene,
  );
  cone.bakeTransformIntoVertices(Matrix.Translation(0, -height / 2, 0));

  const mat = new ShaderMaterial(
    name + 'Mat',
    scene,
    { vertex: 'volumetricCone', fragment: 'volumetricCone' },
    {
      attributes: ['position', 'normal', 'uv'],
      uniforms: ['world', 'worldViewProjection', 'cameraPosition', 'uColor', 'uOpacity'],
      needAlphaBlending: true,
    },
  );
  mat.setColor3('uColor', color);
  mat.setFloat('uOpacity', opacity);
  mat.alphaMode = Engine.ALPHA_ADD;
  mat.backFaceCulling = false;
  mat.disableDepthWrite = true;

  cone.material = mat;
  cone.isPickable = false;
  return cone;
}

function makeContactShadow(
  name: string,
  scene: Scene,
  tex: HospitalTextureLibrary['contactShadow'],
  w: number,
  d: number,
): Mesh {
  const plane = MeshBuilder.CreateGround(name, { width: w, height: d }, scene);
  plane.position.y = 0.004;
  const mat = new StandardMaterial(name + 'Mat', scene);
  mat.diffuseTexture = tex;
  mat.opacityTexture = tex;
  mat.disableLighting = true;
  mat.useAlphaFromDiffuseTexture = true;
  mat.alpha = 0.75;
  mat.zOffset = -1;
  plane.material = mat;
  plane.isPickable = false;
  return plane;
}

function createPbrMaterial(
  name: string,
  scene: Scene,
  texSet: HospitalTextureLibrary['floor'],
  roughnessMul = 1.0,
  metalMul = 1.0,
  envIntensity = 0.55,
  maxLights = 4,
): PBRMaterial {
  const mat = new PBRMaterial(name, scene);
  mat.albedoTexture = texSet.albedo;
  mat.bumpTexture = texSet.bump;
  mat.metallicTexture = texSet.metallic;
  mat.useAmbientOcclusionFromMetallicTextureRed = true;
  mat.useRoughnessFromMetallicTextureGreen = true;
  mat.useMetallnessFromMetallicTextureBlue = true;
  mat.useRoughnessFromMetallicTextureAlpha = false;
  mat.roughness = roughnessMul;
  mat.metallic = metalMul;
  mat.environmentIntensity = envIntensity;
  mat.maxSimultaneousLights = maxLights;
  return mat;
}

function createGurney(
  name: string,
  scene: Scene,
  steelMat: PBRMaterial,
  darkMetalMat: PBRMaterial,
  mattressMat: PBRMaterial,
  glassMat: PBRMaterial,
  textures: HospitalTextureLibrary,
  shadowGen: ShadowGenerator | null,
): TransformNode {
  const root = new TransformNode(name, scene);
  const cs = makeContactShadow(name + 'Shadow', scene, textures.contactShadow, 1.15, 2.25);
  cs.parent = root;

  const legOffsets: [number, number][] = [
    [-0.36, -0.82],
    [0.36, -0.82],
    [-0.36, 0.82],
    [0.36, 0.82],
  ];

  legOffsets.forEach(([lx, lz], i) => {
    const wheel = MeshBuilder.CreateCylinder(
      `${name}_w${i}`,
      { diameter: 0.13, height: 0.04, tessellation: 12 },
      scene,
    );
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(lx, 0.065, lz);
    wheel.material = darkMetalMat;
    wheel.parent = root;

    const leg = MeshBuilder.CreateCylinder(
      `${name}_l${i}`,
      { diameter: 0.048, height: 0.66, tessellation: 8 },
      scene,
    );
    leg.position.set(lx, 0.41, lz);
    leg.material = steelMat;
    leg.parent = root;
  });

  const tray = MeshBuilder.CreateBox(`${name}_tray`, { width: 0.76, height: 0.03, depth: 1.68 }, scene);
  tray.position.y = 0.28;
  tray.material = steelMat;
  tray.receiveShadows = true;
  tray.parent = root;

  const deck = MeshBuilder.CreateBox(`${name}_deck`, { width: 0.84, height: 0.05, depth: 1.94 }, scene);
  deck.position.y = 0.74;
  deck.material = steelMat;
  deck.receiveShadows = true;
  deck.parent = root;
  shadowGen?.addShadowCaster(deck);

  const mattress = MeshBuilder.CreateBox(
    `${name}_mat`,
    { width: 0.78, height: 0.11, depth: 1.38 },
    scene,
  );
  mattress.position.set(0, 0.82, 0.24);
  mattress.material = mattressMat;
  mattress.receiveShadows = true;
  mattress.parent = root;
  shadowGen?.addShadowCaster(mattress);

  const headrest = MeshBuilder.CreateBox(
    `${name}_head`,
    { width: 0.78, height: 0.11, depth: 0.5 },
    scene,
  );
  headrest.position.set(0, 0.88, -0.68);
  headrest.rotation.x = -0.24;
  headrest.material = mattressMat;
  headrest.parent = root;

  [-0.43, 0.43].forEach((sx, i) => {
    const rail = MeshBuilder.CreateCylinder(
      `${name}_rail${i}`,
      { diameter: 0.03, height: 1.25, tessellation: 8 },
      scene,
    );
    rail.rotation.x = Math.PI / 2;
    rail.position.set(sx, 0.96, 0.05);
    rail.material = steelMat;
    rail.parent = root;
  });

  const ivPole = MeshBuilder.CreateCylinder(
    `${name}_pole`,
    { diameterTop: 0.028, diameterBottom: 0.036, height: 1.28, tessellation: 8 },
    scene,
  );
  ivPole.position.set(-0.37, 1.38, -0.86);
  ivPole.material = steelMat;
  ivPole.parent = root;

  const ivArm = MeshBuilder.CreateCylinder(
    `${name}_arm`,
    { diameter: 0.018, height: 0.22, tessellation: 8 },
    scene,
  );
  ivArm.rotation.z = Math.PI / 2;
  ivArm.position.set(-0.28, 2.0, -0.86);
  ivArm.material = steelMat;
  ivArm.parent = root;

  const ivBottle = MeshBuilder.CreateCylinder(
    `${name}_iv`,
    { diameter: 0.084, height: 0.15, tessellation: 12 },
    scene,
  );
  ivBottle.position.set(-0.2, 1.88, -0.86);
  ivBottle.material = glassMat;
  ivBottle.parent = root;

  return root;
}

function createWheelchair(
  name: string,
  scene: Scene,
  steelMat: PBRMaterial,
  seatMat: PBRMaterial,
  rubberMat: PBRMaterial,
  textures: HospitalTextureLibrary,
  shadowGen: ShadowGenerator | null,
): TransformNode {
  const root = new TransformNode(name, scene);
  const cs = makeContactShadow(name + 'Shadow', scene, textures.contactShadow, 0.95, 0.95);
  cs.parent = root;

  const seat = MeshBuilder.CreateBox(`${name}_seat`, { width: 0.48, height: 0.05, depth: 0.46 }, scene);
  seat.position.set(0, 0.48, 0);
  seat.material = seatMat;
  seat.parent = root;
  shadowGen?.addShadowCaster(seat);

  const back = MeshBuilder.CreateBox(`${name}_back`, { width: 0.48, height: 0.5, depth: 0.045 }, scene);
  back.position.set(0, 0.76, -0.22);
  back.rotation.x = 0.12;
  back.material = seatMat;
  back.parent = root;
  shadowGen?.addShadowCaster(back);

  [-0.26, 0.26].forEach((sx, i) => {
    const arm = MeshBuilder.CreateBox(`${name}_arm${i}`, { width: 0.04, height: 0.035, depth: 0.44 }, scene);
    arm.position.set(sx, 0.68, -0.02);
    arm.material = rubberMat;
    arm.parent = root;

    const post = MeshBuilder.CreateCylinder(
      `${name}_post${i}`,
      { diameter: 0.03, height: 0.56, tessellation: 8 },
      scene,
    );
    post.position.set(sx, 0.74, -0.24);
    post.material = steelMat;
    post.parent = root;

    const rim = MeshBuilder.CreateTorus(
      `${name}_rim${i}`,
      { diameter: 0.62, thickness: 0.044, tessellation: 18 },
      scene,
    );
    rim.rotation.z = Math.PI / 2;
    rim.position.set(sx + (sx < 0 ? -0.03 : 0.03), 0.33, -0.08);
    rim.material = rubberMat;
    rim.parent = root;
    shadowGen?.addShadowCaster(rim);

    const hub = MeshBuilder.CreateCylinder(
      `${name}_hub${i}`,
      { diameter: 0.07, height: 0.05, tessellation: 8 },
      scene,
    );
    hub.rotation.z = Math.PI / 2;
    hub.position.copyFrom(rim.position);
    hub.material = steelMat;
    hub.parent = root;

    const frontW = MeshBuilder.CreateCylinder(
      `${name}_fw${i}`,
      { diameter: 0.16, height: 0.03, tessellation: 10 },
      scene,
    );
    frontW.rotation.z = Math.PI / 2;
    frontW.position.set(sx, 0.08, 0.26);
    frontW.material = rubberMat;
    frontW.parent = root;
  });

  return root;
}

function createCrashCart(
  name: string,
  scene: Scene,
  bodyMat: PBRMaterial,
  steelMat: PBRMaterial,
  darkMetalMat: PBRMaterial,
  screenMat: StandardMaterial,
  textures: HospitalTextureLibrary,
  shadowGen: ShadowGenerator | null,
): TransformNode {
  const root = new TransformNode(name, scene);
  const cs = makeContactShadow(name + 'Shadow', scene, textures.contactShadow, 1.05, 0.85);
  cs.parent = root;

  [
    [-0.36, -0.24],
    [0.36, -0.24],
    [-0.36, 0.24],
    [0.36, 0.24],
  ].forEach(([wx, wz], i) => {
    const w = MeshBuilder.CreateCylinder(
      `${name}_w${i}`,
      { diameter: 0.11, height: 0.035, tessellation: 10 },
      scene,
    );
    w.rotation.z = Math.PI / 2;
    w.position.set(wx, 0.055, wz);
    w.material = darkMetalMat;
    w.parent = root;
  });

  const cabinet = MeshBuilder.CreateBox(`${name}_cab`, { width: 0.84, height: 0.84, depth: 0.56 }, scene);
  cabinet.position.y = 0.53;
  cabinet.material = bodyMat;
  cabinet.receiveShadows = true;
  cabinet.parent = root;
  shadowGen?.addShadowCaster(cabinet);

  for (let i = 0; i < 4; i++) {
    const drawer = MeshBuilder.CreateBox(`${name}_drw${i}`, { width: 0.76, height: 0.15, depth: 0.03 }, scene);
    drawer.position.set(0, 0.25 + i * 0.18, 0.285);
    drawer.material = steelMat;
    drawer.parent = root;

    const handle = MeshBuilder.CreateBox(`${name}_hdl${i}`, { width: 0.32, height: 0.02, depth: 0.035 }, scene);
    handle.position.set(0, 0.25 + i * 0.18, 0.31);
    handle.material = darkMetalMat;
    handle.parent = root;
  }

  const top = MeshBuilder.CreateBox(`${name}_top`, { width: 0.9, height: 0.04, depth: 0.62 }, scene);
  top.position.y = 0.97;
  top.material = steelMat;
  top.parent = root;

  const defib = MeshBuilder.CreateBox(`${name}_defib`, { width: 0.34, height: 0.24, depth: 0.24 }, scene);
  defib.position.set(-0.18, 1.11, -0.05);
  defib.material = darkMetalMat;
  defib.parent = root;
  shadowGen?.addShadowCaster(defib);

  const scr = MeshBuilder.CreatePlane(`${name}_scr`, { width: 0.24, height: 0.15 }, scene);
  scr.position.set(-0.18, 1.12, 0.072);
  scr.rotation.y = Math.PI;
  scr.material = screenMat;
  scr.parent = root;

  return root;
}

function createDoorAssembly(
  name: string,
  scene: Scene,
  doorMat: PBRMaterial,
  frameMat: PBRMaterial,
  steelMat: PBRMaterial,
  glassMat: PBRMaterial,
  width: number,
  height: number,
  mirrorRenderList: AbstractMesh[],
  singleLeaf = false,
): { frame: TransformNode; leftLeaf: TransformNode; rightLeaf: TransformNode | null } {
  const frame = new TransformNode(name, scene);

  const pillarL = MeshBuilder.CreateBox(`${name}_pL`, { width: 0.12, height: height + 0.1, depth: 0.24 }, scene);
  pillarL.position.set(-width / 2 - 0.05, (height + 0.1) / 2, 0);
  pillarL.material = frameMat;
  pillarL.parent = frame;

  const pillarR = MeshBuilder.CreateBox(`${name}_pR`, { width: 0.12, height: height + 0.1, depth: 0.24 }, scene);
  pillarR.position.set(width / 2 + 0.05, (height + 0.1) / 2, 0);
  pillarR.material = frameMat;
  pillarR.parent = frame;

  const lintel = MeshBuilder.CreateBox(`${name}_lin`, { width: width + 0.24, height: 0.12, depth: 0.24 }, scene);
  lintel.position.set(0, height + 0.04, 0);
  lintel.material = frameMat;
  lintel.parent = frame;

  const leafW = singleLeaf ? width - 0.04 : width / 2 - 0.025;
  const makeLeaf = (hingeSide: -1 | 1): TransformNode => {
    const pivot = new TransformNode(`${name}_leaf_${hingeSide}`, scene);
    pivot.position.set(hingeSide * (width / 2 - 0.02), 0, 0);
    pivot.parent = frame;

    const offsetX = -hingeSide * (leafW / 2);

    const slab = MeshBuilder.CreateBox(`${name}_slab_${hingeSide}`, { width: leafW, height: height - 0.03, depth: 0.065 }, scene);
    slab.position.set(offsetX, (height - 0.03) / 2, 0);
    slab.material = doorMat;
    slab.receiveShadows = true;
    slab.parent = pivot;
    mirrorRenderList.push(slab);

    const kick = MeshBuilder.CreateBox(`${name}_kick_${hingeSide}`, { width: leafW - 0.04, height: 0.28, depth: 0.072 }, scene);
    kick.position.set(offsetX, 0.16, 0);
    kick.material = steelMat;
    kick.parent = pivot;

    const bar = MeshBuilder.CreateBox(`${name}_bar_${hingeSide}`, { width: leafW * 0.68, height: 0.055, depth: 0.05 }, scene);
    bar.position.set(offsetX, 1.05, 0.055);
    bar.material = steelMat;
    bar.parent = pivot;

    const winFrame = MeshBuilder.CreateBox(`${name}_wf_${hingeSide}`, { width: 0.26, height: 0.62, depth: 0.078 }, scene);
    winFrame.position.set(offsetX, 1.65, 0);
    winFrame.material = frameMat;
    winFrame.parent = pivot;

    const glass = MeshBuilder.CreatePlane(`${name}_gl_${hingeSide}`, { width: 0.2, height: 0.56 }, scene);
    glass.position.set(offsetX, 1.65, 0.041);
    glass.rotation.y = Math.PI;
    glass.material = glassMat;
    glass.parent = pivot;

    return pivot;
  };

  return {
    frame,
    leftLeaf: makeLeaf(-1),
    rightLeaf: singleLeaf ? null : makeLeaf(1),
  };
}

function addBarricadePlanks(
  name: string,
  parent: TransformNode,
  scene: Scene,
  woodMat: PBRMaterial,
  hazardMat: PBRMaterial,
  width: number,
  zOffset = 0.09,
): void {
  const angles = [0.22, -0.26, 0.06];
  const heights = [1.55, 1.15, 0.72];
  angles.forEach((ang, idx) => {
    const plank = MeshBuilder.CreateBox(
      `${name}_plank_${idx}`,
      { width: width * 1.06, height: 0.14, depth: 0.045 },
      scene,
    );
    plank.position.set(0, heights[idx], zOffset + idx * 0.012);
    plank.rotation.z = ang;
    plank.material = idx === 1 ? hazardMat : woodMat;
    plank.parent = parent;
  });
}

function createBottleMesh(
  name: string,
  scene: Scene,
  glassMat: PBRMaterial,
  capMat: PBRMaterial,
  labelMat: PBRMaterial,
): TransformNode {
  const root = new TransformNode(name, scene);

  const body = MeshBuilder.CreateCylinder(
    `${name}_body`,
    { diameter: 0.088, height: 0.17, tessellation: 12 },
    scene,
  );
  body.position.y = 0.085;
  body.material = glassMat;
  body.parent = root;

  const shoulder = MeshBuilder.CreateCylinder(
    `${name}_sh`,
    { diameterTop: 0.036, diameterBottom: 0.088, height: 0.045, tessellation: 12 },
    scene,
  );
  shoulder.position.y = 0.192;
  shoulder.material = glassMat;
  shoulder.parent = root;

  const neck = MeshBuilder.CreateCylinder(
    `${name}_nk`,
    { diameter: 0.034, height: 0.06, tessellation: 10 },
    scene,
  );
  neck.position.y = 0.244;
  neck.material = glassMat;
  neck.parent = root;

  const cap = MeshBuilder.CreateCylinder(
    `${name}_cap`,
    { diameter: 0.038, height: 0.022, tessellation: 10 },
    scene,
  );
  cap.position.y = 0.28;
  cap.material = capMat;
  cap.parent = root;

  const lbl = MeshBuilder.CreateCylinder(
    `${name}_lbl`,
    { diameter: 0.09, height: 0.075, tessellation: 12 },
    scene,
  );
  lbl.position.y = 0.095;
  lbl.material = labelMat;
  lbl.parent = root;

  return root;
}

function createLockerHideout(
  name: string,
  scene: Scene,
  bodyMat: PBRMaterial,
  doorMat: PBRMaterial,
  steelMat: PBRMaterial,
  darkMat: PBRMaterial,
  textures: HospitalTextureLibrary,
  shadowGen: ShadowGenerator | null,
): { root: TransformNode; doorPivot: TransformNode } {
  const root = new TransformNode(name, scene);
  const cs = makeContactShadow(name + 'Shadow', scene, textures.contactShadow, 1.05, 1.05);
  cs.parent = root;

  const w = 0.78;
  const h = 2.08;
  const d = 0.72;

  const back = MeshBuilder.CreateBox(`${name}_back`, { width: w, height: h, depth: 0.05 }, scene);
  back.position.set(0, h / 2, -d / 2 + 0.025);
  back.material = bodyMat;
  back.receiveShadows = true;
  back.parent = root;
  shadowGen?.addShadowCaster(back);

  [-w / 2 + 0.025, w / 2 - 0.025].forEach((sx, i) => {
    const side = MeshBuilder.CreateBox(`${name}_s${i}`, { width: 0.05, height: h, depth: d }, scene);
    side.position.set(sx, h / 2, 0);
    side.material = bodyMat;
    side.receiveShadows = true;
    side.parent = root;
    shadowGen?.addShadowCaster(side);
  });

  const top = MeshBuilder.CreateBox(`${name}_top`, { width: w, height: 0.06, depth: d }, scene);
  top.position.set(0, h - 0.03, 0);
  top.material = bodyMat;
  top.parent = root;

  const base = MeshBuilder.CreateBox(`${name}_base`, { width: w, height: 0.08, depth: d }, scene);
  base.position.set(0, 0.04, 0);
  base.material = darkMat;
  base.parent = root;

  // Hinged louvered door with real horizontal vision slits (Outlast 2 style)
  const doorPivot = new TransformNode(`${name}_doorPivot`, scene);
  doorPivot.position.set(-w / 2 + 0.05, 0.08, d / 2 - 0.02);
  doorPivot.parent = root;

  const leafW = w - 0.1;
  const cx = leafW / 2;

  const lowerPanel = MeshBuilder.CreateBox(`${name}_lp`, { width: leafW, height: 1.24, depth: 0.04 }, scene);
  lowerPanel.position.set(cx, 0.62, 0);
  lowerPanel.material = doorMat;
  lowerPanel.receiveShadows = true;
  lowerPanel.parent = doorPivot;

  const upperPanel = MeshBuilder.CreateBox(`${name}_up`, { width: leafW, height: 0.24, depth: 0.04 }, scene);
  upperPanel.position.set(cx, 1.82, 0);
  upperPanel.material = doorMat;
  upperPanel.parent = doorPivot;

  [-leafW / 2 + 0.03, leafW / 2 - 0.03].forEach((sx, i) => {
    const stile = MeshBuilder.CreateBox(`${name}_st${i}`, { width: 0.06, height: 0.48, depth: 0.04 }, scene);
    stile.position.set(cx + sx, 1.48, 0);
    stile.material = doorMat;
    stile.parent = doorPivot;
  });

  // Louvered slats at eye level (y ~ 1.32..1.66) so looking from inside reveals horizontal slits
  [1.34, 1.44, 1.54, 1.64].forEach((sy, i) => {
    const slat = MeshBuilder.CreateBox(`${name}_slat${i}`, { width: leafW - 0.1, height: 0.035, depth: 0.045 }, scene);
    slat.position.set(cx, sy, 0);
    slat.rotation.x = 0.28;
    slat.material = darkMat;
    slat.parent = doorPivot;
  });

  const handle = MeshBuilder.CreateBox(`${name}_hdl`, { width: 0.035, height: 0.16, depth: 0.055 }, scene);
  handle.position.set(leafW - 0.09, 1.0, 0.035);
  handle.material = steelMat;
  handle.parent = doorPivot;

  return { root, doorPivot };
}

function createBedHideout(
  name: string,
  scene: Scene,
  steelMat: PBRMaterial,
  mattressMat: PBRMaterial,
  blanketMat: PBRMaterial,
  darkMat: PBRMaterial,
  textures: HospitalTextureLibrary,
  shadowGen: ShadowGenerator | null,
): TransformNode {
  const root = new TransformNode(name, scene);
  const cs = makeContactShadow(name + 'Shadow', scene, textures.contactShadow, 1.35, 2.35);
  cs.parent = root;

  const bw = 1.02;
  const bd = 2.04;

  // 4 corners legs raising bed frame to y=0.58 for clear under-bed crawl hideout
  [
    [-bw / 2 + 0.05, -bd / 2 + 0.06],
    [bw / 2 - 0.05, -bd / 2 + 0.06],
    [-bw / 2 + 0.05, bd / 2 - 0.06],
    [bw / 2 - 0.05, bd / 2 - 0.06],
  ].forEach(([lx, lz], i) => {
    const leg = MeshBuilder.CreateCylinder(`${name}_leg${i}`, { diameter: 0.05, height: 0.58, tessellation: 8 }, scene);
    leg.position.set(lx, 0.29, lz);
    leg.material = steelMat;
    leg.parent = root;
  });

  const frame = MeshBuilder.CreateBox(`${name}_frm`, { width: bw, height: 0.07, depth: bd }, scene);
  frame.position.set(0, 0.59, 0);
  frame.material = darkMat;
  frame.receiveShadows = true;
  frame.parent = root;
  shadowGen?.addShadowCaster(frame);

  const mattress = MeshBuilder.CreateBox(`${name}_mat`, { width: bw - 0.06, height: 0.16, depth: bd - 0.08 }, scene);
  mattress.position.set(0, 0.71, 0);
  mattress.material = mattressMat;
  mattress.receiveShadows = true;
  mattress.parent = root;
  shadowGen?.addShadowCaster(mattress);

  // Draped sheet / blanket hanging partly down the sides (iconic Outlast under-bed framing)
  const blanket = MeshBuilder.CreateBox(`${name}_blk`, { width: bw + 0.04, height: 0.24, depth: bd * 0.62 }, scene);
  blanket.position.set(0, 0.68, 0.24);
  blanket.material = blanketMat;
  blanket.parent = root;

  const pillow = MeshBuilder.CreateBox(`${name}_pil`, { width: 0.58, height: 0.1, depth: 0.34 }, scene);
  pillow.position.set(0, 0.84, -bd / 2 + 0.28);
  pillow.material = blanketMat;
  pillow.parent = root;

  const headRail = MeshBuilder.CreateBox(`${name}_hdr`, { width: bw, height: 0.55, depth: 0.05 }, scene);
  headRail.position.set(0, 0.88, -bd / 2 + 0.03);
  headRail.material = steelMat;
  headRail.parent = root;

  const footRail = MeshBuilder.CreateBox(`${name}_ftr`, { width: bw, height: 0.38, depth: 0.05 }, scene);
  footRail.position.set(0, 0.79, bd / 2 - 0.03);
  footRail.material = steelMat;
  footRail.parent = root;

  return root;
}

function createMonsterRig(scene: Scene, shadowGen: ShadowGenerator | null): MonsterRig {
  const root = new TransformNode('patient04Monster', scene);
  root.position.set(0, 0, -14.0);

  const skinMat = new PBRMaterial('monsterSkin', scene);
  skinMat.albedoColor = new Color3(0.16, 0.19, 0.18);
  skinMat.metallic = 0.05;
  skinMat.roughness = 0.78;
  skinMat.maxSimultaneousLights = 4;

  const gownMat = new PBRMaterial('monsterGown', scene);
  gownMat.albedoColor = new Color3(0.1, 0.14, 0.15);
  gownMat.metallic = 0.02;
  gownMat.roughness = 0.92;
  gownMat.maxSimultaneousLights = 4;

  const eyeMat = new StandardMaterial('monsterEyes', scene);
  eyeMat.diffuseColor = new Color3(1.0, 0.25, 0.18);
  eyeMat.emissiveColor = new Color3(1.0, 0.18, 0.12);
  eyeMat.disableLighting = true;

  // Hunched gaunt torso
  const torso = MeshBuilder.CreateCylinder(
    'mTorso',
    { diameterTop: 0.46, diameterBottom: 0.34, height: 0.92, tessellation: 10 },
    scene,
  );
  torso.position.set(0, 1.32, 0.04);
  torso.rotation.x = 0.18;
  torso.material = gownMat;
  torso.parent = root;

  const pelvis = MeshBuilder.CreateBox('mPelvis', { width: 0.34, height: 0.22, depth: 0.24 }, scene);
  pelvis.position.set(0, 0.84, 0);
  pelvis.material = gownMat;
  pelvis.parent = root;

  // Head pivot
  const head = new TransformNode('mHeadPivot', scene);
  head.position.set(0, 1.82, 0.12);
  head.parent = root;

  const skull = MeshBuilder.CreateSphere('mSkull', { diameter: 0.28, segments: 10 }, scene);
  skull.scaling.set(0.86, 1.16, 0.95);
  skull.material = skinMat;
  skull.parent = head;

  [-0.055, 0.055].forEach((ex, i) => {
    const eye = MeshBuilder.CreateSphere(`mEye_${i}`, { diameter: 0.042, segments: 6 }, scene);
    eye.position.set(ex, 0.03, 0.115);
    eye.material = eyeMat;
    eye.parent = head;
  });

  // Elongated arms
  const makeArm = (side: -1 | 1): TransformNode => {
    const armPivot = new TransformNode(`mArm_${side}`, scene);
    armPivot.position.set(side * 0.27, 1.66, 0.08);
    armPivot.parent = root;

    const upper = MeshBuilder.CreateCylinder(
      `mArmU_${side}`,
      { diameterTop: 0.09, diameterBottom: 0.07, height: 0.92, tessellation: 8 },
      scene,
    );
    upper.position.set(0, -0.44, 0.08);
    upper.rotation.x = -0.28;
    upper.material = skinMat;
    upper.parent = armPivot;

    const claw = MeshBuilder.CreateBox(`mClaw_${side}`, { width: 0.07, height: 0.18, depth: 0.08 }, scene);
    claw.position.set(0, -0.92, 0.22);
    claw.rotation.x = -0.35;
    claw.material = skinMat;
    claw.parent = armPivot;

    return armPivot;
  };

  // Stalking legs
  const makeLeg = (side: -1 | 1): TransformNode => {
    const legPivot = new TransformNode(`mLeg_${side}`, scene);
    legPivot.position.set(side * 0.13, 0.82, 0);
    legPivot.parent = root;

    const legMesh = MeshBuilder.CreateCylinder(
      `mLegM_${side}`,
      { diameterTop: 0.12, diameterBottom: 0.08, height: 0.82, tessellation: 8 },
      scene,
    );
    legMesh.position.y = -0.41;
    legMesh.material = skinMat;
    legMesh.parent = legPivot;

    return legPivot;
  };

  const torsoMesh = torso;
  shadowGen?.addShadowCaster(torsoMesh);
  shadowGen?.addShadowCaster(pelvis);
  shadowGen?.addShadowCaster(skull);

  const leftArm = makeArm(-1);
  const rightArm = makeArm(1);
  const leftLeg = makeLeg(-1);
  const rightLeg = makeLeg(1);
  [leftArm, rightArm, leftLeg, rightLeg].forEach((pivot) => {
    pivot.getChildMeshes().forEach((m) => shadowGen?.addShadowCaster(m));
  });

  return {
    root,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    eyeMat,
  };
}

export function buildHospitalWorld(
  engine: Engine,
  isSoftwareGl: boolean,
  initialConfig: RenderQualityConfig,
  chapterId: ChapterId = 'ch1',
  hasPremiumPass = false,
): HospitalWorld {
  const isMobileTier =
    isSoftwareGl || initialConfig.tier === 'balanced' || initialConfig.tier === 'performance';

  const scene = new Scene(engine);
  scene.clearColor = new Color4(0.008, 0.014, 0.024, 1);
  scene.fogMode = Scene.FOGMODE_EXP2;
  scene.fogColor = new Color3(0.022, 0.035, 0.052);
  scene.fogDensity = isMobileTier ? 0.04 : 0.046;

  const camera = new UniversalCamera('playerCam', new Vector3(0, 1.62, 13.6), scene);
  camera.minZ = 0.06;
  camera.maxZ = 75;
  camera.fov = 1.04;
  camera.rotation.set(0, Math.PI, 0);

  const textures = buildHospitalTextures(engine, scene, isMobileTier);
  scene.environmentTexture = textures.envCube;
  scene.environmentIntensity = 0.44;

  const hemi = new HemisphericLight('hemi', new Vector3(0, 1, 0), scene);
  hemi.diffuse = new Color3(0.42, 0.56, 0.74);
  hemi.groundColor = new Color3(0.05, 0.07, 0.1);
  hemi.intensity = isMobileTier ? 0.32 : 0.35;

  // Cold exterior moonlight illuminating drawn 3D buildings, courtyard & skylight
  const moonLight = new DirectionalLight('moonLight', new Vector3(0.36, -0.82, 0.44), scene);
  moonLight.position = new Vector3(-14, 24, -18);
  moonLight.diffuse = new Color3(0.36, 0.54, 0.82);
  moonLight.specular = new Color3(0.28, 0.42, 0.65);
  moonLight.intensity = isMobileTier ? 0.85 : 1.05;

  let moonShadowGen: ShadowGenerator | null = null;
  if (!isSoftwareGl && !isMobileTier) {
    moonShadowGen = new ShadowGenerator(1024, moonLight);
    moonShadowGen.usePercentageCloserFiltering = true;
    moonShadowGen.bias = 0.0012;
    moonShadowGen.normalBias = 0.03;
  }

  const flashlight = new SpotLight(
    'flashlight',
    new Vector3(0.14, -0.1, 0.06),
    new Vector3(0, -0.02, 1),
    Math.PI / 4.2,
    18,
    scene,
  );
  flashlight.diffuse = new Color3(0.93, 0.97, 1.0);
  flashlight.specular = new Color3(0.95, 0.98, 1.0);
  flashlight.intensity = isMobileTier ? 14.5 : 16.0;
  flashlight.range = isMobileTier ? 21 : 25;
  flashlight.parent = camera;

  let shadowGen: ShadowGenerator | null = null;
  if (!isSoftwareGl) {
    shadowGen = new ShadowGenerator(initialConfig.shadowMapSize, flashlight);
    shadowGen.usePercentageCloserFiltering = initialConfig.pcfShadows;
    shadowGen.bias = 0.0007;
    shadowGen.normalBias = 0.025;
  }

  const flashCone = createVolumetricCone('flashCone', scene, new Color3(0.62, 0.78, 0.96), 5.8, 2.8, 0.048);
  flashCone.rotation.x = -Math.PI / 2;
  flashCone.position.set(0.14, -0.1, 0.14);
  flashCone.parent = camera;

  const bounceLight = new PointLight('lumenBounce', new Vector3(0, 1.6, 8), scene);
  bounceLight.diffuse = new Color3(0.55, 0.74, 0.92);
  bounceLight.intensity = 1.25;
  bounceLight.range = 9.5;

  const maxLights = isMobileTier ? 4 : 8;
  const floorMat = createPbrMaterial('floorMat', scene, textures.floor, 1.0, 0.35, 0.62, maxLights);
  const wallMat = createPbrMaterial('wallMat', scene, textures.wall, 1.0, 0.3, 0.42, maxLights);
  const ceilingMat = createPbrMaterial('ceilingMat', scene, textures.ceiling, 1.0, 0.3, 0.35, maxLights);
  const steelMat = createPbrMaterial('steelMat', scene, textures.brushedMetal, 0.85, 0.95, 0.95, maxLights);
  steelMat.albedoColor = new Color3(0.75, 0.8, 0.86);
  if (!isMobileTier) {
    steelMat.anisotropy.isEnabled = true;
    steelMat.anisotropy.intensity = 0.7;
  }

  // High-resolution PBR materials for concrete structures, wood barricades, hospital doors & exterior buildings
  const concreteMat = createPbrMaterial('concreteMat', scene, textures.concrete, 1.0, 0.25, 0.38, maxLights);
  const woodPlankMat = createPbrMaterial('woodPlankMat', scene, textures.wood, 1.0, 0.2, 0.32, maxLights);
  const doorMat = createPbrMaterial('doorMat', scene, textures.doorLaminate, 0.95, 0.45, 0.5, maxLights);
  const buildingMat = createPbrMaterial('buildingMat', scene, textures.buildingFacade, 0.95, 0.35, 0.45, maxLights);

  const makeSimplePbr = (name: string, albedo: Color3, metallic: number, roughness: number) => {
    const m = new PBRMaterial(name, scene);
    m.albedoColor = albedo;
    m.metallic = metallic;
    m.roughness = roughness;
    m.maxSimultaneousLights = maxLights;
    return m;
  };

  const darkMetalMat = makeSimplePbr('darkMetal', new Color3(0.12, 0.15, 0.18), 0.78, 0.42);
  const mattressMat = makeSimplePbr('mattress', new Color3(0.24, 0.3, 0.34), 0.02, 0.84);
  const seatMat = makeSimplePbr('seatMat', new Color3(0.11, 0.14, 0.18), 0.05, 0.82);
  const rubberMat = makeSimplePbr('rubberMat', new Color3(0.08, 0.09, 0.11), 0.05, 0.92);
  const redBodyMat = makeSimplePbr('redBody', new Color3(0.45, 0.14, 0.15), 0.28, 0.38);
  const hazardMat = makeSimplePbr('hazardMat', new Color3(0.58, 0.38, 0.1), 0.1, 0.6);

  const glassMat = makeSimplePbr('glassMat', new Color3(0.62, 0.78, 0.88), 0.08, 0.08);
  glassMat.alpha = 0.34;
  if (!isMobileTier) {
    glassMat.clearCoat.isEnabled = true;
    glassMat.clearCoat.intensity = 1.0;
  }

  const monitorMat = new StandardMaterial('monitorMat', scene);
  monitorMat.diffuseTexture = textures.monitorScreen;
  monitorMat.emissiveTexture = textures.monitorScreen;
  monitorMat.disableLighting = true;

  const mirrorRenderList: AbstractMesh[] = [];
  const raycastMeshes: AbstractMesh[] = [];
  const colliders: Aabb2D[] = [];
  const staticFreezeMeshes: AbstractMesh[] = [];

  const registerWall = (
    name: string,
    w: number,
    h: number,
    d: number,
    x: number,
    y: number,
    z: number,
    mat: PBRMaterial = wallMat,
    addCollider = true,
  ): Mesh => {
    const m = MeshBuilder.CreateBox(name, { width: w, height: h, depth: d }, scene);
    m.position.set(x, y, z);
    m.material = mat;
    m.receiveShadows = true;
    raycastMeshes.push(m);
    mirrorRenderList.push(m);
    staticFreezeMeshes.push(m);
    if (addCollider) {
      colliders.push({
        minX: x - w / 2,
        maxX: x + w / 2,
        minZ: z - d / 2,
        maxZ: z + d / 2,
      });
    }
    return m;
  };

  // 1. FLOORS & CEILINGS (Main corridor + 4 discoverable side rooms)
  const makeFloor = (name: string, w: number, h: number, x: number, z: number) => {
    const f = MeshBuilder.CreateGround(name, { width: w, height: h }, scene);
    f.position.set(x, 0.001, z);
    f.material = floorMat;
    f.receiveShadows = true;
    raycastMeshes.push(f);
    staticFreezeMeshes.push(f);
  };
  const makeCeiling = (name: string, w: number, h: number, x: number, z: number) => {
    const c = MeshBuilder.CreateGround(name, { width: w, height: h }, scene);
    c.rotation.x = Math.PI;
    c.position.set(x, 3.6, z);
    c.material = ceilingMat;
    raycastMeshes.push(c);
    mirrorRenderList.push(c);
    staticFreezeMeshes.push(c);
  };

  // Main corridor floor & split ceiling with Atrium Skylight bay (Z: -2.2 -> +2.2)
  makeFloor('mainFloor', 4.6, 32.4, 0, 0);
  makeCeiling('mainCeilN', 4.6, 14.0, 0, -9.2);
  makeCeiling('mainCeilS', 4.6, 14.0, 0, 9.2);

  // Skylight frame & recessed skylight glazing letting moonlight + exterior towers show above
  const skylightFrame = MeshBuilder.CreateBox('skylightFrame', { width: 4.4, height: 0.18, depth: 0.18 }, scene);
  skylightFrame.position.set(0, 3.62, -2.2);
  skylightFrame.material = darkMetalMat;
  staticFreezeMeshes.push(skylightFrame);
  const skylightFrameS = skylightFrame.clone('skylightFrameS');
  skylightFrameS.position.z = 2.2;
  staticFreezeMeshes.push(skylightFrameS);

  [-1.2, 0, 1.2].forEach((mx, idx) => {
    const mullion = MeshBuilder.CreateBox(`skyMull_${idx}`, { width: 0.08, height: 0.14, depth: 4.4 }, scene);
    mullion.position.set(mx, 3.68, 0);
    mullion.material = darkMetalMat;
    moonShadowGen?.addShadowCaster(mullion);
    staticFreezeMeshes.push(mullion);
  });
  const skyGlass = MeshBuilder.CreateGround('skyGlass', { width: 4.5, height: 4.4 }, scene);
  skyGlass.rotation.x = Math.PI;
  skyGlass.position.set(0, 3.74, 0);
  skyGlass.material = glassMat;
  staticFreezeMeshes.push(skyGlass);

  // Zone 1: Réception / Poste de soins (East-South, open)
  makeFloor('eastFloor', 3.4, 4.8, 3.9, 4.5);
  makeCeiling('eastCeil', 3.4, 4.8, 3.9, 4.5);

  // Zone 2: Salle d'Observation (West-Center, unlocked door)
  makeFloor('westObsFloor', 3.6, 4.8, -4.0, -4.5);
  makeCeiling('westObsCeil', 3.6, 4.8, -4.0, -4.5);

  // Zone 3: Bloc Chirurgical (East-North, locked with cle_chirurgie)
  makeFloor('surgFloor', 4.0, 5.6, 4.2, -9.8);
  makeCeiling('surgCeil', 4.0, 5.6, 4.2, -9.8);

  // Zone 4: Local Générateur (West-South, locked with cle_generateur)
  makeFloor('genFloor', 3.8, 5.2, -4.1, 5.2);
  makeCeiling('genCeil', 3.8, 5.2, -4.1, 5.2);

  // 2. WALLS & ROOM ENCLOSURES (clean openings for each room + reinforced exterior windows)
  // West Wall segments
  registerWall('wWestN', 0.24, 3.6, 9.2, -2.32, 1.8, -11.4); // Z: -16.0 -> -6.8
  registerWall('wWestObsF1', 0.24, 3.6, 1.6, -2.32, 1.8, -6.0); // Z: -6.8 -> -5.2
  registerWall('wWestObsF2', 0.24, 3.6, 1.6, -2.32, 1.8, -3.0); // Z: -3.8 -> -2.2
  registerWall('wWestMid', 0.24, 3.6, 6.75, -2.32, 1.8, 1.175); // Z: -2.2 -> 4.55
  registerWall('wWestS', 0.24, 3.6, 10.15, -2.32, 1.8, 10.925); // Z: 5.85 -> 16.0

  // West Observation Room perimeter with Reinforced Courtyard Window looking at exterior buildings & Gaussian Scan
  registerWall('wWestAlcBackLow', 0.24, 1.05, 5.0, -5.82, 0.525, -4.5);
  registerWall('wWestAlcBackTop', 0.24, 0.72, 5.0, -5.82, 3.24, -4.5);
  registerWall('wWestAlcBackPilN', 0.24, 1.85, 0.9, -5.82, 1.97, -6.55);
  registerWall('wWestAlcBackPilS', 0.24, 1.85, 0.9, -5.82, 1.97, -2.45);
  colliders.push({ minX: -5.98, maxX: -5.68, minZ: -6.9, maxZ: -2.1 });

  const obsWinGlass = MeshBuilder.CreateBox('obsWinGlass', { width: 0.04, height: 1.82, depth: 3.2 }, scene);
  obsWinGlass.position.set(-5.82, 1.96, -4.5);
  obsWinGlass.material = glassMat;
  staticFreezeMeshes.push(obsWinGlass);
  [-5.3, -4.5, -3.7].forEach((mz, i) => {
    const bar = MeshBuilder.CreateBox(`obsMull_${i}`, { width: 0.09, height: 1.84, depth: 0.06 }, scene);
    bar.position.set(-5.82, 1.96, mz);
    bar.material = darkMetalMat;
    moonShadowGen?.addShadowCaster(bar);
    staticFreezeMeshes.push(bar);
  });

  registerWall('wWestAlcN', 3.6, 3.6, 0.24, -4.0, 1.8, -6.92);
  registerWall('wWestAlcS', 3.6, 3.6, 0.24, -4.0, 1.8, -2.08);

  // West Generator Room perimeter (X: -6.0 -> -2.32, Z: 2.6 -> 7.8)
  registerWall('wGenBack', 0.24, 3.6, 5.4, -6.02, 1.8, 5.2);
  registerWall('wGenN', 3.8, 3.6, 0.24, -4.1, 1.8, 2.58);
  registerWall('wGenS', 3.8, 3.6, 0.24, -4.1, 1.8, 7.82);

  // East Wall segments
  registerWall('wEastNN', 0.24, 3.6, 5.55, 2.32, 1.8, -13.225);
  registerWall('wEastMid', 0.24, 3.6, 11.35, 2.32, 1.8, -3.475);
  registerWall('wEastS', 0.24, 3.6, 9.2, 2.32, 1.8, 11.4);

  // East Reception Room perimeter
  registerWall('wEastAlcBack', 0.24, 3.6, 4.8, 5.52, 1.8, 4.5);
  registerWall('wEastAlcN', 3.4, 3.6, 0.24, 3.9, 1.8, 2.08);
  registerWall('wEastAlcS', 3.4, 3.6, 0.24, 3.9, 1.8, 6.92);

  // East Surgery Room perimeter (X: 2.32 -> 6.2, Z: -12.6 -> -7.0)
  registerWall('wSurgBack', 0.24, 3.6, 5.8, 6.22, 1.8, -9.8);
  registerWall('wSurgN', 4.0, 3.6, 0.24, 4.2, 1.8, -12.62);
  registerWall('wSurgS', 4.0, 3.6, 0.24, 4.2, 1.8, -6.98);

  // Corridor End Walls (North end has wired observation window on left + openable airlock frame in center)
  registerWall('wNorthEndR', 1.4, 3.6, 0.28, 1.7, 1.8, -16.14);
  registerWall('wNorthEndCenterTop', 2.0, 1.15, 0.28, 0, 3.025, -16.14);
  registerWall('wNorthEndLow', 1.4, 1.12, 0.28, -1.7, 0.56, -16.14);
  registerWall('wNorthEndTop', 1.4, 0.75, 0.28, -1.7, 3.22, -16.14);
  colliders.push({ minX: -2.45, maxX: 2.45, minZ: -16.3, maxZ: -15.98 });
  const northSlitGlass = MeshBuilder.CreateBox('northSlitGlass', { width: 1.25, height: 1.72, depth: 0.04 }, scene);
  northSlitGlass.position.set(-1.62, 1.98, -16.14);
  northSlitGlass.material = glassMat;
  staticFreezeMeshes.push(northSlitGlass);
  [-1.9, -1.35].forEach((nx, i) => {
    const bar = MeshBuilder.CreateBox(`northSlitBar_${i}`, { width: 0.05, height: 1.72, depth: 0.09 }, scene);
    bar.position.set(nx, 1.98, -16.14);
    bar.material = darkMetalMat;
    staticFreezeMeshes.push(bar);
  });

  registerWall('wSouthEnd', 4.8, 3.6, 0.28, 0, 1.8, 16.14);

  // Structural pilasters & ceiling beams
  const ribZPositions = [-14, -10, -7, -2, 2, 7, 11, 14.5];
  ribZPositions.forEach((rz, idx) => {
    const beam = MeshBuilder.CreateBox(`beam_${idx}`, { width: 4.45, height: 0.28, depth: 0.24 }, scene);
    beam.position.set(0, 3.46, rz);
    beam.material = concreteMat;
    beam.receiveShadows = true;
    mirrorRenderList.push(beam);
    staticFreezeMeshes.push(beam);

    [-2.14, 2.14].forEach((sx, si) => {
      if (sx < 0 && ((rz > -6.6 && rz < -2.4) || (rz > 3.8 && rz < 6.6))) return;
      if (sx > 0 && ((rz > 2.4 && rz < 6.6) || (rz > -11.0 && rz < -8.5))) return;
      const pil = MeshBuilder.CreateBox(`pil_${idx}_${si}`, { width: 0.16, height: 3.6, depth: 0.26 }, scene);
      pil.position.set(sx, 1.8, rz);
      pil.material = concreteMat;
      pil.receiveShadows = true;
      shadowGen?.addShadowCaster(pil);
      mirrorRenderList.push(pil);
      staticFreezeMeshes.push(pil);
    });
  });

  // Crash rails & conduits
  [-1.72, -1.56, 1.62].forEach((px, i) => {
    const pipe = MeshBuilder.CreateTube(
      `pipe_${i}`,
      {
        path: [new Vector3(px, 3.24, -15.8), new Vector3(px, 3.24, 15.8)],
        radius: 0.032,
        tessellation: 8,
      },
      scene,
    );
    pipe.material = px > 0 ? darkMetalMat : steelMat;
    staticFreezeMeshes.push(pipe);
  });

  const masterBracket = MeshBuilder.CreateBox('masterBracket', { width: 0.42, height: 0.05, depth: 0.06 }, scene);
  masterBracket.material = darkMetalMat;
  masterBracket.isVisible = false;
  for (let i = 0; i < 18; i++) {
    const z = -14.8 + i * 1.75;
    const bL = masterBracket.createInstance(`brkL_${i}`);
    bL.position.set(-1.64, 3.3, z);
    staticFreezeMeshes.push(bL);
    const bR = masterBracket.createInstance(`brkR_${i}`);
    bR.position.set(1.62, 3.3, z);
    bR.scaling.x = 0.55;
    staticFreezeMeshes.push(bR);
  }

  const masterShard = MeshBuilder.CreatePolyhedron('masterShard', { type: 2, size: 0.04 }, scene);
  masterShard.material = concreteMat;
  masterShard.isVisible = false;
  const shardCount = isMobileTier ? 24 : 40;
  for (let i = 0; i < shardCount; i++) {
    const sh = masterShard.createInstance(`shard_${i}`);
    const sx = (Math.sin(i * 19.3) * 0.5 + 0.5) * 3.8 - 1.9;
    const sz = -14.5 + (i / shardCount) * 29.0;
    const sc = 0.65 + (i % 5) * 0.22;
    sh.position.set(sx, 0.012, sz);
    sh.rotation.set(i * 0.7, i * 1.3, i * 0.4);
    sh.scaling.set(sc * 1.3, sc * 0.32, sc);
    staticFreezeMeshes.push(sh);
  }

  // 3. PUDDLES
  const puddles: PuddleZone[] = [
    { x: -0.65, z: 10.2, radius: 0.88 },
    { x: 0.72, z: 6.1, radius: 0.96 },
    { x: -0.5, z: 1.4, radius: 0.8 },
    { x: 0.45, z: -2.8, radius: 1.05 },
    { x: -0.82, z: -7.5, radius: 0.88 },
    { x: 0.35, z: -11.9, radius: 0.94 },
    { x: -0.25, z: -14.2, radius: 0.76 },
  ];

  let mirrorTex: MirrorTexture | null = null;
  const ensureMirrorTexture = (): MirrorTexture | null => {
    if (isSoftwareGl) return null;
    if (!mirrorTex) {
      mirrorTex = new MirrorTexture('puddleMirror', 512, scene, true);
      mirrorTex.mirrorPlane = new Plane(0, -1, 0, 0.009);
      mirrorTex.renderList = mirrorRenderList;
      mirrorTex.adaptiveBlurKernel = 18;
      mirrorTex.level = 0.78;
    }
    return mirrorTex;
  };
  if (initialConfig.mirrorReflections) ensureMirrorTexture();

  const puddleMat = new PBRMaterial('puddleMat', scene);
  puddleMat.albedoColor = new Color3(0.03, 0.06, 0.09);
  puddleMat.metallic = 0.14;
  puddleMat.roughness = 0.05;
  puddleMat.alpha = 0.78;
  puddleMat.environmentIntensity = 1.65;
  puddleMat.maxSimultaneousLights = maxLights;
  if (!isMobileTier) {
    puddleMat.clearCoat.isEnabled = true;
    puddleMat.clearCoat.intensity = 1.0;
    puddleMat.clearCoat.roughness = 0.03;
  }
  puddleMat.bumpTexture = initialConfig.puddleRipples ? textures.floor.bump : null;
  if (puddleMat.bumpTexture) puddleMat.bumpTexture.level = 0.12;
  puddleMat.zOffset = -2;
  if (mirrorTex && initialConfig.mirrorReflections) {
    puddleMat.reflectionTexture = mirrorTex;
  }

  puddles.forEach((pz, idx) => {
    const disc = MeshBuilder.CreateDisc(`puddle_${idx}`, { radius: pz.radius, tessellation: 20 }, scene);
    disc.rotation.x = Math.PI / 2;
    disc.scaling.set(1.18, 0.78 + (idx % 2) * 0.25, 1);
    disc.position.set(pz.x, 0.009, pz.z);
    disc.material = puddleMat;
    disc.receiveShadows = true;
    disc.isPickable = false;
    staticFreezeMeshes.push(disc);
  });

  // 4. CEILING FLUORESCENTS + SIDE ROOM LIGHTS + EMERGENCY BEACONS
  const fixtures: PracticalFixture[] = [];
  const volumetricCones: Mesh[] = [];

  const addFluoFixture = (name: string, x: number, z: number, intensity: number, phase: number, tint?: Color3) => {
    const housing = MeshBuilder.CreateBox(`${name}_h`, { width: 1.18, height: 0.08, depth: 0.3 }, scene);
    housing.position.set(x, 3.55, z);
    housing.material = darkMetalMat;
    staticFreezeMeshes.push(housing);

    const tubeColor = tint ?? new Color3(0.55, 0.76, 0.96);
    const tubeMat = new StandardMaterial(`${name}_tm`, scene);
    tubeMat.diffuseColor = new Color3(0.8, 0.9, 1.0);
    tubeMat.emissiveColor = tubeColor.clone();
    tubeMat.disableLighting = true;

    [-0.055, 0.055].forEach((tz, ti) => {
      const tube = MeshBuilder.CreateCylinder(`${name}_t_${ti}`, { diameter: 0.044, height: 1.04, tessellation: 8 }, scene);
      tube.rotation.z = Math.PI / 2;
      tube.position.set(x, 3.505, z + tz);
      tube.material = tubeMat;
      mirrorRenderList.push(tube);
      staticFreezeMeshes.push(tube);
    });

    const light = new PointLight(`${name}_pt`, new Vector3(x, 3.3, z), scene);
    light.diffuse = tubeColor.clone();
    light.intensity = intensity;
    light.range = 9.0;

    const cone = createVolumetricCone(`${name}_cone`, scene, tubeColor, 3.35, 3.2, 0.042);
    cone.position.set(x, 3.48, z);
    staticFreezeMeshes.push(cone);
    volumetricCones.push(cone);

    fixtures.push({
      light,
      tubeMat,
      coneMesh: cone,
      baseIntensity: intensity,
      phase,
      flickerCooldown: 1.5 + phase,
      isFlickering: false,
      zPos: z,
    });
  };

  [12.0, 6.2, 0.8, -4.6, -10.2].forEach((fz, i) => {
    addFluoFixture(`fluo_${i}`, 0, fz, i === 2 ? 0.9 : 2.3, i * 1.93 + 0.5);
  });
  // Side room lights (automatically culled when out of range on mobile)
  addFluoFixture('fluo_surg', 4.2, -9.8, 2.2, 2.7, new Color3(0.45, 0.88, 0.78));
  addFluoFixture('fluo_gen', -4.1, 5.2, 1.85, 4.1, new Color3(0.95, 0.62, 0.3));

  const addEmergencyBeacon = (name: string, x: number, y: number, z: number, intensity: number, phase: number) => {
    const cage = MeshBuilder.CreateCylinder(name + '_cage', { diameter: 0.18, height: 0.14, tessellation: 10 }, scene);
    cage.position.set(x, y, z);
    cage.material = darkMetalMat;
    staticFreezeMeshes.push(cage);

    const bulbMat = new StandardMaterial(name + '_mat', scene);
    bulbMat.diffuseColor = new Color3(1.0, 0.55, 0.25);
    bulbMat.emissiveColor = new Color3(1.0, 0.42, 0.14);
    bulbMat.disableLighting = true;

    const bulb = MeshBuilder.CreateSphere(name + '_bulb', { diameter: 0.13, segments: 8 }, scene);
    bulb.position.set(x, y - 0.03, z);
    bulb.material = bulbMat;
    mirrorRenderList.push(bulb);
    staticFreezeMeshes.push(bulb);

    const light = new PointLight(name + '_pt', new Vector3(x, y - 0.15, z + (z < 0 ? 0.35 : -0.35)), scene);
    light.diffuse = new Color3(1.0, 0.46, 0.2);
    light.intensity = intensity;
    light.range = 8.5;

    const cone = createVolumetricCone(name + '_cone', scene, new Color3(1.0, 0.46, 0.2), 2.2, 2.1, 0.035);
    cone.position.set(x, y - 0.05, z + (z < 0 ? 0.2 : -0.2));
    staticFreezeMeshes.push(cone);
    volumetricCones.push(cone);

    fixtures.push({
      light,
      tubeMat: bulbMat,
      coneMesh: cone,
      baseIntensity: intensity,
      phase,
      flickerCooldown: 0,
      isFlickering: false,
      isEmergency: true,
      zPos: z,
    });
  };

  addEmergencyBeacon('beaconNorth', 0, 3.22, -15.72, 2.6, 0.2);
  addEmergencyBeacon('beaconSouth', 0, 3.22, 15.72, 1.4, 2.4);

  const makeSignMesh = (
    name: string,
    w: number,
    h: number,
    tex: HospitalTextureLibrary['exitSign'],
    x: number,
    y: number,
    z: number,
    rotY = 0,
  ) => {
    const p = MeshBuilder.CreatePlane(name, { width: w, height: h }, scene);
    p.position.set(x, y, z);
    p.rotation.y = rotY;
    const m = new StandardMaterial(name + 'Mat', scene);
    m.diffuseTexture = tex;
    m.emissiveTexture = tex;
    m.disableLighting = true;
    p.material = m;
    mirrorRenderList.push(p);
    staticFreezeMeshes.push(p);
    return p;
  };

  makeSignMesh('exitSign', 1.15, 0.42, textures.exitSign, 0, 2.86, -15.96, Math.PI);
  makeSignMesh('sectorSign', 0.95, 0.35, textures.sectorSign, 2.19, 2.45, 0.4, Math.PI / 2);

  // Wing door plaques for architectural clarity
  makeSignMesh('plaqueRec', 0.72, 0.26, textures.plaqueReception, 2.19, 1.92, 1.65, Math.PI / 2);
  makeSignMesh('plaqueObs', 0.72, 0.26, textures.plaqueObservation, -2.19, 1.92, -3.25, -Math.PI / 2);
  makeSignMesh('plaqueSurg', 0.72, 0.26, textures.plaqueSurgery, 2.19, 1.92, -8.45, Math.PI / 2);
  makeSignMesh('plaqueGen', 0.72, 0.26, textures.plaqueGenerator, -2.19, 1.92, 3.95, -Math.PI / 2);

  // X-Ray Negatoscope (illuminated wall radiograph in Poste de Soins)
  const xrayFrame = MeshBuilder.CreateBox('xrayFrame', { width: 0.08, height: 0.68, depth: 1.06 }, scene);
  xrayFrame.position.set(5.36, 1.72, 4.5);
  xrayFrame.material = darkMetalMat;
  staticFreezeMeshes.push(xrayFrame);
  makeSignMesh('xrayPane', 0.96, 0.58, textures.xrayScreen, 5.31, 1.72, 4.5, Math.PI / 2);

  const hangingSignBox = MeshBuilder.CreateBox('hangBox', { width: 1.38, height: 0.44, depth: 0.06 }, scene);
  hangingSignBox.position.set(0, 2.95, -1.8);
  hangingSignBox.material = darkMetalMat;
  staticFreezeMeshes.push(hangingSignBox);
  [-0.52, 0.52].forEach((rx, i) => {
    const rod = MeshBuilder.CreateCylinder(`hangRod_${i}`, { diameter: 0.018, height: 0.44, tessellation: 6 }, scene);
    rod.position.set(rx, 3.38, -1.8);
    rod.material = steelMat;
    staticFreezeMeshes.push(rod);
  });
  makeSignMesh('dirSignF', 1.32, 0.39, textures.directionalSign, 0, 2.95, -1.765, Math.PI);
  makeSignMesh('dirSignB', 1.32, 0.39, textures.directionalSign, 0, 2.95, -1.835, 0);

  const fanHousing = MeshBuilder.CreateCylinder('fanH', { diameter: 0.82, height: 0.14, tessellation: 12 }, scene);
  fanHousing.position.set(0, 3.53, -13.2);
  fanHousing.material = darkMetalMat;
  staticFreezeMeshes.push(fanHousing);
  const fanHub = new TransformNode('fanHub', scene);
  fanHub.position.set(0, 3.44, -13.2);
  for (let i = 0; i < 4; i++) {
    const blade = MeshBuilder.CreateBox(`fanBlade_${i}`, { width: 0.34, height: 0.014, depth: 0.09 }, scene);
    blade.position.set(Math.cos((i * Math.PI) / 2) * 0.2, 0, Math.sin((i * Math.PI) / 2) * 0.2);
    blade.rotation.y = -(i * Math.PI) / 2;
    blade.rotation.x = 0.32;
    blade.material = steelMat;
    blade.parent = fanHub;
  }

  // 4B. DRAWN 3D EXTERIOR HOSPITAL BUILDINGS & COURTYARD (visible through skylight & windows)
  const exteriorRoot = new TransformNode('exteriorBuildings', scene);
  const addExteriorBuilding = (
    name: string,
    w: number,
    h: number,
    d: number,
    x: number,
    z: number,
    hasAntenna = false,
  ) => {
    const body = MeshBuilder.CreateBox(name, { width: w, height: h, depth: d }, scene);
    body.position.set(x, h / 2 - 0.5, z);
    body.material = buildingMat;
    body.receiveShadows = true;
    moonShadowGen?.addShadowCaster(body);
    body.parent = exteriorRoot;
    staticFreezeMeshes.push(body);

    const parapet = MeshBuilder.CreateBox(`${name}_cap`, { width: w + 0.5, height: 0.55, depth: d + 0.5 }, scene);
    parapet.position.set(x, h - 0.3, z);
    parapet.material = concreteMat;
    parapet.parent = exteriorRoot;
    staticFreezeMeshes.push(parapet);

    const hvac = MeshBuilder.CreateBox(`${name}_hvac`, { width: w * 0.32, height: 1.5, depth: d * 0.32 }, scene);
    hvac.position.set(x + w * 0.14, h + 0.55, z);
    hvac.material = darkMetalMat;
    hvac.parent = exteriorRoot;
    staticFreezeMeshes.push(hvac);

    if (hasAntenna) {
      const mast = MeshBuilder.CreateCylinder(`${name}_mast`, { diameter: 0.14, height: 6.2, tessellation: 6 }, scene);
      mast.position.set(x, h + 2.8, z);
      mast.material = steelMat;
      mast.parent = exteriorRoot;
      staticFreezeMeshes.push(mast);

      const beaconMat = new StandardMaterial(`${name}_bMat`, scene);
      beaconMat.diffuseColor = new Color3(1.0, 0.22, 0.18);
      beaconMat.emissiveColor = new Color3(1.0, 0.2, 0.14);
      beaconMat.disableLighting = true;
      const beacon = MeshBuilder.CreateSphere(`${name}_beacon`, { diameter: 0.38, segments: 6 }, scene);
      beacon.position.set(x, h + 5.95, z);
      beacon.material = beaconMat;
      beacon.parent = exteriorRoot;
      staticFreezeMeshes.push(beacon);
    }
  };

  // Pavillon Central (North 5-story tower), West Wing & East Clinical Tower + Skybridge
  addExteriorBuilding('pavillonNorth', 32, 20.5, 9.5, 0, -30.5, true);
  addExteriorBuilding('pavillonWest', 7.5, 15.0, 34, -16.2, -7.0, false);
  addExteriorBuilding('pavillonEast', 7.5, 16.0, 34, 16.2, -7.0, false);

  const skybridge = MeshBuilder.CreateBox('extSkybridge', { width: 25.0, height: 2.9, depth: 3.4 }, scene);
  skybridge.position.set(0, 8.9, -21.2);
  skybridge.material = buildingMat;
  skybridge.receiveShadows = true;
  moonShadowGen?.addShadowCaster(skybridge);
  skybridge.parent = exteriorRoot;
  staticFreezeMeshes.push(skybridge);

  const courtyardGround = MeshBuilder.CreateGround('courtyardGround', { width: 42, height: 52 }, scene);
  courtyardGround.position.set(0, -0.08, -10);
  courtyardGround.material = concreteMat;
  courtyardGround.receiveShadows = true;
  courtyardGround.parent = exteriorRoot;
  staticFreezeMeshes.push(courtyardGround);

  // 5. DOORS: Exit, Unlocked (Observation), Locked (Surgery + Generator), and Barricaded (3 sealed doors)
  const doors: DoorTarget[] = [];
  const interactables: InteractableTarget[] = [];

  const northExit = createDoorAssembly('northExit', scene, doorMat, darkMetalMat, steelMat, glassMat, 2.0, 2.45, mirrorRenderList);
  northExit.frame.position.set(0, 0, -15.92);

  // Barricaded South Exit
  const southDoor = createDoorAssembly('southDoor', scene, doorMat, darkMetalMat, steelMat, glassMat, 2.0, 2.45, mirrorRenderList);
  southDoor.frame.position.set(0, 0, 15.92);
  southDoor.frame.rotation.y = Math.PI;
  addBarricadePlanks('southBar', southDoor.frame, scene, woodPlankMat, hazardMat, 1.9, 0.09);

  const southBarCollider: Aabb2D = { minX: -1.1, maxX: 1.1, minZ: 15.65, maxZ: 16.15 };
  colliders.push(southBarCollider);
  const southBarTarget: DoorTarget = {
    id: 'door_south_bar',
    label: 'Sortie Sud (Barricadée)',
    position: new Vector3(0, 1.3, 15.75),
    kind: 'barricaded',
    isOpen: false,
    isUnlocked: false,
    openAngle: 0,
    targetAngle: 0,
    leftLeaf: southDoor.leftLeaf,
    rightLeaf: southDoor.rightLeaf,
    collider: southBarCollider,
    barricadeMessage: 'Des planches clouées de l’extérieur condamnent la sortie Sud. Aucune issue par ici.',
  };
  doors.push(southBarTarget);
  interactables.push({
    id: 'door_south_bar',
    label: southBarTarget.label,
    position: southBarTarget.position,
    root: southDoor.frame,
    ringMesh: MeshBuilder.CreateBox('dmy_s', { size: 0.01 }, scene),
    collected: false,
    doorRef: southBarTarget,
  });
  interactables[interactables.length - 1].ringMesh.isVisible = false;

  // Barricaded West Isolation Door (Z = -12.6)
  const barWest = createDoorAssembly('barWest', scene, doorMat, darkMetalMat, steelMat, glassMat, 1.25, 2.25, mirrorRenderList, true);
  barWest.frame.position.set(-2.16, 0, -12.6);
  barWest.frame.rotation.y = Math.PI / 2;
  addBarricadePlanks('barWestP', barWest.frame, scene, woodPlankMat, hazardMat, 1.25, -0.09);
  const barWestTarget: DoorTarget = {
    id: 'door_west_bar',
    label: 'Quartier Isolement (Condamné)',
    position: new Vector3(-2.1, 1.3, -12.6),
    kind: 'barricaded',
    isOpen: false,
    isUnlocked: false,
    openAngle: 0,
    targetAngle: 0,
    leftLeaf: barWest.leftLeaf,
    rightLeaf: null,
    collider: { minX: -2.4, maxX: -2.1, minZ: -13.2, maxZ: -12.0, disabled: true },
    barricadeMessage: 'Porte condamnée par l’équipe médicale avant l’évacuation. Des marques de griffes couvrent le bois.',
  };
  doors.push(barWestTarget);
  const dummyW = MeshBuilder.CreateBox('dmy_w', { size: 0.01 }, scene);
  dummyW.isVisible = false;
  interactables.push({
    id: 'door_west_bar',
    label: barWestTarget.label,
    position: barWestTarget.position,
    root: barWest.frame,
    ringMesh: dummyW,
    collected: false,
    doorRef: barWestTarget,
  });

  // Barricaded East Collapsed Wing Door (Z = 11.8)
  const barEast = createDoorAssembly('barEast', scene, doorMat, darkMetalMat, steelMat, glassMat, 1.25, 2.25, mirrorRenderList, true);
  barEast.frame.position.set(2.16, 0, 11.8);
  barEast.frame.rotation.y = -Math.PI / 2;
  addBarricadePlanks('barEastP', barEast.frame, scene, woodPlankMat, hazardMat, 1.25, -0.09);
  const barEastTarget: DoorTarget = {
    id: 'door_east_bar',
    label: 'Aile Effondrée (Barricadée)',
    position: new Vector3(2.1, 1.3, 11.8),
    kind: 'barricaded',
    isOpen: false,
    isUnlocked: false,
    openAngle: 0,
    targetAngle: 0,
    leftLeaf: barEast.leftLeaf,
    rightLeaf: null,
    collider: { minX: 2.1, maxX: 2.4, minZ: 11.2, maxZ: 12.4, disabled: true },
    barricadeMessage: 'Le plafond de cette aile s’est effondré derrière les barricades.',
  };
  doors.push(barEastTarget);
  const dummyE = MeshBuilder.CreateBox('dmy_e', { size: 0.01 }, scene);
  dummyE.isVisible = false;
  interactables.push({
    id: 'door_east_bar',
    label: barEastTarget.label,
    position: barEastTarget.position,
    root: barEast.frame,
    ringMesh: dummyE,
    collected: false,
    doorRef: barEastTarget,
  });

  // UNLOCKED Door: Observation Room (West, Z = -4.5) - starts ajar/openable
  const obsDoorAsm = createDoorAssembly('obsDoor', scene, doorMat, darkMetalMat, steelMat, glassMat, 1.28, 2.25, mirrorRenderList, true);
  obsDoorAsm.frame.position.set(-2.32, 0, -4.5);
  obsDoorAsm.frame.rotation.y = Math.PI / 2;
  const obsCollider: Aabb2D = { minX: -2.45, maxX: -2.19, minZ: -5.2, maxZ: -3.8, disabled: true };
  colliders.push(obsCollider);
  const obsDoorTarget: DoorTarget = {
    id: 'door_obs',
    label: 'Salle d’Observation',
    position: new Vector3(-2.32, 1.3, -4.5),
    kind: 'unlocked',
    isOpen: true,
    isUnlocked: true,
    openAngle: 1.35,
    targetAngle: 1.35,
    leftLeaf: obsDoorAsm.leftLeaf,
    rightLeaf: null,
    collider: obsCollider,
  };
  obsDoorAsm.leftLeaf.rotation.y = 1.35;
  doors.push(obsDoorTarget);
  const dummyObs = MeshBuilder.CreateBox('dmy_obs', { size: 0.01 }, scene);
  dummyObs.isVisible = false;
  interactables.push({
    id: 'door_obs',
    label: obsDoorTarget.label,
    position: obsDoorTarget.position,
    root: obsDoorAsm.frame,
    ringMesh: dummyObs,
    collected: false,
    doorRef: obsDoorTarget,
  });

  // LOCKED Door 1: Local Générateur (West-South, Z = 5.2, requires cle_generateur)
  const genDoorAsm = createDoorAssembly('sideDoor1', scene, doorMat, darkMetalMat, steelMat, glassMat, 1.25, 2.25, mirrorRenderList, true);
  genDoorAsm.frame.position.set(-2.32, 0, 5.2);
  genDoorAsm.frame.rotation.y = Math.PI / 2;
  const genCollider: Aabb2D = { minX: -2.45, maxX: -2.19, minZ: 4.55, maxZ: 5.85, disabled: false };
  colliders.push(genCollider);
  const genDoorTarget: DoorTarget = {
    id: 'door_generator',
    label: 'Local Générateur',
    position: new Vector3(-2.32, 1.3, 5.2),
    kind: 'locked',
    requiredKeyId: 'cle_generateur',
    requiredKeyLabel: 'Clé Local Générateur',
    isOpen: false,
    isUnlocked: false,
    openAngle: 0,
    targetAngle: 0,
    leftLeaf: genDoorAsm.leftLeaf,
    rightLeaf: null,
    collider: genCollider,
  };
  doors.push(genDoorTarget);
  const dummyGenD = MeshBuilder.CreateBox('dmy_gend', { size: 0.01 }, scene);
  dummyGenD.isVisible = false;
  interactables.push({
    id: 'door_generator',
    label: genDoorTarget.label,
    position: genDoorTarget.position,
    root: genDoorAsm.frame,
    ringMesh: dummyGenD,
    collected: false,
    doorRef: genDoorTarget,
  });

  // LOCKED Door 2: Bloc Chirurgical (East-North, Z = -9.8, requires cle_chirurgie)
  const surgDoorAsm = createDoorAssembly('sideDoor2', scene, doorMat, darkMetalMat, steelMat, glassMat, 1.25, 2.25, mirrorRenderList, true);
  surgDoorAsm.frame.position.set(2.32, 0, -9.8);
  surgDoorAsm.frame.rotation.y = -Math.PI / 2;
  const surgCollider: Aabb2D = { minX: 2.19, maxX: 2.45, minZ: -10.45, maxZ: -9.15, disabled: false };
  colliders.push(surgCollider);
  const surgDoorTarget: DoorTarget = {
    id: 'door_surgery',
    label: 'Bloc Chirurgical',
    position: new Vector3(2.32, 1.3, -9.8),
    kind: 'locked',
    requiredKeyId: 'cle_chirurgie',
    requiredKeyLabel: 'Clé Bloc Chirurgical',
    isOpen: false,
    isUnlocked: false,
    openAngle: 0,
    targetAngle: 0,
    leftLeaf: surgDoorAsm.leftLeaf,
    rightLeaf: null,
    collider: surgCollider,
  };
  doors.push(surgDoorTarget);
  const dummySurgD = MeshBuilder.CreateBox('dmy_surgd', { size: 0.01 }, scene);
  dummySurgD.isVisible = false;
  interactables.push({
    id: 'door_surgery',
    label: surgDoorTarget.label,
    position: surgDoorTarget.position,
    root: surgDoorAsm.frame,
    ringMesh: dummySurgD,
    collected: false,
    doorRef: surgDoorTarget,
  });

  // 6. PROPS IN CORRIDOR & NEW ROOMS
  const freezeHierarchy = (root: TransformNode) => {
    root.computeWorldMatrix(true);
    root.getChildMeshes().forEach((m) => staticFreezeMeshes.push(m));
  };

  const gurney1 = createGurney('gurney1', scene, steelMat, darkMetalMat, mattressMat, glassMat, textures, shadowGen);
  gurney1.position.set(-1.32, 0, -9.2);
  gurney1.rotation.y = -0.18;
  freezeHierarchy(gurney1);
  colliders.push({ minX: -1.85, maxX: -0.78, minZ: -10.25, maxZ: -8.15 });

  const gurney2 = createGurney('gurney2', scene, steelMat, darkMetalMat, mattressMat, glassMat, textures, shadowGen);
  gurney2.position.set(1.28, 0, 10.4);
  gurney2.rotation.y = 0.34;
  freezeHierarchy(gurney2);
  colliders.push({ minX: 0.72, maxX: 1.85, minZ: 9.35, maxZ: 11.45 });

  // Operating Table inside Bloc Chirurgical
  const opTable = createGurney('opTable', scene, steelMat, darkMetalMat, mattressMat, glassMat, textures, shadowGen);
  opTable.position.set(4.45, 0, -9.8);
  opTable.rotation.y = Math.PI / 2;
  freezeHierarchy(opTable);
  colliders.push({ minX: 3.45, maxX: 5.45, minZ: -10.35, maxZ: -9.25 });

  const crashCart = createCrashCart('crashCart', scene, redBodyMat, steelMat, darkMetalMat, monitorMat, textures, shadowGen);
  crashCart.position.set(-1.45, 0, 8.3);
  crashCart.rotation.y = -Math.PI / 2 - 0.16;
  freezeHierarchy(crashCart);
  colliders.push({ minX: -1.9, maxX: -1.0, minZ: 7.78, maxZ: 8.82 });

  const wc1 = createWheelchair('wc1', scene, steelMat, seatMat, rubberMat, textures, shadowGen);
  wc1.position.set(-4.1, 0, -4.5);
  wc1.rotation.y = -1.15;
  freezeHierarchy(wc1);
  colliders.push({ minX: -4.55, maxX: -3.65, minZ: -4.95, maxZ: -4.05 });

  const wc2 = createWheelchair('wc2', scene, steelMat, seatMat, rubberMat, textures, shadowGen);
  wc2.position.set(1.38, 0, -1.2);
  wc2.rotation.y = 2.2;
  freezeHierarchy(wc2);
  colliders.push({ minX: 0.95, maxX: 1.82, minZ: -1.65, maxZ: -0.75 });

  // East Alcove Reception Desk
  const deskRoot = new TransformNode('deskRoot', scene);
  deskRoot.position.set(3.85, 0, 4.5);
  const deskCs = makeContactShadow('deskShadow', scene, textures.contactShadow, 1.5, 3.0);
  deskCs.parent = deskRoot;

  const deskBase = MeshBuilder.CreateBox('deskBase', { width: 0.95, height: 1.02, depth: 2.75 }, scene);
  deskBase.position.y = 0.51;
  deskBase.material = concreteMat;
  deskBase.receiveShadows = true;
  deskBase.parent = deskRoot;
  shadowGen?.addShadowCaster(deskBase);

  const deskTop = MeshBuilder.CreateBox('deskTop', { width: 1.12, height: 0.06, depth: 2.86 }, scene);
  deskTop.position.y = 1.05;
  deskTop.material = steelMat;
  deskTop.parent = deskRoot;
  shadowGen?.addShadowCaster(deskTop);

  const crtBody = MeshBuilder.CreateBox('crtBody', { width: 0.38, height: 0.34, depth: 0.36 }, scene);
  crtBody.position.set(-0.1, 1.25, -0.65);
  crtBody.rotation.y = 0.35;
  crtBody.material = darkMetalMat;
  crtBody.parent = deskRoot;

  const crtScreen = MeshBuilder.CreatePlane('crtScreen', { width: 0.31, height: 0.24 }, scene);
  crtScreen.position.set(-0.28, 1.25, -0.58);
  crtScreen.rotation.y = Math.PI / 2 + 0.35;
  crtScreen.material = monitorMat;
  crtScreen.parent = deskRoot;
  freezeHierarchy(deskRoot);
  colliders.push({ minX: 3.25, maxX: 4.48, minZ: 3.05, maxZ: 5.95 });

  // Industrial Generator Machine inside Local Générateur (West-South)
  const genRoot = new TransformNode('genMachine', scene);
  genRoot.position.set(-4.6, 0, 5.2);
  const genBody = MeshBuilder.CreateBox('genBody', { width: 1.35, height: 1.45, depth: 2.1 }, scene);
  genBody.position.y = 0.725;
  genBody.material = darkMetalMat;
  genBody.parent = genRoot;
  const genTank = MeshBuilder.CreateCylinder('genTank', { diameter: 0.52, height: 1.7, tessellation: 12 }, scene);
  genTank.rotation.x = Math.PI / 2;
  genTank.position.set(0, 1.65, 0);
  genTank.material = redBodyMat;
  genTank.parent = genRoot;

  const generatorLedMat = new StandardMaterial('generatorLedMat', scene);
  generatorLedMat.diffuseColor = new Color3(1.0, 0.25, 0.16);
  generatorLedMat.emissiveColor = new Color3(1.0, 0.22, 0.14);
  generatorLedMat.disableLighting = true;
  const genLed = MeshBuilder.CreateSphere('genLed', { diameter: 0.08, segments: 8 }, scene);
  genLed.position.set(0.7, 1.18, 0.35);
  genLed.material = generatorLedMat;
  genLed.parent = genRoot;
  freezeHierarchy(genRoot);
  colliders.push({ minX: -5.35, maxX: -3.85, minZ: 4.1, maxZ: 6.3 });

  // Architectural & Medical Detail Props (Scialytic Surgical Lamp, Oxygen Cylinders, Fire Extinguishers, Wall Bumper Rails)
  const addBumperRail = (name: string, x: number, z0: number, z1: number) => {
    const len = Math.abs(z1 - z0);
    const rail = MeshBuilder.CreateBox(name, { width: 0.06, height: 0.12, depth: len }, scene);
    rail.position.set(x, 0.94, (z0 + z1) / 2);
    rail.material = darkMetalMat;
    staticFreezeMeshes.push(rail);
  };
  addBumperRail('railWN', -2.18, -15.8, -6.9);
  addBumperRail('railWS', -2.18, 6.0, 15.8);
  addBumperRail('railEN', 2.18, -15.8, -10.6);
  addBumperRail('railEM', 2.18, -9.0, 2.0);
  addBumperRail('railES', 2.18, 7.0, 15.8);

  // Scialytic Surgical Lamp above Operating Table (Bloc Chirurgical)
  const scialyticStem = MeshBuilder.CreateCylinder('scialyticStem', { diameter: 0.08, height: 0.9, tessellation: 10 }, scene);
  scialyticStem.position.set(4.45, 3.15, -9.8);
  scialyticStem.material = steelMat;
  staticFreezeMeshes.push(scialyticStem);
  const scialyticDome = MeshBuilder.CreateCylinder('scialyticDome', { diameterTop: 0.35, diameterBottom: 0.78, height: 0.16, tessellation: 16 }, scene);
  scialyticDome.position.set(4.45, 2.68, -9.8);
  scialyticDome.material = steelMat;
  shadowGen?.addShadowCaster(scialyticDome);
  staticFreezeMeshes.push(scialyticDome);
  const scialyticGlowMat = new StandardMaterial('scialyticGlow', scene);
  scialyticGlowMat.diffuseColor = new Color3(0.65, 0.98, 0.92);
  scialyticGlowMat.emissiveColor = new Color3(0.45, 0.92, 0.84);
  scialyticGlowMat.disableLighting = true;
  const scialyticLens = MeshBuilder.CreateDisc('scialyticLens', { radius: 0.34, tessellation: 16 }, scene);
  scialyticLens.rotation.x = -Math.PI / 2;
  scialyticLens.position.set(4.45, 2.59, -9.8);
  scialyticLens.material = scialyticGlowMat;
  staticFreezeMeshes.push(scialyticLens);

  // Oxygen Cylinders in Bloc Chirurgical
  [-11.8, -11.4].forEach((oz, i) => {
    const tank = MeshBuilder.CreateCylinder(`o2Tank_${i}`, { diameter: 0.24, height: 1.25, tessellation: 12 }, scene);
    tank.position.set(5.75, 0.625, oz);
    tank.material = steelMat;
    shadowGen?.addShadowCaster(tank);
    staticFreezeMeshes.push(tank);
    const valve = MeshBuilder.CreateCylinder(`o2Valve_${i}`, { diameter: 0.08, height: 0.14, tessellation: 8 }, scene);
    valve.position.set(5.75, 1.32, oz);
    valve.material = hazardMat;
    staticFreezeMeshes.push(valve);
  });

  // Hideouts (Lockers & Under-Bed spaces like Outlast 2) + Diversion Glass Bottles
  const hideouts: HideoutTarget[] = [];
  const bottleGlassMat = makeSimplePbr('bottleGlassMat', new Color3(0.24, 0.52, 0.34), 0.12, 0.08);
  bottleGlassMat.alpha = 0.82;
  if (!isMobileTier) {
    bottleGlassMat.clearCoat.isEnabled = true;
    bottleGlassMat.clearCoat.intensity = 1.0;
  }
  const bottleLabelMat = makeSimplePbr('bottleLabelMat', new Color3(0.76, 0.72, 0.62), 0.02, 0.82);
  const blanketMat = makeSimplePbr('blanketMat', new Color3(0.18, 0.24, 0.27), 0.02, 0.9);

  const registerLocker = (
    id: string,
    label: string,
    x: number,
    z: number,
    rotY: number,
    baseYaw: number,
  ) => {
    const { root, doorPivot } = createLockerHideout(
      id,
      scene,
      doorMat,
      concreteMat,
      steelMat,
      darkMetalMat,
      textures,
      shadowGen,
    );
    root.position.set(x, 0, z);
    root.rotation.y = rotY;
    root.computeWorldMatrix(true);
    root.getChildMeshes().forEach((m) => {
      if (m.parent !== doorPivot) {
        staticFreezeMeshes.push(m);
      }
    });

    // Collider sized to locker footprint
    colliders.push({ minX: x - 0.44, maxX: x + 0.44, minZ: z - 0.44, maxZ: z + 0.44 });

    const fwdX = Math.sin(baseYaw);
    const fwdZ = Math.cos(baseYaw);
    const cameraPos = new Vector3(x + fwdX * 0.04, 1.48, z + fwdZ * 0.04);
    const exitPos = new Vector3(x + fwdX * 0.88, 0, z + fwdZ * 0.88);
    const ringMat = new StandardMaterial(`${id}_ringMat`, scene);
    ringMat.diffuseColor = new Color3(0.38, 0.86, 0.78);
    ringMat.emissiveColor = new Color3(0.38, 0.86, 0.78);
    ringMat.disableLighting = true;
    ringMat.alpha = 0.65;

    const dummyRing = MeshBuilder.CreateTorus(`${id}_ring`, { diameter: 0.24, thickness: 0.018, tessellation: 14 }, scene);
    dummyRing.position.set(x + fwdX * 0.42, 1.05, z + fwdZ * 0.42);
    dummyRing.rotation.z = Math.PI / 2;
    dummyRing.material = ringMat;
    dummyRing.isVisible = false;

    const hTarget: HideoutTarget = {
      id,
      label,
      kind: 'locker',
      position: new Vector3(x, 1.25, z),
      cameraPos,
      exitPos,
      baseYaw,
      doorPivot,
      doorAngle: 0,
      targetDoorAngle: 0,
    };
    hideouts.push(hTarget);
    interactables.push({
      id,
      label,
      position: new Vector3(x + fwdX * 0.38, 1.25, z + fwdZ * 0.38),
      root,
      ringMesh: dummyRing,
      collected: false,
      hideoutRef: hTarget,
    });
  };

  const registerBed = (
    id: string,
    label: string,
    x: number,
    z: number,
    rotY: number,
    exitOffsetX: number,
    exitOffsetZ: number,
    baseYaw: number,
  ) => {
    const bedRoot = createBedHideout(
      id,
      scene,
      steelMat,
      mattressMat,
      blanketMat,
      darkMetalMat,
      textures,
      shadowGen,
    );
    bedRoot.position.set(x, 0, z);
    bedRoot.rotation.y = rotY;
    freezeHierarchy(bedRoot);

    const halfW = Math.abs(Math.sin(rotY)) > 0.7 ? 1.04 : 0.54;
    const halfD = Math.abs(Math.sin(rotY)) > 0.7 ? 0.54 : 1.04;
    colliders.push({ minX: x - halfW, maxX: x + halfW, minZ: z - halfD, maxZ: z + halfD });

    const dummyRing = MeshBuilder.CreateBox(`${id}_dmy`, { size: 0.01 }, scene);
    dummyRing.isVisible = false;

    const hTarget: HideoutTarget = {
      id,
      label,
      kind: 'bed',
      position: new Vector3(x, 0.52, z),
      cameraPos: new Vector3(x, 0.34, z),
      exitPos: new Vector3(x + exitOffsetX, 0, z + exitOffsetZ),
      baseYaw,
      doorPivot: null,
      doorAngle: 0,
      targetDoorAngle: 0,
    };
    hideouts.push(hTarget);
    interactables.push({
      id,
      label,
      position: new Vector3(x, 0.52, z),
      root: bedRoot,
      ringMesh: dummyRing,
      collected: false,
      hideoutRef: hTarget,
    });
  };

  // Place 3 Lockers & 2 Hospital Beds across corridor & rooms
  registerLocker('locker_south', 'Casier métallique (Couloir Sud)', -1.86, 11.4, Math.PI / 2, Math.PI / 2);
  registerLocker('locker_north', 'Casier métallique (Couloir Nord)', -1.86, -7.2, Math.PI / 2, Math.PI / 2);
  registerLocker('locker_surg', 'Casier médical (Bloc Chirurgical)', 5.72, -7.8, -Math.PI / 2, -Math.PI / 2);
  registerBed('bed_obs', 'Lit d’observation (Dessous)', -4.35, -5.85, Math.PI / 2, 0, 1.05, 0);
  registerBed('bed_corr', 'Lit de quarantaine (Dessous)', 1.56, -3.6, 0, -0.95, 0, -Math.PI / 2);

  // Reusable Thrown Bottle Projectile + Glass Shatter VFX
  const thrownBottleMesh = createBottleMesh('thrownBottleProj', scene, bottleGlassMat, steelMat, bottleLabelMat);
  thrownBottleMesh.setEnabled(false);

  const shatterRoot = new TransformNode('shatterFxRoot', scene);
  shatterRoot.setEnabled(false);
  const shatterRingMat = new StandardMaterial('shatterRingMat', scene);
  shatterRingMat.diffuseColor = new Color3(0.75, 0.94, 1.0);
  shatterRingMat.emissiveColor = new Color3(0.6, 0.9, 1.0);
  shatterRingMat.disableLighting = true;
  shatterRingMat.alpha = 0.85;
  const shatterRing = MeshBuilder.CreateTorus('shatterRing', { diameter: 0.7, thickness: 0.03, tessellation: 18 }, scene);
  shatterRing.material = shatterRingMat;
  shatterRing.parent = shatterRoot;

  const shatterShards: { mesh: Mesh; vx: number; vy: number; vz: number }[] = [];
  for (let i = 0; i < 6; i++) {
    const sh = MeshBuilder.CreateBox(`shShard_${i}`, { width: 0.03, height: 0.012, depth: 0.045 }, scene);
    sh.material = bottleGlassMat;
    sh.parent = shatterRoot;
    const ang = (i / 6) * Math.PI * 2;
    shatterShards.push({
      mesh: sh,
      vx: Math.cos(ang) * (1.2 + (i % 2) * 0.6),
      vy: 1.8 + (i % 3) * 0.6,
      vz: Math.sin(ang) * (1.2 + (i % 2) * 0.6),
    });
  }

  let shatterTimer = 0;
  const triggerGlassShatter = (pos: Vector3) => {
    shatterRoot.position.set(pos.x, 0.03, pos.z);
    shatterRoot.setEnabled(true);
    shatterTimer = 0.75;
    shatterRing.scaling.set(0.25, 0.25, 0.25);
    shatterRingMat.alpha = 0.85;
    shatterShards.forEach((s) => {
      s.mesh.position.set(0, 0.08, 0);
      s.mesh.rotation.set(Math.random() * 3, Math.random() * 3, 0);
    });
  };

  // Wall-mounted Fire Extinguishers along Corridor
  [
    { x: -2.06, z: 12.6 },
    { x: 2.06, z: -12.2 },
  ].forEach((fe, i) => {
    const ext = MeshBuilder.CreateCylinder(`fireExt_${i}`, { diameter: 0.16, height: 0.52, tessellation: 10 }, scene);
    ext.position.set(fe.x, 1.18, fe.z);
    ext.material = redBodyMat;
    shadowGen?.addShadowCaster(ext);
    staticFreezeMeshes.push(ext);
    const horn = MeshBuilder.CreateBox(`fireHorn_${i}`, { width: 0.05, height: 0.14, depth: 0.08 }, scene);
    horn.position.set(fe.x, 1.48, fe.z);
    horn.material = darkMetalMat;
    staticFreezeMeshes.push(horn);
  });

  const genRingMat = new StandardMaterial('genRingMat', scene);
  genRingMat.diffuseColor = new Color3(1.0, 0.68, 0.25);
  genRingMat.emissiveColor = new Color3(1.0, 0.62, 0.2);
  genRingMat.disableLighting = true;
  genRingMat.alpha = 0.7;
  const genRing = MeshBuilder.CreateTorus('genRing', { diameter: 0.34, thickness: 0.024, tessellation: 18 }, scene);
  genRing.rotation.z = Math.PI / 2;
  genRing.position.set(0.75, 1.18, 0.35);
  genRing.material = genRingMat;
  genRing.parent = genRoot;

  interactables.push({
    id: 'generator_switch',
    label: 'Démarrer le groupe électrogène',
    position: new Vector3(-3.85, 1.18, 5.55),
    root: genRoot,
    ringMesh: genRing,
    collected: false,
    isGeneratorSwitch: true,
  });

  // Electrical Breaker Panel beside North Exit
  const breakerRoot = new TransformNode('breakerRoot', scene);
  breakerRoot.position.set(1.52, 1.38, -15.9);
  const breakerBox = MeshBuilder.CreateBox('breakerBox', { width: 0.54, height: 0.72, depth: 0.14 }, scene);
  breakerBox.material = darkMetalMat;
  breakerBox.parent = breakerRoot;

  const breakerLedMat = new StandardMaterial('breakerLedMat', scene);
  breakerLedMat.diffuseColor = new Color3(1.0, 0.24, 0.18);
  breakerLedMat.emissiveColor = new Color3(1.0, 0.22, 0.16);
  breakerLedMat.disableLighting = true;

  const ledMesh = MeshBuilder.CreateSphere('breakerLed', { diameter: 0.064, segments: 8 }, scene);
  ledMesh.position.set(-0.14, 0.2, 0.075);
  ledMesh.material = breakerLedMat;
  ledMesh.parent = breakerRoot;

  const breakerLever = new TransformNode('breakerLever', scene);
  breakerLever.position.set(0.18, 0.05, 0.07);
  breakerLever.parent = breakerRoot;

  const leverArm = MeshBuilder.CreateBox('leverArm', { width: 0.035, height: 0.22, depth: 0.035 }, scene);
  leverArm.position.y = -0.09;
  leverArm.material = steelMat;
  leverArm.parent = breakerLever;

  const leverHandle = MeshBuilder.CreateCylinder('leverHandle', { diameter: 0.05, height: 0.08, tessellation: 8 }, scene);
  leverHandle.rotation.z = Math.PI / 2;
  leverHandle.position.set(0.03, -0.18, 0);
  leverHandle.material = redBodyMat;
  leverHandle.parent = breakerLever;

  const exitRingMat = new StandardMaterial('exitRingMat', scene);
  exitRingMat.diffuseColor = new Color3(1.0, 0.55, 0.25);
  exitRingMat.emissiveColor = new Color3(1.0, 0.55, 0.25);
  exitRingMat.disableLighting = true;
  exitRingMat.alpha = 0.7;

  const exitRing = MeshBuilder.CreateTorus('exitRing', { diameter: 0.36, thickness: 0.025, tessellation: 18 }, scene);
  exitRing.rotation.x = Math.PI / 2;
  exitRing.position.set(0, -0.35, 0.09);
  exitRing.material = exitRingMat;
  exitRing.parent = breakerRoot;

  interactables.push({
    id: 'exit_panel',
    label: 'Rétablir le courant (Sortie Nord)',
    position: new Vector3(1.52, 1.38, -15.75),
    root: breakerRoot,
    ringMesh: exitRing,
    collected: false,
    isExitPanel: true,
  });

  // 7. COLLECTIBLES (2 Keys + 4 Story Components)
  const createPickupItem = (
    id: string,
    label: string,
    pos: Vector3,
    kind: 'fuse' | 'dossier' | 'badge' | 'key',
    note: ClueNote,
    keyLabel?: string,
  ) => {
    const root = new TransformNode(id, scene);
    root.position.copyFrom(pos);

    if (kind === 'key') {
      const goldMat = makeSimplePbr(id + '_gold', new Color3(0.95, 0.76, 0.32), 0.9, 0.22);
      const bow = MeshBuilder.CreateTorus(id + '_bow', { diameter: 0.08, thickness: 0.016, tessellation: 14 }, scene);
      bow.position.x = -0.06;
      bow.material = goldMat;
      bow.parent = root;
      const blade = MeshBuilder.CreateBox(id + '_bld', { width: 0.13, height: 0.012, depth: 0.02 }, scene);
      blade.position.x = 0.03;
      blade.material = goldMat;
      blade.parent = root;
      const tooth = MeshBuilder.CreateBox(id + '_tth', { width: 0.03, height: 0.012, depth: 0.03 }, scene);
      tooth.position.set(0.08, 0, 0.018);
      tooth.material = goldMat;
      tooth.parent = root;
    } else if (kind === 'fuse') {
      const capMat = makeSimplePbr(id + '_cap', new Color3(0.85, 0.6, 0.22), 0.88, 0.24);
      const coreMat = new StandardMaterial(id + '_core', scene);
      coreMat.diffuseColor = new Color3(0.35, 0.78, 1.0);
      coreMat.emissiveColor = new Color3(0.18, 0.55, 0.9);
      const body = MeshBuilder.CreateCylinder(id + '_b', { diameter: 0.09, height: 0.16, tessellation: 12 }, scene);
      body.rotation.z = Math.PI / 2;
      body.material = coreMat;
      body.parent = root;
      const capL = MeshBuilder.CreateCylinder(id + '_cL', { diameter: 0.096, height: 0.04, tessellation: 12 }, scene);
      capL.rotation.z = Math.PI / 2;
      capL.position.x = -0.085;
      capL.material = capMat;
      capL.parent = root;
      const capR = capL.clone(id + '_cR');
      capR.position.x = 0.085;
      capR.parent = root;
    } else if (kind === 'dossier') {
      const folderMat = makeSimplePbr(id + '_fMat', new Color3(0.76, 0.67, 0.52), 0.0, 0.78);
      const pageMat = new StandardMaterial(id + '_pMat', scene);
      pageMat.diffuseColor = new Color3(0.92, 0.94, 0.96);
      pageMat.emissiveColor = new Color3(0.14, 0.24, 0.32);
      const folder = MeshBuilder.CreateBox(id + '_fold', { width: 0.24, height: 0.018, depth: 0.31 }, scene);
      folder.material = folderMat;
      folder.parent = root;
      const page = MeshBuilder.CreateBox(id + '_page', { width: 0.21, height: 0.022, depth: 0.28 }, scene);
      page.position.set(0.01, 0.004, 0.01);
      page.rotation.y = 0.08;
      page.material = pageMat;
      page.parent = root;
    } else {
      const cardMat = new StandardMaterial(id + '_card', scene);
      cardMat.diffuseColor = new Color3(0.84, 0.92, 0.98);
      cardMat.emissiveColor = new Color3(0.24, 0.56, 0.84);
      const strapMat = makeSimplePbr(id + '_strap', new Color3(0.13, 0.3, 0.48), 0.0, 0.7);
      const card = MeshBuilder.CreateBox(id + '_crd', { width: 0.11, height: 0.008, depth: 0.16 }, scene);
      card.material = cardMat;
      card.parent = root;
      const strap = MeshBuilder.CreateTorus(id + '_stp', { diameter: 0.13, thickness: 0.014, tessellation: 14 }, scene);
      strap.position.z = -0.11;
      strap.material = strapMat;
      strap.parent = root;
    }

    const ringColor = kind === 'key' ? new Color3(1.0, 0.78, 0.28) : new Color3(0.45, 0.82, 1.0);
    const ringMat = new StandardMaterial(id + '_ringMat', scene);
    ringMat.diffuseColor = ringColor;
    ringMat.emissiveColor = ringColor;
    ringMat.disableLighting = true;
    ringMat.alpha = 0.68;

    const ringMesh = MeshBuilder.CreateTorus(id + '_ring', { diameter: 0.32, thickness: 0.022, tessellation: 18 }, scene);
    ringMesh.position.y = 0.02;
    ringMesh.material = ringMat;
    ringMesh.parent = root;

    interactables.push({
      id,
      label,
      position: pos.clone(),
      root,
      ringMesh,
      collected: false,
      isKey: kind === 'key',
      keyLabel,
      note,
    });
  };

  // Clé 1 : sur le bureau du Poste de soins (Aile Est ouverte)
  createPickupItem(
    'cle_chirurgie',
    'Clé du Bloc Chirurgical',
    new Vector3(3.62, 1.12, 4.95),
    'key',
    {
      id: 'cle_chirurgie',
      title: 'CHAPITRE I — ÉVACUATION D’URGENCE',
      subtitle: 'Poste de soins · Aile Est',
      body: '« 23h50 — Le Sujet 04 a brisé les sangles du bloc. Nous avons barricadé les sorties. Prenez la clé de la Chirurgie pour récupérer le relais. »',
    },
    'Clé Chirurgie',
  );

  // Composant 1 : Fusible sur le chariot du couloir Sud
  createPickupItem(
    'fusible_1',
    'Fusible Haute Tension',
    new Vector3(-1.32, 1.02, 8.45),
    'fuse',
    {
      id: 'fusible_1',
      title: 'FUSIBLE HAUTE TENSION RÉCUPÉRÉ',
      subtitle: 'Chariot médical · Couloir Sud',
      body: 'Composant intact de 60A. Une respiration rauque résonne plus loin au Nord… reste attentif.',
    },
  );

  // Composant 2 : Dossier + Badge dans la Salle d'Observation (Aile Ouest, porte ouverte/refermable)
  createPickupItem(
    'badge_acces',
    'Dossier Patient 04 & Badge',
    new Vector3(-3.95, 0.55, -4.45),
    'badge',
    {
      id: 'badge_acces',
      title: 'CHAPITRE II — PROTOCOLE SILENCE',
      subtitle: 'Salle d’Observation · Aile Ouest',
      body: '« Le Patient 04 chasse au bruit et à la lumière directe. Accroupis-toi [C] et éteins ta lampe [F] s’il approche. Tu peux refermer cette porte derrière toi. »',
    },
  );

  // Clé 2 : Clé du Local Générateur à l'intérieur du Bloc Chirurgical (verrouillé par cle_chirurgie)
  createPickupItem(
    'cle_generateur',
    'Clé du Local Générateur',
    new Vector3(4.55, 0.9, -9.45),
    'key',
    {
      id: 'cle_generateur',
      title: 'CHAPITRE III — L’EXPÉRIENCE KAMBALA',
      subtitle: 'Bloc Chirurgical · Aile Est-Nord',
      body: '« Nous avons coupé le générateur Ouest-Sud pour l’endormir dans le noir. Il faut le réactiver là-bas pour alimenter la Sortie Nord. »',
    },
    'Clé Générateur',
  );

  // Composant 3 : Relais de secours sur la table d'opération (Bloc Chirurgical)
  createPickupItem(
    'fusible_2',
    'Relais de Secours',
    new Vector3(4.35, 0.9, -10.25),
    'fuse',
    {
      id: 'fusible_2',
      title: 'RELAIS DE SECOURS RÉCUPÉRÉ',
      subtitle: 'Table d’opération · Bloc Chirurgical',
      body: 'Module d’amorçage sécurisé. Direction le Local Générateur au Sud-Ouest avec la nouvelle clé.',
    },
  );

  // Composant 4 : Module de Quarantaine dans le Local Générateur (verrouillé par cle_generateur)
  createPickupItem(
    'dossier_patient',
    'Module d’Amorçage Sas',
    new Vector3(-4.65, 1.52, 3.85),
    'dossier',
    {
      id: 'dossier_patient',
      title: 'CHAPITRE IV — DERNIER SOUFFLE',
      subtitle: 'Local Technique · Aile Ouest-Sud',
      body: 'Tu tiens le dernier composant. Démarre le groupe électrogène juste à côté, puis cours vers le tableau électrique de la Sortie Nord !',
    },
  );

  // Bouteilles en verre PBR ramassables pour faire diversion (touche G)
  const createBottlePickup = (id: string, pos: Vector3) => {
    const root = createBottleMesh(id, scene, bottleGlassMat, steelMat, bottleLabelMat);
    root.position.copyFrom(pos);

    const ringMat = new StandardMaterial(`${id}_ringMat`, scene);
    ringMat.diffuseColor = new Color3(0.42, 0.92, 0.65);
    ringMat.emissiveColor = new Color3(0.42, 0.92, 0.65);
    ringMat.disableLighting = true;
    ringMat.alpha = 0.62;

    const ringMesh = MeshBuilder.CreateTorus(`${id}_ring`, { diameter: 0.26, thickness: 0.018, tessellation: 14 }, scene);
    ringMesh.position.y = 0.015;
    ringMesh.material = ringMat;
    ringMesh.parent = root;

    interactables.push({
      id,
      label: 'Bouteille en verre (Diversion)',
      position: pos.clone().add(new Vector3(0, 0.14, 0)),
      root,
      ringMesh,
      collected: false,
      isBottle: true,
    });
  };

  createBottlePickup('bottle_1', new Vector3(1.55, 0.01, 12.6));
  createBottlePickup('bottle_2', new Vector3(3.75, 1.08, 5.45));
  createBottlePickup('bottle_3', new Vector3(-3.3, 0.01, -3.2));
  createBottlePickup('bottle_4', new Vector3(1.62, 0.01, -6.4));
  createBottlePickup('bottle_5', new Vector3(-3.1, 0.01, 6.7));

  // Freeze static meshes & materials
  staticFreezeMeshes.forEach((m) => {
    m.freezeWorldMatrix();
    m.doNotSyncBoundingInfo = true;
  });
  [
    wallMat,
    ceilingMat,
    steelMat,
    darkMetalMat,
    concreteMat,
    mattressMat,
    seatMat,
    rubberMat,
    redBodyMat,
    doorMat,
    woodPlankMat,
    buildingMat,
    hazardMat,
    blanketMat,
    bottleLabelMat,
  ].forEach((mat) => mat.freeze());

  // 7B. GAUSSIAN SPLATTING SCANNED BUILDING COMPLEX (Babylon.js GaussianSplattingMesh)
  let gaussianBuildingsMesh: GaussianSplattingMesh | null = null;
  let gaussianUserEnabled = initialConfig.gaussianEnabled;

  if (!isSoftwareGl) {
    try {
      const gs = new GaussianSplattingMesh('kambalaBuildingsScan', null, scene);
      gs.minPixelSize = isMobileTier ? 1.8 : 1.0;
      gs.isPickable = false;
      gs.isVisible = gaussianUserEnabled;
      gaussianBuildingsMesh = gs;
      gs.loadFileAsync('/assets/gaussian/kambala_buildings_scan.splat', scene)
        .then(() => {
          if (gaussianBuildingsMesh) {
            gaussianBuildingsMesh.isVisible = gaussianUserEnabled;
          }
        })
        .catch(() => {
          // Non-fatal fallback if splat binary isn't reachable
        });
    } catch {
      gaussianBuildingsMesh = null;
    }
  }

  // 8. MONSTER RIG (Patient 04) + NOAH 3P RIG + 1P WEAPON/FLASHLIGHT VIEWMODEL + CHAPTER EXTENSIONS
  const monster = createMonsterRig(scene, shadowGen);
  const noahRig = createNoahThirdPersonRig(scene, shadowGen, hasPremiumPass);
  const fpGear = createFirstPersonGearRig(scene, camera, hasPremiumPass);
  const atmosphereFx = createBloodAndRainAtmosphere(scene, chapterId, isMobileTier);
  const chapterExt = populateChapterExtensions(
    scene,
    chapterId,
    steelMat,
    darkMetalMat,
    glassMat,
    colliders,
    shadowGen,
  );
  chapterExt.extraInteractables.forEach((item) => interactables.push(item));

  const setPremiumSkins = (enabled: boolean) => {
    noahRig.jacketMat.albedoColor = enabled
      ? new Color3(0.06, 0.13, 0.24)
      : new Color3(0.18, 0.22, 0.26);
    noahRig.flashlightBodyMat.albedoColor = enabled
      ? new Color3(0.85, 0.62, 0.22)
      : new Color3(0.22, 0.25, 0.28);
    fpGear.flashlightBodyMat.albedoColor = enabled
      ? new Color3(0.86, 0.62, 0.2)
      : new Color3(0.18, 0.21, 0.25);
    flashlight.diffuse = enabled
      ? new Color3(1.0, 0.94, 0.8)
      : new Color3(0.93, 0.97, 1.0);
  };
  setPremiumSkins(hasPremiumPass);

  // 9. PARTICLES
  const dustCapacity = isMobileTier ? 70 : 200;
  const dustSystem = new ParticleSystem('dustMotes', dustCapacity, scene);
  dustSystem.particleTexture = textures.dustParticle;
  dustSystem.emitter = new Vector3(0, 1.7, 0);
  dustSystem.minEmitBox = new Vector3(-1.9, -1.4, -15.0);
  dustSystem.maxEmitBox = new Vector3(1.9, 1.4, 15.0);
  dustSystem.color1 = new Color4(0.75, 0.88, 1.0, 0.26);
  dustSystem.color2 = new Color4(0.55, 0.72, 0.88, 0.16);
  dustSystem.colorDead = new Color4(0.4, 0.55, 0.7, 0.0);
  dustSystem.minSize = 0.022;
  dustSystem.maxSize = 0.055;
  dustSystem.minLifeTime = 4.5;
  dustSystem.maxLifeTime = 8.0;
  dustSystem.emitRate = 24;
  dustSystem.blendMode = ParticleSystem.BLENDMODE_ADD;
  dustSystem.direction1 = new Vector3(-0.08, -0.04, -0.08);
  dustSystem.direction2 = new Vector3(0.08, 0.06, 0.08);
  dustSystem.minEmitPower = 0.02;
  dustSystem.maxEmitPower = 0.07;
  dustSystem.preWarmCycles = 25;
  dustSystem.start();

  let activeMaxPointLights = initialConfig.maxActivePointLights;
  let monitorInterval = isMobileTier ? 0.16 : 0.085;
  let raycastStride = isMobileTier ? 5 : 3;

  const applyQuality = (config: RenderQualityConfig) => {
    // Keep touch devices at native CSS resolution to prevent WebGL memory spikes/context loss.
    const dpr = (isSoftwareGl || isMobileTier)
      ? 1
      : Math.min(window.devicePixelRatio || 1, config.pixelRatioCap, 1.5);
    engine.setHardwareScalingLevel(1 / dpr);

    activeMaxPointLights = config.maxActivePointLights;
    const lowTier = config.tier === 'balanced' || config.tier === 'performance';
    monitorInterval = lowTier ? 0.16 : 0.085;
    raycastStride = lowTier ? 5 : 3;

    flashlight.shadowEnabled = !isSoftwareGl && config.shadowsEnabled;
    moonLight.shadowEnabled = !isSoftwareGl && !lowTier && config.shadowsEnabled;
    if (shadowGen) {
      shadowGen.usePercentageCloserFiltering = config.pcfShadows;
    }

    if (config.mirrorReflections && !isSoftwareGl) {
      puddleMat.reflectionTexture = ensureMirrorTexture();
    } else {
      puddleMat.reflectionTexture = null;
    }

    puddleMat.bumpTexture = config.puddleRipples ? textures.floor.bump : null;

    volumetricCones.forEach((c) => {
      c.isVisible = config.volumetricsEnabled;
    });
    flashCone.isVisible = config.volumetricsEnabled && flashlight.isEnabled();

    dustSystem.emitRate = Math.round(24 * config.dustRatio);

    if (gaussianBuildingsMesh) {
      gaussianBuildingsMesh.minPixelSize = lowTier ? 1.8 : 1.0;
      // Quality presets never hide world/environment geometry; only the player's SPLAT toggle may hide it.
      gaussianBuildingsMesh.isVisible = gaussianUserEnabled;
    }
  };

  const setGaussianEnabled = (enabled: boolean) => {
    gaussianUserEnabled = enabled;
    if (gaussianBuildingsMesh) {
      gaussianBuildingsMesh.isVisible = enabled;
    }
  };

  const isGaussianEnabled = () => gaussianUserEnabled && (gaussianBuildingsMesh?.isVisible ?? false);

  applyQuality(initialConfig);

  let bounceFrameCounter = 0;
  let monitorTimer = 0;
  const targetBouncePos = new Vector3(0, 1.5, 8);
  const scratchDir = new Vector3();
  const scratchRay = new Ray(new Vector3(), new Vector3(0, 0, 1), 16);

  const updateDynamicElements = (
    elapsed: number,
    dt: number,
    flashlightOn: boolean,
    flashlightFlickerMult: number,
    powerRestored: boolean,
    generatorRestored: boolean,
    cluesCollected: number,
    onFlickerBuzz: () => void,
  ) => {
    flashlight.setEnabled(flashlightOn && flashlightFlickerMult > 0.05);
    flashlight.intensity = (isMobileTier ? 14.5 : 16.0) * flashlightFlickerMult;
    flashCone.isVisible =
      flashlightOn && flashlightFlickerMult > 0.2 && volumetricCones[0]?.isVisible !== false;

    for (const dr of chapterExt.drawers) {
      const target = dr.isOpen ? 1 : 0;
      dr.openProgress = Scalar.Lerp(dr.openProgress, target, 1 - Math.exp(-8 * dt));
      dr.drawerMesh.position.z = 0.02 + dr.openProgress * 0.36;
    }

    fanHub.rotation.y += dt * (powerRestored ? 4.2 : 1.15);

    if (puddleMat.bumpTexture) {
      textures.floor.bump.uOffset = Math.sin(elapsed * 0.45) * 0.008;
      textures.floor.bump.vOffset = Math.cos(elapsed * 0.38) * 0.008;
    }

    monitorTimer += dt;
    if (monitorTimer >= monitorInterval) {
      monitorTimer = 0;
      textures.updateMonitorScreen(elapsed, powerRestored, cluesCollected);
    }

    // Proximity-based PointLight culling
    const camZ = camera.position.z;
    if (activeMaxPointLights < fixtures.length) {
      const ranked = fixtures
        .map((f, idx) => ({ idx, dist: Math.abs(f.zPos - camZ) }))
        .sort((a, b) => a.dist - b.dist);
      for (let r = 0; r < ranked.length; r++) {
        fixtures[ranked[r].idx].light.setEnabled(r < activeMaxPointLights);
      }
    } else {
      for (const f of fixtures) f.light.setEnabled(true);
    }

    for (const f of fixtures) {
      if (f.isEmergency) {
        const pulse = 0.72 + 0.28 * Math.sin(elapsed * (powerRestored ? 1.5 : 3.6) + f.phase);
        if (powerRestored) {
          f.light.diffuse.set(0.3, 1.0, 0.7);
          f.tubeMat.emissiveColor.set(0.2, 0.9, 0.58);
          f.light.intensity = 2.4;
        } else {
          f.light.diffuse.set(1.0, 0.46, 0.2);
          f.tubeMat.emissiveColor.set(1.0, 0.42, 0.14);
          f.light.intensity = f.baseIntensity * pulse;
        }
        continue;
      }

      if (powerRestored || generatorRestored) {
        const target = powerRestored ? 3.0 : f.baseIntensity * 1.15;
        f.light.intensity = Scalar.Lerp(f.light.intensity, target, 1 - Math.exp(-3 * dt));
        if (powerRestored) {
          f.tubeMat.emissiveColor.set(0.75, 0.9, 1.0);
          continue;
        }
      }

      f.flickerCooldown -= dt;
      if (f.flickerCooldown <= 0) {
        f.isFlickering = !f.isFlickering;
        if (f.isFlickering) {
          f.flickerCooldown = 0.08 + Math.random() * 0.28;
          if (f.light.isEnabled() && Math.random() < 0.3) onFlickerBuzz();
        } else {
          f.flickerCooldown = 2.2 + Math.random() * 5.0;
        }
      }

      const hum = 0.94 + 0.06 * Math.sin(elapsed * 2.4 + f.phase);
      const mult = f.isFlickering ? (Math.sin(elapsed * 58) > 0 ? 0.14 : 0.42) : 1.0;
      f.light.intensity = f.baseIntensity * hum * mult;
      f.tubeMat.emissiveColor.set(0.55 * hum * mult, 0.76 * hum * mult, 0.96 * hum * mult);
    }

    bounceFrameCounter = (bounceFrameCounter + 1) % raycastStride;
    if (flashlightOn && bounceFrameCounter === 0) {
      camera.getDirectionToRef(Vector3.Forward(), scratchDir);
      scratchRay.origin.copyFrom(camera.position);
      scratchRay.direction.copyFrom(scratchDir);
      const pick = scene.pickWithRay(scratchRay, (m) => raycastMeshes.includes(m));
      if (pick && pick.hit && pick.pickedPoint) {
        targetBouncePos.copyFrom(pick.pickedPoint).subtractInPlace(scratchDir.scale(0.45));
      } else {
        targetBouncePos.copyFrom(camera.position).addInPlace(scratchDir.scale(8));
      }
    }

    const alpha = 1 - Math.exp(-9 * dt);
    bounceLight.intensity = Scalar.Lerp(bounceLight.intensity, flashlightOn ? 1.55 : 0.2, alpha);
    bounceLight.position.x = Scalar.Lerp(bounceLight.position.x, targetBouncePos.x, alpha);
    bounceLight.position.y = Scalar.Lerp(bounceLight.position.y, targetBouncePos.y, alpha);
    bounceLight.position.z = Scalar.Lerp(bounceLight.position.z, targetBouncePos.z, alpha);

    // Animate door swings & locker hideout doors
    const doorAlpha = 1 - Math.exp(-6.5 * dt);
    for (const d of doors) {
      if (d.kind === 'barricaded') continue;
      d.openAngle = Scalar.Lerp(d.openAngle, d.targetAngle, doorAlpha);
      d.leftLeaf.rotation.y = d.openAngle;
      if (d.rightLeaf) d.rightLeaf.rotation.y = -d.openAngle;
    }

    for (const h of hideouts) {
      if (!h.doorPivot) continue;
      h.doorAngle = Scalar.Lerp(h.doorAngle, h.targetDoorAngle, 1 - Math.exp(-10 * dt));
      h.doorPivot.rotation.y = h.doorAngle;
    }

    if (shatterTimer > 0) {
      shatterTimer = Math.max(0, shatterTimer - dt);
      const t = 1 - shatterTimer / 0.75;
      const sc = 0.25 + t * 3.2;
      shatterRing.scaling.set(sc, 1, sc);
      shatterRingMat.alpha = Math.max(0, (1 - t) * 0.85);
      shatterShards.forEach((s) => {
        s.mesh.position.x = s.vx * t * 0.75;
        s.mesh.position.z = s.vz * t * 0.75;
        s.mesh.position.y = Math.max(0.015, 0.08 + s.vy * t - 4.9 * t * t);
      });
      if (shatterTimer <= 0) {
        shatterRoot.setEnabled(false);
      }
    }

    for (const item of interactables) {
      if (item.collected || item.doorRef || item.hideoutRef) continue;
      if (!item.isExitPanel && !item.isGeneratorSwitch) {
        item.ringMesh.rotation.y = elapsed * 0.9;
        const s = 0.92 + 0.12 * Math.sin(elapsed * 2.6);
        item.ringMesh.scaling.set(s, 1, s);
      }
    }

    if (powerRestored) {
      const exitAlpha = 1 - Math.exp(-3.2 * dt);
      northExit.leftLeaf.rotation.y = Scalar.Lerp(northExit.leftLeaf.rotation.y, -1.32, exitAlpha);
      if (northExit.rightLeaf) {
        northExit.rightLeaf.rotation.y = Scalar.Lerp(northExit.rightLeaf.rotation.y, 1.32, exitAlpha);
      }
      breakerLever.rotation.x = Scalar.Lerp(breakerLever.rotation.x, 0.95, 1 - Math.exp(-7 * dt));
    }
  };

  const resetObjectives = () => {
    for (const item of interactables) {
      item.collected = false;
      if (!item.isExitPanel && !item.isGeneratorSwitch && !item.doorRef && !item.hideoutRef) {
        item.root.setEnabled(true);
      } else if (item.isExitPanel || item.isGeneratorSwitch) {
        item.ringMesh.isVisible = true;
      }
    }
    for (const h of hideouts) {
      h.doorAngle = 0;
      h.targetDoorAngle = 0;
      if (h.doorPivot) h.doorPivot.rotation.y = 0;
    }
    thrownBottleMesh.setEnabled(false);
    shatterRoot.setEnabled(false);
    shatterTimer = 0;
    for (const d of doors) {
      if (d.id === 'door_obs') {
        d.isOpen = true;
        d.isUnlocked = true;
        d.openAngle = 1.35;
        d.targetAngle = 1.35;
        d.collider.disabled = true;
        d.leftLeaf.rotation.y = 1.35;
      } else if (d.kind === 'locked') {
        d.isOpen = false;
        d.isUnlocked = false;
        d.openAngle = 0;
        d.targetAngle = 0;
        d.collider.disabled = false;
        d.leftLeaf.rotation.y = 0;
      }
    }
    breakerLedMat.diffuseColor.set(1.0, 0.24, 0.18);
    breakerLedMat.emissiveColor.set(1.0, 0.22, 0.16);
    generatorLedMat.diffuseColor.set(1.0, 0.25, 0.16);
    generatorLedMat.emissiveColor.set(1.0, 0.22, 0.14);
    breakerLever.rotation.x = 0;
    northExit.leftLeaf.rotation.y = 0;
    if (northExit.rightLeaf) {
      northExit.rightLeaf.rotation.y = 0;
    }
    monster.root.position.set(0, 0, -14.0);
  };

  const dispose = () => {
    chapterExt.cleanup();
    atmosphereFx.dispose();
    dustSystem.dispose();
    gaussianBuildingsMesh?.dispose();
    mirrorTex?.dispose();
    moonShadowGen?.dispose();
    shadowGen?.dispose();
    textures.dispose();
    scene.dispose();
  };

  return {
    scene,
    camera,
    flashlight,
    bounceLight,
    colliders,
    puddles,
    doors,
    hideouts,
    interactables,
    fixtures,
    breakerLedMat,
    generatorLedMat,
    monster,
    noahRig,
    fpGear,
    drawers: chapterExt.drawers,
    npcs: chapterExt.npcs,
    raycastMeshes,
    thrownBottleMesh,
    triggerGlassShatter,
    setPremiumSkins,
    applyQuality,
    setGaussianEnabled,
    isGaussianEnabled,
    updateDynamicElements,
    resetObjectives,
    dispose,
  };
}
