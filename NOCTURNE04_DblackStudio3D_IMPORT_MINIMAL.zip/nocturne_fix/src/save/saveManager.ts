import type {
  ChapterId,
  EndingId,
  GameSettings,
  GlobalProgressData,
  SaveSlotData,
} from '../types/game';

const SETTINGS_KEY = 'nocturne04_settings_v1';
const PROGRESS_KEY = 'nocturne04_progress_v1';
const SLOT_PREFIX = 'nocturne04_save_';
const IDB_NAME = 'nocturne04_db';
const IDB_STORE = 'saves';

export const DEFAULT_SETTINGS: GameSettings = {
  language: 'fr',
  masterVolume: 0.8,
  musicVolume: 0.65,
  sfxVolume: 0.85,
  mouseSensitivity: 1.0,
  fov: 1.04,
  subtitlesEnabled: true,
  profileMode: 'auto',
  visualFilter: 'none',
};

function generateProfileId(): string {
  const arr = new Uint8Array(12);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(arr);
  } else {
    for (let i = 0; i < arr.length; i++) arr[i] = Math.floor(Math.random() * 256);
  }
  return 'nk_' + Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('');
}

export const DEFAULT_PROGRESS: GlobalProgressData = {
  unlockedChapters: ['ch1'],
  unlockedEndings: [],
  discoveredDocIds: [],
  discoveredTapeIds: [],
  profileId: generateProfileId(),
  lastPlayedAt: null,
};

function openIdb(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    if (typeof indexedDB === 'undefined') {
      resolve(null);
      return;
    }
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          db.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbPut(key: string, value: unknown): Promise<void> {
  const db = await openIdb();
  if (!db) return;
  try {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).put(value, key);
  } catch {
    // Non-fatal
  }
}

export const SaveManager = {
  loadSettings(): GameSettings {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (!raw) return { ...DEFAULT_SETTINGS };
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  },

  saveSettings(settings: GameSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // Ignore quota errors
    }
  },

  loadProgress(): GlobalProgressData {
    try {
      const raw = localStorage.getItem(PROGRESS_KEY);
      if (!raw) {
        const initial = { ...DEFAULT_PROGRESS, profileId: generateProfileId() };
        localStorage.setItem(PROGRESS_KEY, JSON.stringify(initial));
        return initial;
      }
      const parsed = JSON.parse(raw) as Partial<GlobalProgressData>;
      return {
        unlockedChapters: parsed.unlockedChapters?.length ? parsed.unlockedChapters : ['ch1'],
        unlockedEndings: parsed.unlockedEndings ?? [],
        discoveredDocIds: parsed.discoveredDocIds ?? [],
        discoveredTapeIds: parsed.discoveredTapeIds ?? [],
        profileId: parsed.profileId || generateProfileId(),
        lastPlayedAt: parsed.lastPlayedAt ?? null,
      };
    } catch {
      return { ...DEFAULT_PROGRESS, profileId: generateProfileId() };
    }
  },

  saveProgress(progress: GlobalProgressData): void {
    try {
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
      void idbPut('progress', progress);
    } catch {
      // Ignore
    }
  },

  unlockChapter(chapterId: ChapterId): GlobalProgressData {
    const prog = this.loadProgress();
    if (!prog.unlockedChapters.includes(chapterId)) {
      prog.unlockedChapters.push(chapterId);
    }
    prog.lastPlayedAt = new Date().toISOString();
    this.saveProgress(prog);
    return prog;
  },

  unlockEnding(endingId: EndingId): GlobalProgressData {
    const prog = this.loadProgress();
    if (!prog.unlockedEndings.includes(endingId)) {
      prog.unlockedEndings.push(endingId);
    }
    prog.lastPlayedAt = new Date().toISOString();
    this.saveProgress(prog);
    return prog;
  },

  recordDiscovery(docIds: string[], tapeIds: string[]): GlobalProgressData {
    const prog = this.loadProgress();
    for (const d of docIds) {
      if (!prog.discoveredDocIds.includes(d)) prog.discoveredDocIds.push(d);
    }
    for (const t of tapeIds) {
      if (!prog.discoveredTapeIds.includes(t)) prog.discoveredTapeIds.push(t);
    }
    this.saveProgress(prog);
    return prog;
  },

  saveSlot(slot: SaveSlotData): void {
    try {
      const serialized = JSON.stringify(slot);
      localStorage.setItem(`${SLOT_PREFIX}${slot.slotId}`, serialized);
      void idbPut(`slot_${slot.slotId}`, slot);
      this.unlockChapter(slot.chapterId);
      this.recordDiscovery(slot.discoveredDocIds, slot.discoveredTapeIds);
      void this.syncToCloud(slot);
    } catch {
      // Ignore
    }
  },

  loadSlot(slotId: SaveSlotData['slotId']): SaveSlotData | null {
    try {
      const raw = localStorage.getItem(`${SLOT_PREFIX}${slotId}`);
      if (!raw) return null;
      return JSON.parse(raw) as SaveSlotData;
    } catch {
      return null;
    }
  },

  listSlots(): Record<SaveSlotData['slotId'], SaveSlotData | null> {
    return {
      auto: this.loadSlot('auto'),
      slot1: this.loadSlot('slot1'),
      slot2: this.loadSlot('slot2'),
      slot3: this.loadSlot('slot3'),
    };
  },

  getLatestSave(): SaveSlotData | null {
    const slots = Object.values(this.listSlots()).filter((s): s is SaveSlotData => s !== null);
    if (slots.length === 0) return null;
    slots.sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime());
    return slots[0];
  },

  deleteSlot(slotId: SaveSlotData['slotId']): void {
    try {
      localStorage.removeItem(`${SLOT_PREFIX}${slotId}`);
    } catch {
      // Ignore
    }
  },

  async syncToCloud(slot: SaveSlotData): Promise<boolean> {
    try {
      const prog = this.loadProgress();
      const res = await fetch('/api/saves', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          profileId: prog.profileId,
          slot,
          progress: prog,
        }),
      });
      return res.ok;
    } catch {
      return false;
    }
  },

  async pullFromCloud(): Promise<{ slots: SaveSlotData[]; progress: GlobalProgressData } | null> {
    try {
      const prog = this.loadProgress();
      const res = await fetch(`/api/saves/${encodeURIComponent(prog.profileId)}`);
      if (!res.ok) return null;
      return (await res.json()) as { slots: SaveSlotData[]; progress: GlobalProgressData };
    } catch {
      return null;
    }
  },
};
