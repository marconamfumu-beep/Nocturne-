# MINUIT — La Ville Silencieuse

Projet web 3D basé sur **Babylon.js** (`@babylonjs/core`) et React/Vite.

## Moteur 3D
- Moteur utilisé : Babylon.js.
- Aucun import `three` / `THREE.*` dans les sources applicatives.
- Les dépendances `three` et `@types/three` ont été retirées du manifeste.
- Le fichier `bun.lock` obsolète a été retiré : les dépendances seront résolues depuis `package.json`.

## Lancer le projet
Prérequis : Node.js récent.

```bash
npm install
npm run dev
```

## Vérifier la production
```bash
npm run lint
npm run build
npm run preview
```

Le dossier généré est `dist/`.

## Déploiement Netlify
- Build command : `npm run build`
- Publish directory : `dist`

## Compatibilité mobile
Le jeu possède des contrôles tactiles et un profil de rendu adaptatif. Sur iPhone, utiliser Safari en mode paysage et commencer par le profil « Mobile paysage » ou « Performance » si le rendu ralentit.

## Limites
Le rendu Babylon.js peut être cinématographique, mais ce n'est pas Unreal Engine 5 : il ne fournit pas automatiquement Lumen, Nanite ou le ray tracing UE5. Les performances dépendent du GPU, du navigateur et de la complexité de la scène.


## BUILD 05 — laboratoire Gaussian Splatting
- Ouvrir `/gaussian-preview.html` après lancement ou déploiement pour voir la scène de démonstration.
- Le projet charge le format `.splat` avec les loaders officiels Babylon.js (`@babylonjs/loaders`).
- L'asset fourni `public/assets/gaussian/hospital_corridor_demo.splat` est une **maquette procédurale de test** pour valider le pipeline de rendu. Ce n'est pas une capture photogrammétrique ou une reconstruction réelle d'un hôpital.
- Remplacer cet asset par une vraie capture `.splat`, `.ply`, `.spz` ou `.sog` lorsque celle-ci aura été créée.
- Le rendu Gaussian est séparé de la scène de jeu principale pour permettre de comparer le résultat sans casser les collisions, les objets interactifs et les contrôles existants.
