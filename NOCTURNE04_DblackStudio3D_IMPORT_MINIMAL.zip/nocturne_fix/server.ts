import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import express from 'express';
import type { Request, Response } from 'express';

const PORT =
  process.env.NODE_ENV !== 'production' ? 3000 : Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_FILE = path.join(DATA_DIR, 'store.json');
const SAVES_FILE = path.join(DATA_DIR, 'saves.json');

const ENTITLEMENT_SECRET =
  process.env.ENTITLEMENT_SECRET ||
  crypto.createHash('sha256').update(`${process.cwd()}_nocturne04_secret`).digest('hex');

interface StoredTransaction {
  id: string;
  productId: 'premium_pass' | 'dlc_dossiers';
  productName: string;
  amountCents: number;
  currency: string;
  status: 'paid' | 'pending' | 'failed';
  createdAt: string;
  customerEmail: string;
  sessionId: string;
}

interface AccountEntitlementRecord {
  email: string;
  premiumPass: boolean;
  dlcForgottenFiles: boolean;
  verifiedAt: string;
}

interface StoreDb {
  accounts: Record<string, AccountEntitlementRecord>;
  transactions: StoredTransaction[];
}

interface SavesDb {
  profiles: Record<
    string,
    {
      progress: Record<string, unknown>;
      slots: Record<string, unknown>;
      updatedAt: string;
    }
  >;
}

const CATALOG = [
  {
    id: 'premium_pass' as const,
    sku: 'NOCTURNE04_PREMIUM_PASS',
    name: 'NOCTURNE 04 PREMIUM PASS',
    nameEn: 'NOCTURNE 04 PREMIUM PASS',
    priceUsd: 4.99,
    priceDisplay: '4,99 $',
    amountCents: 499,
    tagline:
      'Tenue tactique de Noah, lampe torche spéciale, Mode Photo, filtres visuels et dossiers bonus.',
    taglineEn:
      'Exclusive Noah tactical outfit, custom flashlight skin, Photo Mode, visual filters, and bonus files.',
    imageUrl: '/src/assets/images/premium_pass_showcase_1794998102538.jpg',
    features: [
      'Tenue exclusive d’ambulancier tactique de Noah (vue 3e personne)',
      'Lampe torche spéciale UV / Ambre avec faisceau amélioré',
      'Mode Photo complet avec caméra libre et capture PNG',
      'Filtres exclusifs Caméra VHS & Vision Nocturne',
      'Documents classifiés bonus et notes narratives inédites',
    ],
    featuresEn: [
      'Exclusive Noah tactical paramedic outfit (3rd person view)',
      'Custom UV / Amber tactical flashlight skin & beam',
      'Full Photo Mode with free-roam camera & PNG capture',
      'Exclusive VHS Bodycam & Night-Vision visual filters',
      'Bonus classified documents & director lore notes',
    ],
  },
  {
    id: 'dlc_dossiers' as const,
    sku: 'NOCTURNE04_DLC_DOSSIERS',
    name: 'DLC — LES DOSSIERS OUBLIÉS',
    nameEn: 'DLC — THE FORGOTTEN FILES',
    priceUsd: 2.99,
    priceDisplay: '2,99 $',
    amountCents: 299,
    tagline:
      'Nouvelle histoire indépendante (30–45 min) dans le Bloc Zéro lors de l’incendie d’il y a 11 ans.',
    taglineEn:
      'Standalone prequel story (30–45 min) inside Block Zero during the fire 11 years ago.',
    imageUrl: '/src/assets/images/dlc_dossiers_art_1794998103686.jpg',
    features: [
      'Chapitre inédit jouable : La Première Nuit du Programme NOCTURNE',
      'Nouvelle zone secrète en flammes : Bloc Zéro',
      'Documents inédits et bande boîte noire de 2015',
      'Révélations sur l’origine de l’incendie et d’Elias Kanza',
    ],
    featuresEn: [
      'New playable chapter: First Night of Project NOCTURNE',
      'New burning secret zone: Block Zero',
      'Unreleased documents & 2015 black-box audio tape',
      'Deep revelations on the fire and Elias Kanza’s origin',
    ],
  },
];

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readStore(): StoreDb {
  ensureDataDir();
  if (!fs.existsSync(STORE_FILE)) {
    return { accounts: {}, transactions: [] };
  }
  try {
    return JSON.parse(fs.readFileSync(STORE_FILE, 'utf8')) as StoreDb;
  } catch {
    return { accounts: {}, transactions: [] };
  }
}

function writeStore(db: StoreDb) {
  ensureDataDir();
  fs.writeFileSync(STORE_FILE, JSON.stringify(db, null, 2), 'utf8');
}

function readSaves(): SavesDb {
  ensureDataDir();
  if (!fs.existsSync(SAVES_FILE)) {
    return { profiles: {} };
  }
  try {
    return JSON.parse(fs.readFileSync(SAVES_FILE, 'utf8')) as SavesDb;
  } catch {
    return { profiles: {} };
  }
}

function writeSaves(db: SavesDb) {
  ensureDataDir();
  fs.writeFileSync(SAVES_FILE, JSON.stringify(db, null, 2), 'utf8');
}

function signEntitlementToken(payload: {
  email: string;
  premiumPass: boolean;
  dlcForgottenFiles: boolean;
  verifiedAt: string;
}): string {
  const body = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', ENTITLEMENT_SECRET).update(body).digest('base64url');
  return `nk_ent_${body}.${sig}`;
}

function verifyEntitlementToken(
  token: string,
): { email: string; premiumPass: boolean; dlcForgottenFiles: boolean; verifiedAt: string } | null {
  if (!token || !token.startsWith('nk_ent_')) return null;
  const raw = token.slice('nk_ent_'.length);
  const dot = raw.indexOf('.');
  if (dot <= 0) return null;
  const body = raw.slice(0, dot);
  const sig = raw.slice(dot + 1);
  const expected = crypto.createHmac('sha256', ENTITLEMENT_SECRET).update(body).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    return JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
}

function recordPaidPurchase(
  emailRaw: string,
  productId: 'premium_pass' | 'dlc_dossiers',
  sessionId: string,
  amountCents: number,
  currency: string,
) {
  const email = emailRaw.trim().toLowerCase();
  const db = readStore();
  const existing = db.accounts[email] ?? {
    email,
    premiumPass: false,
    dlcForgottenFiles: false,
    verifiedAt: new Date().toISOString(),
  };

  if (productId === 'premium_pass') existing.premiumPass = true;
  if (productId === 'dlc_dossiers') existing.dlcForgottenFiles = true;
  existing.verifiedAt = new Date().toISOString();
  db.accounts[email] = existing;

  const alreadyLogged = db.transactions.some((t) => t.sessionId === sessionId);
  if (!alreadyLogged) {
    const prod = CATALOG.find((p) => p.id === productId);
    db.transactions.unshift({
      id: `tx_${crypto.randomBytes(6).toString('hex')}`,
      productId,
      productName: prod?.name ?? productId,
      amountCents,
      currency: currency.toUpperCase(),
      status: 'paid',
      createdAt: new Date().toISOString(),
      customerEmail: email,
      sessionId,
    });
  }

  writeStore(db);
  const token = signEntitlementToken({
    email,
    premiumPass: existing.premiumPass,
    dlcForgottenFiles: existing.dlcForgottenFiles,
    verifiedAt: existing.verifiedAt,
  });

  return {
    entitlements: {
      premiumPass: existing.premiumPass,
      dlcForgottenFiles: existing.dlcForgottenFiles,
      token,
      customerEmail: email,
      verifiedAt: existing.verifiedAt,
    },
    transactions: db.transactions.filter((t) => t.customerEmail === email),
  };
}

function verifyStripeWebhookSig(rawBody: string, header: string | undefined, secret: string): boolean {
  if (!header) return false;
  const parts = Object.fromEntries(
    header.split(',').map((kv) => {
      const idx = kv.indexOf('=');
      return [kv.slice(0, idx), kv.slice(idx + 1)];
    }),
  );
  if (!parts.t || !parts.v1) return false;
  const signedPayload = `${parts.t}.${rawBody}`;
  const expected = crypto.createHmac('sha256', secret).update(signedPayload).digest('hex');
  const a = Buffer.from(parts.v1);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function createAppServer() {
  const app = express();

  // Stripe webhook requires raw body for signature validation
  app.post(
    '/api/shop/webhook',
    express.raw({ type: 'application/json' }),
    (req: Request, res: Response) => {
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
      if (!webhookSecret) {
        res.status(503).json({ error: 'STRIPE_WEBHOOK_SECRET non configuré.' });
        return;
      }
      const rawBody = Buffer.isBuffer(req.body) ? req.body.toString('utf8') : String(req.body);
      const sig = req.header('stripe-signature');
      if (!verifyStripeWebhookSig(rawBody, sig, webhookSecret)) {
        res.status(400).json({ error: 'Signature Stripe invalide.' });
        return;
      }
      try {
        const event = JSON.parse(rawBody) as {
          type: string;
          data?: {
            object?: {
              id?: string;
              payment_status?: string;
              customer_email?: string;
              customer_details?: { email?: string };
              amount_total?: number;
              currency?: string;
              metadata?: { productId?: string; customerEmail?: string };
            };
          };
        };
        if (event.type === 'checkout.session.completed' && event.data?.object) {
          const obj = event.data.object;
          if (obj.payment_status === 'paid') {
            const productId =
              obj.metadata?.productId === 'dlc_dossiers' ? 'dlc_dossiers' : 'premium_pass';
            const email =
              obj.customer_details?.email ||
              obj.customer_email ||
              obj.metadata?.customerEmail ||
              '';
            if (email && obj.id) {
              recordPaidPurchase(
                email,
                productId,
                obj.id,
                obj.amount_total ?? (productId === 'dlc_dossiers' ? 299 : 499),
                obj.currency ?? 'usd',
              );
            }
          }
        }
        res.json({ received: true });
      } catch {
        res.status(400).json({ error: 'Charge utile webhook invalide.' });
      }
    },
  );

  app.use(express.json({ limit: '1mb' }));

  // Shop Catalog
  app.get('/api/shop/catalog', (_req: Request, res: Response) => {
    res.json({
      products: CATALOG,
      stripeConfigured: Boolean(process.env.STRIPE_SECRET_KEY),
      currency: 'USD',
    });
  });

  // Create real Stripe Checkout session
  app.post('/api/shop/create-checkout-session', async (req: Request, res: Response) => {
    const stripeKey = process.env.STRIPE_SECRET_KEY;
    if (!stripeKey) {
      res.status(503).json({
        ok: false,
        code: 'STRIPE_UNCONFIGURED',
        error:
          'Paiement Stripe réel non configuré sur ce serveur (STRIPE_SECRET_KEY manquant dans .env). Aucun achat factice n’est autorisé.',
      });
      return;
    }

    const { productId, customerEmail } = req.body as {
      productId?: 'premium_pass' | 'dlc_dossiers';
      customerEmail?: string;
    };
    const product = CATALOG.find((p) => p.id === productId);
    const email = (customerEmail ?? '').trim().toLowerCase();
    if (!product || !email.includes('@')) {
      res.status(400).json({
        ok: false,
        error: 'Produit ou adresse e-mail invalide.',
      });
      return;
    }

    const origin =
      process.env.APP_URL ||
      `${req.protocol}://${req.get('host') || `localhost:${PORT}`}`;

    const configuredPriceId =
      product.id === 'premium_pass'
        ? process.env.STRIPE_PRICE_PREMIUM_PASS
        : process.env.STRIPE_PRICE_DLC_DOSSIERS;

    const form = new URLSearchParams();
    form.set('mode', 'payment');
    form.set('customer_email', email);
    form.set('success_url', `${origin}/?checkout_session_id={CHECKOUT_SESSION_ID}`);
    form.set('cancel_url', `${origin}/?checkout_canceled=1`);
    form.set('metadata[productId]', product.id);
    form.set('metadata[customerEmail]', email);

    if (configuredPriceId) {
      form.set('line_items[0][price]', configuredPriceId);
      form.set('line_items[0][quantity]', '1');
    } else {
      form.set('line_items[0][price_data][currency]', 'usd');
      form.set('line_items[0][price_data][unit_amount]', String(product.amountCents));
      form.set('line_items[0][price_data][product_data][name]', product.nameEn);
      form.set('line_items[0][price_data][product_data][description]', product.taglineEn);
      form.set('line_items[0][quantity]', '1');
    }

    try {
      const stripeRes = await fetch('https://api.stripe.com/v1/checkout/sessions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${stripeKey}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: form.toString(),
      });
      const stripeData = (await stripeRes.json()) as {
        id?: string;
        url?: string;
        error?: { message?: string };
      };
      if (!stripeRes.ok || !stripeData.url) {
        res.status(502).json({
          ok: false,
          error: stripeData.error?.message || 'Erreur lors de la création de session Stripe.',
        });
        return;
      }
      res.json({
        ok: true,
        sessionId: stripeData.id,
        checkoutUrl: stripeData.url,
      });
    } catch {
      res.status(502).json({ ok: false, error: 'Impossible de joindre l’API Stripe.' });
    }
  });

  // Verify Stripe Checkout Session server-side
  app.post('/api/shop/verify-session', async (req: Request, res: Response) => {
    const stripeKey = process.env.STRIPE_SECRET_KEY;
    if (!stripeKey) {
      res.status(503).json({
        ok: false,
        error: 'STRIPE_SECRET_KEY manquant : vérification impossible.',
      });
      return;
    }

    const { sessionId } = req.body as { sessionId?: string };
    if (!sessionId || !sessionId.startsWith('cs_')) {
      res.status(400).json({ ok: false, error: 'Identifiant de session Stripe invalide.' });
      return;
    }

    try {
      const stripeRes = await fetch(
        `https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sessionId)}`,
        {
          headers: { Authorization: `Bearer ${stripeKey}` },
        },
      );
      const session = (await stripeRes.json()) as {
        id?: string;
        payment_status?: string;
        customer_email?: string;
        customer_details?: { email?: string };
        amount_total?: number;
        currency?: string;
        metadata?: { productId?: string; customerEmail?: string };
        error?: { message?: string };
      };

      if (!stripeRes.ok || session.payment_status !== 'paid') {
        res.status(402).json({
          ok: false,
          error: session.error?.message || 'Paiement Stripe non confirmé.',
        });
        return;
      }

      const productId =
        session.metadata?.productId === 'dlc_dossiers' ? 'dlc_dossiers' : 'premium_pass';
      const email =
        session.customer_details?.email ||
        session.customer_email ||
        session.metadata?.customerEmail ||
        '';
      if (!email) {
        res.status(400).json({ ok: false, error: 'Adresse e-mail client introuvable.' });
        return;
      }

      const result = recordPaidPurchase(
        email,
        productId,
        session.id ?? sessionId,
        session.amount_total ?? (productId === 'dlc_dossiers' ? 299 : 499),
        session.currency ?? 'usd',
      );
      res.json({ ok: true, ...result });
    } catch {
      res.status(502).json({ ok: false, error: 'Erreur lors de la vérification Stripe.' });
    }
  });

  // Validate HMAC entitlement token
  app.post('/api/shop/validate-token', (req: Request, res: Response) => {
    const { token } = req.body as { token?: string };
    const decoded = token ? verifyEntitlementToken(token) : null;
    if (!decoded) {
      res.status(401).json({ ok: false, error: 'Jeton de licence invalide.' });
      return;
    }
    const db = readStore();
    const acc = db.accounts[decoded.email.toLowerCase()];
    const merged = {
      premiumPass: Boolean(acc?.premiumPass ?? decoded.premiumPass),
      dlcForgottenFiles: Boolean(acc?.dlcForgottenFiles ?? decoded.dlcForgottenFiles),
      verifiedAt: acc?.verifiedAt ?? decoded.verifiedAt,
    };
    const refreshedToken = signEntitlementToken({
      email: decoded.email.toLowerCase(),
      ...merged,
    });
    res.json({
      ok: true,
      entitlements: {
        ...merged,
        token: refreshedToken,
        customerEmail: decoded.email.toLowerCase(),
      },
    });
  });

  // Restore purchases by verified email or token
  app.post('/api/shop/restore', (req: Request, res: Response) => {
    const { customerEmail, token } = req.body as { customerEmail?: string; token?: string };
    const decoded = token ? verifyEntitlementToken(token) : null;
    const email = (decoded?.email || customerEmail || '').trim().toLowerCase();
    if (!email) {
      res.status(400).json({ ok: false, error: 'E-mail ou jeton requis.' });
      return;
    }
    const db = readStore();
    const acc = db.accounts[email];
    if (!acc || (!acc.premiumPass && !acc.dlcForgottenFiles)) {
      res.status(404).json({
        ok: false,
        error: 'Aucun achat vérifié trouvé pour cette adresse.',
      });
      return;
    }
    const freshToken = signEntitlementToken({
      email,
      premiumPass: acc.premiumPass,
      dlcForgottenFiles: acc.dlcForgottenFiles,
      verifiedAt: acc.verifiedAt,
    });
    res.json({
      ok: true,
      entitlements: {
        premiumPass: acc.premiumPass,
        dlcForgottenFiles: acc.dlcForgottenFiles,
        token: freshToken,
        customerEmail: email,
        verifiedAt: acc.verifiedAt,
      },
      transactions: db.transactions.filter((t) => t.customerEmail === email),
    });
  });

  // Fetch transaction history for verified token/email
  app.get('/api/shop/transactions', (req: Request, res: Response) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const emailQuery = typeof req.query.email === 'string' ? req.query.email.toLowerCase() : '';
    const decoded = token ? verifyEntitlementToken(token) : null;
    const targetEmail = decoded?.email?.toLowerCase() || emailQuery;
    if (!targetEmail) {
      res.json({ transactions: [] });
      return;
    }
    const db = readStore();
    res.json({
      transactions: db.transactions.filter((t) => t.customerEmail === targetEmail),
    });
  });

  // Cloud Save Sync Endpoints
  app.post('/api/saves', (req: Request, res: Response) => {
    const { profileId, slot, progress } = req.body as {
      profileId?: string;
      slot?: { slotId?: string };
      progress?: Record<string, unknown>;
    };
    if (!profileId || !slot?.slotId) {
      res.status(400).json({ ok: false, error: 'Données de sauvegarde invalides.' });
      return;
    }
    const db = readSaves();
    const current = db.profiles[profileId] ?? {
      progress: {},
      slots: {},
      updatedAt: new Date().toISOString(),
    };
    current.slots[slot.slotId] = slot;
    if (progress) current.progress = progress;
    current.updatedAt = new Date().toISOString();
    db.profiles[profileId] = current;
    writeSaves(db);
    res.json({ ok: true, updatedAt: current.updatedAt });
  });

  app.get('/api/saves/:profileId', (req: Request, res: Response) => {
    const profileId = String(req.params.profileId || '');
    const db = readSaves();
    const record = db.profiles[profileId];
    if (!record) {
      res.status(404).json({ ok: false });
      return;
    }
    res.json({
      slots: Object.values(record.slots),
      progress: record.progress,
    });
  });

  const httpServer = http.createServer(app);

  // Frontend Vite Dev or Production Static Serving
  const distDir = path.resolve(process.cwd(), 'dist');
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        ws: { server: httpServer },
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else if (fs.existsSync(distDir)) {
    app.use(express.static(distDir));
    app.use((_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`NOCTURNE 04 server listening on http://0.0.0.0:${PORT}`);
  });
}

void createAppServer();
