# NOCTURNE 04 — PAVILLON KAMBALA

Jeu vidéo d'horreur et de survie 3D complet sur navigateur Web (PC et Mobile), propulsé par **React 19**, **Vite**, **Babylon.js (WebGL2 + Gaussian Splatting)** et **Express**.

## Contenu du jeu

- **6 Chapitres complets** :
  1. *L’Aile de Quarantaine* — Appel de Maya à 02h17, fouille, clés, pistolet 9mm, générateur, première traque.
  2. *Les Archives Interdites* — Caméras CCTV, bandes audio, dossiers NOCTURNE, digicode (`0217`).
  3. *Le Bloc Opératoire* — Protocoles chirurgicaux `04-A / 04-B`, stimulateur neuronal (`408 Hz`).
  4. *Le Laboratoire Souterrain* — Rencontre avec Maya, Dr Voss, cuves de confinement, choix moral.
  5. *La Vérité du Patient 04* — Zone de confinement Zéro, identité d'Elias Kanza, 3 dossiers classifiés cachés.
  6. *La Dernière Nuit* — Autodestruction (`0404`), confrontation avec Voss, poursuite finale.
- **3 Fins distinctes** :
  - **Fin A — Le Survivant**
  - **Fin B — Le Sacrifice**
  - **Fin C — NOCTURNE** *(fin secrète : récupérer les 3 dossiers classifiés au Chapitre 5 -> `PATIENT 05 — ADMISSION CONFIRMÉE`)*
- **IA avancée du Patient 04** : patrouille, suspicion, investigation sonore, poursuite, recherche, inspection de casiers, embuscades, recul aux tirs/fusées, mimétisme vocal de Maya.
- **Systèmes complets** : Vue 1P/3P (`V`), marche/sprint/accroupissement/saut, pistolet 9mm + rechargement, lampe torche + batterie, bouteilles leurres, fusées défensives, tiroirs fouillables, sauvegardes auto + 3 emplacements manuels (`localStorage` + `IndexedDB` + sync `/api/saves`).
- **Boutique Web sécurisée** : Jeu principal 100 % gratuit ; **Premium Pass (4,99 $)** et **DLC Les Dossiers Oubliés (2,99 $)** vérifiés côté serveur via **Stripe Checkout** + jetons signés **HMAC-SHA256**.

## Commandes

- `WASD / ZQSD` : Déplacement (`Maj` Courir, `C` Accroupir, `Espace` Sauter)
- `Souris` : Orienter la caméra (`Clic Gauche` Tirer 9mm, `R` Recharger)
- `V` : Basculer Vue 1re personne / 3e personne
- `E` : Interagir / Ouvrir / Fouiller / Se cacher
- `F` / `B` : Lampe torche / Changer pile
- `G` / `X` / `H` : Lancer bouteille / Fusée défensive / Trousse de soins
- `Tab` / `J` / `Échap` : Inventaire / Codex & Archives / Pause

## Installation et lancement local

```bash
npm install
npm run dev
```

Ouvrir `http://localhost:3000`.

### Build de production

```bash
npm run build
npm start
```

## Configuration Paiements Stripe & Déploiement Netlify

1. Copiez `.env.example` vers `.env`.
2. Renseignez vos clés marchandes Stripe côté serveur :
   - `STRIPE_SECRET_KEY=sk_live_...` (ou `sk_test_...`)
   - `STRIPE_WEBHOOK_SECRET=whsec_...`
   - `ENTITLEMENT_SECRET=...` (chaîne aléatoire longue pour signer les jetons)
   - `APP_URL=https://votre-domaine.netlify.app`
3. Pour déployer sur **Netlify**, le fichier `netlify.toml` et la fonction `netlify/functions/api.mjs` sont déjà configurés. Définissez simplement les variables d'environnement dans l'interface Netlify.


## Installation comme application (PWA)
Le projet inclut maintenant un manifeste, des icônes et un service worker. Déployez le site en HTTPS (Netlify le fournit), puis :
- Android / Chrome : ouvrez l’URL du jeu, menu ⋮, puis « Installer l’application » ou « Ajouter à l’écran d’accueil ».
- iPhone / Safari : bouton Partager, puis « Sur l’écran d’accueil ».
La mise en cache permet de retrouver la coque de l’application hors connexion, mais le jeu et ses ressources ne sont pas garantis entièrement jouables sans réseau.
