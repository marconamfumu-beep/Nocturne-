import crypto from 'node:crypto';

const ENTITLEMENT_SECRET =
  process.env.ENTITLEMENT_SECRET ||
  crypto.createHash('sha256').update('nocturne04_netlify_default').digest('hex');

const CATALOG = [
  {
    id: 'premium_pass',
    sku: 'NOCTURNE04_PREMIUM_PASS',
    name: 'NOCTURNE 04 PREMIUM PASS',
    nameEn: 'NOCTURNE 04 PREMIUM PASS',
    priceUsd: 4.99,
    priceDisplay: '4,99 $',
    amountCents: 499,
    tagline:
      'Tenue tactique de Noah, lampe torche spéciale, Mode Photo, filtres visuels et dossiers bonus.',
    taglineEn:
      'Exclusive Noah tactical outfit, custom flashlight skin, Photo Mode, visual filters, and bonus files.',
    imageUrl: '/src/assets/images/premium_pass_showcase_1794998102538.jpg',
    features: [
      'Tenue exclusive d’ambulancier tactique de Noah (vue 3e personne)',
      'Lampe torche spéciale UV / Ambre avec faisceau amélioré',
      'Mode Photo complet avec caméra libre et capture PNG',
      'Filtres exclusifs Caméra VHS & Vision Nocturne',
      'Documents classifiés bonus et notes narratives inédites',
    ],
    featuresEn: [
      'Exclusive Noah tactical paramedic outfit (3rd person view)',
      'Custom UV / Amber tactical flashlight skin & beam',
      'Full Photo Mode with free-roam camera & PNG capture',
      'Exclusive VHS Bodycam & Night-Vision visual filters',
      'Bonus classified documents & director lore notes',
    ],
  },
  {
    id: 'dlc_dossiers',
    sku: 'NOCTURNE04_DLC_DOSSIERS',
    name: 'DLC — LES DOSSIERS OUBLIÉS',
    nameEn: 'DLC — THE FORGOTTEN FILES',
    priceUsd: 2.99,
    priceDisplay: '2,99 $',
    amountCents: 299,
    tagline:
      'Nouvelle histoire indépendante (30–45 min) dans le Bloc Zéro lors de l’incendie d’il y a 11 ans.',
    taglineEn:
      'Standalone prequel story (30–45 min) inside Block Zero during the fire 11 years ago.',
    imageUrl: '/src/assets/images/dlc_dossiers_art_1794998103686.jpg',
    features: [
      'Chapitre inédit jouable : La Première Nuit du Programme NOCTURNE',
      'Nouvelle zone secrète en flammes : Bloc Zéro',
      'Documents inédits et bande boîte noire de 2015',
      'Révélations sur l’origine de l’incendie et d’Elias Kanza',
    ],
    featuresEn: [
      'New playable chapter: First Night of Project NOCTURNE',
      'New burning secret zone: Block Zero',
      'Unreleased documents & 2015 black-box audio tape',
      'Deep revelations on the fire and Elias Kanza’s origin',
    ],
  },
];

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
}

function signToken(payload) {
  const body = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', ENTITLEMENT_SECRET).update(body).digest('base64url');
  return `nk_ent_${body}.${sig}`;
}

function verifyToken(token) {
  if (!token || !token.startsWith('nk_ent_')) return null;
  const raw = token.slice('nk_ent_'.length);
  const dot = raw.indexOf('.');
  if (dot <= 0) return null;
  const body = raw.slice(0, dot);
  const sig = raw.slice(dot + 1);
  const expected = crypto.createHmac('sha256', ENTITLEMENT_SECRET).update(body).digest('base64url');
  if (sig !== expected) return null;
  try {
    return JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
}

export async function handler(event) {
  const path = event.path.replace(/^\/\.netlify\/functions\/api/, '').replace(/^\/api/, '');
  const stripeKey = process.env.STRIPE_SECRET_KEY;

  if (event.httpMethod === 'GET' && path === '/shop/catalog') {
    return json(200, {
      products: CATALOG,
      stripeConfigured: Boolean(stripeKey),
      currency: 'USD',
    });
  }

  if (event.httpMethod === 'POST' && path === '/shop/create-checkout-session') {
    if (!stripeKey) {
      return json(503, {
        ok: false,
        code: 'STRIPE_UNCONFIGURED',
        error: 'STRIPE_SECRET_KEY manquant dans les variables Netlify.',
      });
    }
    const { productId, customerEmail } = JSON.parse(event.body || '{}');
    const product = CATALOG.find((p) => p.id === productId);
    const email = (customerEmail || '').trim().toLowerCase();
    if (!product || !email.includes('@')) {
      return json(400, { ok: false, error: 'Produit ou adresse e-mail invalide.' });
    }
    const origin = process.env.APP_URL || process.env.URL || 'https://nocturne04.netlify.app';
    const form = new URLSearchParams({
      mode: 'payment',
      customer_email: email,
      success_url: `${origin}/?checkout_session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/?checkout_canceled=1`,
      'metadata[productId]': product.id,
      'metadata[customerEmail]': email,
      'line_items[0][price_data][currency]': 'usd',
      'line_items[0][price_data][unit_amount]': String(product.amountCents),
      'line_items[0][price_data][product_data][name]': product.nameEn,
      'line_items[0][price_data][product_data][description]': product.taglineEn,
      'line_items[0][quantity]': '1',
    });

    const stripeRes = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${stripeKey}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: form.toString(),
    });
    const stripeData = await stripeRes.json();
    if (!stripeRes.ok || !stripeData.url) {
      return json(502, { ok: false, error: stripeData.error?.message || 'Erreur Stripe.' });
    }
    return json(200, { ok: true, sessionId: stripeData.id, checkoutUrl: stripeData.url });
  }

  if (event.httpMethod === 'POST' && path === '/shop/verify-session') {
    if (!stripeKey) {
      return json(503, { ok: false, error: 'STRIPE_SECRET_KEY non configuré.' });
    }
    const { sessionId } = JSON.parse(event.body || '{}');
    if (!sessionId) return json(400, { ok: false, error: 'sessionId requis.' });
    const stripeRes = await fetch(
      `https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sessionId)}`,
      { headers: { Authorization: `Bearer ${stripeKey}` } },
    );
    const session = await stripeRes.json();
    if (!stripeRes.ok || session.payment_status !== 'paid') {
      return json(402, { ok: false, error: 'Paiement non confirmé.' });
    }
    const productId =
      session.metadata?.productId === 'dlc_dossiers' ? 'dlc_dossiers' : 'premium_pass';
    const email =
      session.customer_details?.email ||
      session.customer_email ||
      session.metadata?.customerEmail ||
      '';
    const verifiedAt = new Date().toISOString();
    const ent = {
      premiumPass: productId === 'premium_pass',
      dlcForgottenFiles: productId === 'dlc_dossiers',
      verifiedAt,
    };
    return json(200, {
      ok: true,
      entitlements: {
        ...ent,
        token: signToken({ email, ...ent }),
        customerEmail: email,
      },
    });
  }

  if (event.httpMethod === 'POST' && path === '/shop/validate-token') {
    const { token } = JSON.parse(event.body || '{}');
    const decoded = verifyToken(token);
    if (!decoded) return json(401, { ok: false, error: 'Jeton invalide.' });
    return json(200, {
      ok: true,
      entitlements: {
        premiumPass: Boolean(decoded.premiumPass),
        dlcForgottenFiles: Boolean(decoded.dlcForgottenFiles),
        token,
        customerEmail: decoded.email,
        verifiedAt: decoded.verifiedAt,
      },
    });
  }

  return json(404, { ok: false, error: 'Route API introuvable.' });
}
