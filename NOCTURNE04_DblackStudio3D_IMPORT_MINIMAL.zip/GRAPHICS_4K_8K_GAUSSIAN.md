# NOCTURNE 04 — profils graphiques 4K / 8K et Gaussian Splatting

- Les profils 4K AAA et 8K Cinématique sont disponibles dans Paramètres > Profil graphique.
- Ils utilisent les profils Babylon.js haute/ultra, des ombres jusqu’à 2048/4096 et un suréchantillonnage borné sur les GPU desktop.
- Les appareils tactiles et GPU logiciels restent protégés : le suréchantillonnage est désactivé pour éviter les plantages et pertes de FPS.
- Le rendu n’est pas une garantie de sortie native 3840×2160 ou 7680×4320 : la résolution réelle dépend de l’écran, du GPU, du navigateur et des limites WebGL.
- Gaussian Splatting Babylon.js était déjà intégré dans le projet. Les scans existants `kambala_buildings_scan.splat` et `hospital_corridor_demo.splat` sont conservés. Le scan des bâtiments est chargé dans la scène quand le GPU le permet; l’option SPLAT existante le masque/affiche.
- Aucun nouveau scan 4K/8K n’a été inventé : pour une vraie géométrie Gaussian haute résolution, il faudra fournir des captures `.splat`/`.ply` de qualité correspondante.
